import axios from 'axios';
import endPoints from '../constants/config';

const instanceAxios = axios.create({
  baseURL: endPoints.BASE_URL,
});

instanceAxios.interceptors.response.use(
  (response) => {
    //console.log('[interceptor response log]', response);
    return response;
  },
  (error) => {
    console.log('API failed ', error);
    return Promise.reject(error);
  },
);

instanceAxios.interceptors.request.use(
  (request) => {
    //console.log('[interceptor request log]', request);
    return request;
  },
  (error) => {
    console.log('API failed ', error);
    return Promise.reject(error);
  },
);

// adding token in out going req
export const setAuthToken = (token, UserID) => {
  if (token && UserID) {
    console.log('[axios] confirm new token update  2 ===>', token);
    instanceAxios.defaults.headers.common['Token'] = `${token}`;
    instanceAxios.defaults.headers.common['UserID'] = `${UserID}`;
  } else {
    delete instanceAxios.defaults.headers.common['Token'];
    delete instanceAxios.defaults.headers.common['UserID'];
  }
};

export default instanceAxios;
