import Images from './images';
import Icons from './icons';

export {Images, Icons};
