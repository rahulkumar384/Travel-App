export default {
  test:require('../assets/Tour-Guide.jpg'),
};
