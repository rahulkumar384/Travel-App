import axios, {setAuthToken} from './axios';
import EndPoint from '../constants/config';

export const makeAPICall = (endPoint, param, UserID = 1,urlencode = false) => {
  console.log(endPoint, param, UserID);
  const finalPromise = new Promise((res, rej) => {
    console.log(`Token: ${axios.defaults.headers.common.Token}`);
    axios
      .post(endPoint, param, {
        
        headers:urlencode == true? {
          "Content-Type":"application/x-www-form-urlencoded"
        }:{}
      })
      .then((response) => {
        //console.log('[magic func]: success case', response.data);
        //checking if we have 200 response
        if (response.data.StatusCode == 200) {
          console.log('[magic func] req resolve response 200 =======>');
          res(response);
        } else if (response.data.StatusCode == 401) {
          console.log('[magic func] ====> token expire');
          getNewToken(UserID)
            .then(() => {
              console.log(
                '[magic func] =====> recive new token and making http call again',
              );

              //making the call again
              retryCall(endPoint, param).then((retryResponse) => {
                console.log(
                  '[magic function] return response ===>',
                  retryResponse,
                );
                res(retryResponse);
              });
            })
            .catch((error) => {
              rej(error);
            });
        } else {
          //TODO 401 and more shit promise reject
        }
      })
      .catch((error) => {
        //TODO  finalPromise main promise reject krna he
        rej(error);
      });
  });

  return finalPromise;
};

const getNewToken = (UserID) => {
  let config = {
    headers: {
      UserID: UserID,
    },
  };

  let data = {};
  const makeNewTokenPromise = new Promise((resolve, reject) => {
    axios
      .post(EndPoint.GET_TOKEN, data, config)
      .then((res) => {
        console.log('[magic func] new token ====>', res.data.Token);
        setAuthToken(res.data.Token, UserID);
        resolve();
      })
      .catch((error) => {
        reject(error);
      });
  });

  return makeNewTokenPromise;
};

const retryCall = (endPoint, param) => {
  const retryCallPromise = new Promise((resolve, reject) => {
    axios
      .post(endPoint, param)
      .then((res) => {
        resolve(res);
      })
      .catch((error) => {
        reject(error);
      });
  });

  return retryCallPromise;
};
