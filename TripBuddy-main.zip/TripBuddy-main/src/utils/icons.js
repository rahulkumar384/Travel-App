import {requireNativeComponent} from 'react-native';

export default {
  unselectedStar: require('../assets/unselected_star.png'),
  starFilled: require('../assets/star_filled.png'),
  star: require('../assets/Favorites.png'),
  settings: require('../assets/Settings.png'),
  search: require('../assets/Search.png'),
  back: require('../assets/Back.png'),
  backBlack: require('../assets/Back-vblack.png'),
  message: require('../assets/Message.png'),
  messageActive: require('../assets/MessageActive.png'),
  notification: require('../assets/Notification.png'),
  notificationActive: require('../assets/NotificationActive.png'),
  shape: require('../assets/Shape.png'),
  shapeActive: require('../assets/ShapeActive.png'),
  tour: require('../assets/Tour.png'),
  tourActive: require('../assets/TourActive.png'),
  googleLogo: require('../assets/google-logo.png'),
  circuleTick: require('../assets/circuleTick.png'),
  circuleUntick: require('../assets/circuleUntick.png'),
  startPoint: require('../assets/startPoint.png'),
  endPoint: require('../assets/endPoint.png'),
};
