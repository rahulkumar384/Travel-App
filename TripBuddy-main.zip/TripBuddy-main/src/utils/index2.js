import React, {Component} from 'react';
import {Text, View, Image} from 'react-native';
import {WebView} from 'react-native-webview';

//import axios from '../../utils/axios';
import {makeAPICall} from '../../utils/callAPI';
import {connect} from 'react-redux';

import EndPoint from '../../const/config';
import styles from './style';
import Header from '../../components/header';
import icons from '../../utils/icons';
import ActivityIndicators from '../../components/ActivityIndicator';
import CustomAlert from '../../components/CustomAlert/CustomAlert';

//const {width, height} = Dimensions.get('window');

class AboutUs extends Component {
  constructor(props) {
    super(props);

    this.state = {
      AppConfigValue: {},
      isLoading: true,
      isModelOpen: false,
      modelText: '',
    };
  }
  componentDidMount() {
    // create param and adding langage ID
    const params = {
      param: {
        Key: 'AboutApp',
        LanguageID: this.props.currentLanguage.LanguageID,
      },
    };

    console.log(' params ===>', params);

    makeAPICall(EndPoint.CONFIG, params, this.props.singInUser.UserID)
      .then((response) => {
        console.log('response how it work ===>', response.data.Data[0]);
        this.setState({
          AppConfigValue: response.data.Data[0],
          isLoading: false,
        });
      })
      .catch((error) => {
        console.log('error ===> ', error);
        this.setState({
          isModelOpen: true,
          isLoading: false,
          modelText: 'Something went wrong,Please try again later',
        });
      });
  }

  render() {
    return (
      <View style={styles.wrapper}>
        <Header
          navigation={this.props.navigation}
          title={this.props.languageResources.Back}
          fontSize={20}
          textColor="#21C265"
        />

        <CustomAlert
          isVisible={this.state.isModelOpen}
          onPress={() => this.setState({isModelOpen: false})}
          message={this.state.modelText}
        />

        <ActivityIndicators visible={this.state.isLoading} />

        <View style={styles.heading}>
          <Text style={styles.headingtxt}>
            {this.props.languageResources.AboutBasketo}
          </Text>
        </View>
        <View style={styles.imgsty}>
          <Image style={styles.imagesty} source={icons.aboutuslogo} />
        </View>

        <WebView
          source={{
            html: this.state.AppConfigValue.AppConfigValue,
          }}
          style={{
            // width: 200,
            // height: 200,
            // backgroundColor: 'blue',
            flex: 1,
            marginTop: 20,
          }}
        />
      </View>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    languageResources: state.resourcesReducer.resourcesData,
    currentLanguage: state.mainReducer.selectedLangauge,
    singInUser: state.authReducer.singInUserData,
  };
};

export default connect(mapStateToProps)(AboutUs);
