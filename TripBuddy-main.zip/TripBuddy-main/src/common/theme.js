export default {
  primaryColor: '#FFFFFF',
  secondaryColor: '#F9B634',
};
