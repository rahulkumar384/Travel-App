import axios from '../../utils/axios';
import EndPoints from '../../constants/config';

import {
  SET_DATE,
  GET_RESOURCES,
  GET_TOKEN,
  SIGNIN,
  GET_LANGUAGES,
  SIGNOUT,
  USER_COUNTYID,
  UPDATE_USER,
} from '../reducers/app';
import {makeAPICall} from '../../utils/callAPI';

export const setDate = (date) => {
  return async (dispatch) => {
    try {
      dispatch({
        type: SET_DATE,
        date,
      });
    } catch (error) {}
  };
};

export const getToken = () => {
  return async (dispatch) => {
    const response = await axios.post(EndPoints.GET_TOKEN, {}, {});
    const categoryResponse = await response.data;
    console.log('getResources ->resourceResponse', categoryResponse);
    if (categoryResponse.StatusCode == 200) {
      dispatch({
        type: GET_TOKEN,
        payload: {
          token: categoryResponse.Token,
        },
      });
      return Promise.resolve(categoryResponse);
    }
    return Promise.reject(categoryResponse);
  };
};
export const updateUser = (user) => {
  return (dispatch) => {
    dispatch({
      type: UPDATE_USER,
      payload: {
        user,
      },
    });
  };
};
export const getResources = (langId) => {
  return async (dispatch) => {
    const response = await axios.post(
      EndPoints.GET_RESOURCES,
      {
        param: {LanguageID: langId},
      },
      {
        headers: {contentType: 'application/json'},
      },
    );
    const categoryResponse = await response.data;
    console.log('getResources ->resourceResponse', categoryResponse);
    if (categoryResponse.StatusCode == 200) {
      dispatch({
        type: GET_RESOURCES,
        payload: {
          resources: categoryResponse.Data,
        },
      });
      return Promise.resolve(categoryResponse);
    }
    return Promise.reject(categoryResponse);
  };
};

export const getTours = (payload) => {
  return async (dispatch) => {
    const params = {
      param: {
        CountryID: payload.countryId,
        CityID: payload.cityId,
        TourID: payload.tourId,
      },
    };
    const response = await makeAPICall(
      EndPoints.GET_TOURS,
      params,
      payload.userId,
    );
    // alert(JSON.stringify(response.data))
    const categoryResponse = await response.data;
    console.log('getTours ->tourResponse', categoryResponse);
    if (categoryResponse.StatusCode == 200) {
      return Promise.resolve(categoryResponse);
    }
    return Promise.reject(categoryResponse);
  };
};

export const signIn = (payload) => {
  return async (dispatch) => {
    const response = await axios.post(
      EndPoints.SIGNIN,
      {
        param: {
          Email: payload.email,
          Password: payload.password,
        },
      },
      {
        headers: {contentType: 'application/json'},
      },
    );
    const apiResponse = await response.data;
    console.log('signIn -> signInResponse', apiResponse);
    if (apiResponse.StatusCode == 200) {
      dispatch({
        type: SIGNIN,
        payload: {
          token: apiResponse.Token,
          user: apiResponse.Data,
        },
      });
      return Promise.resolve(apiResponse);
    }
    return Promise.reject(apiResponse);
  };
};

export const signUp = (payload) => {
  return async (dispatch) => {
    const response = await axios.post(
      EndPoints.SIGNUP,
      {
        param1: {
          JSON: {
            FullName: payload.fullname,
            EmailAddress: payload.email,
            Password: payload.password,
            PhoneNo: payload.phoneno,
            ProfileUrl: '',
            DateOfBirth: '1994-01-01',
            GenderID: payload.gender,
          },
        },
      },
      {
        headers: {contentType: 'application/json'},
      },
    );
    const apiResponse = await response.data;
    console.log('signUp -> signUpResponse', apiResponse);
    if (apiResponse.StatusCode == 200) {
      dispatch({
        type: SIGNIN,
        payload: {
          token: apiResponse.Token,
          user: apiResponse.Data,
        },
      });
      return Promise.resolve(apiResponse);
    }
    return Promise.reject(apiResponse);
  };
};

export const signIn2 = (payload) => {
  return async (dispatch) => {
    const response = await axios.post(
      EndPoints.SIGNIN,
      {
        param: {
          Email: payload.email,
          FullName: payload.fullName,
          ProviderName: payload.providerName,
          Token: payload.token,
          ProfileUrl: payload.profileUrl,
        },
      },
      {
        headers: {contentType: 'application/json'},
      },
    );
    const apiResponse = await response.data;
    console.log('signIn -> signInResponse', apiResponse);
    if (apiResponse.StatusCode == 200) {
      dispatch({
        type: SIGNIN,
        payload: {
          token: apiResponse.Token,
          user: apiResponse.Data,
        },
      });
      return Promise.resolve(apiResponse);
    }
    return Promise.reject(apiResponse);
  };
};

export const signOut = (payload) => {
  return async (dispatch) => {
    dispatch({
      type: SIGNOUT,
    });
  };
};

export const getLanguages = (payload) => {
  return async (dispatch) => {
    const params = {
      param: {LanguageID: payload.langId},
    };
    const response = await makeAPICall(
      EndPoints.GET_LANGUGAES,
      params,
      payload.userId,
    );
    const categoryResponse = await response.data;
    console.log('getLanguages ->languageResponse', categoryResponse);
    if (categoryResponse.StatusCode == 200) {
      dispatch({
        type: GET_LANGUAGES,
        payload: {
          languages: categoryResponse.Data,
        },
      });
      return Promise.resolve(categoryResponse);
    }
    return Promise.reject(categoryResponse);
  };
};

export const getTourGuides = (payload) => {
  return async (dispatch) => {
    const params = {
      param: {
        TourID: payload.tourId,
        From: payload.from,
        To: payload.to,
        LanguageID: payload.language.toString(),
        GenderID: payload.gender.toString(),
        Rating: payload.rating,
      },
    };
    const response = await makeAPICall(
      EndPoints.GET_TOURGUIDES,
      params,
      payload.userId,
    );
    const categoryResponse = await response.data;
    console.log('getTourGuides ->tourGuides', categoryResponse);
    if (categoryResponse.StatusCode == 200) {
      return Promise.resolve(categoryResponse);
    }
    return Promise.reject(categoryResponse);
  };
};

export const getToursGuideDetails = (payload) => {
  return async (dispatch) => {
    const params = {
      param: {
        TourGuideID: payload.tourguideId,
        CountryID: payload.countryId,
        CityID: payload.cityId,
      },
    };
    const response = await makeAPICall(
      EndPoints.GET_TOURGUIDEDETAILS,
      params,
      payload.userId,
    );
    // alert(JSON.stringify(response.data))
    const categoryResponse = await response.data;
    console.log(
      'getToursGuideDetail ->tourGuideDetailResponse',
      categoryResponse,
    );
    if (categoryResponse.StatusCode == 200) {
      return Promise.resolve(categoryResponse);
    }
    return Promise.reject(categoryResponse);
  };
};

export const getTourGuideInfo = (payload) => {
  return async (dispatch) => {
    const params = {
      param: {
        LanguageID: payload.langId,
        TourGuideID: payload.tourGuideId,
        VenueID: payload.venueId,
      },
    };
    const response = await makeAPICall(
      EndPoints.GET_TOURGUIDEINFO,
      params,
      payload.userId,
    );
    // alert(JSON.stringify(response.data))
    const categoryResponse = await response.data;
    console.log('getTourGuideInfo ->tourGuideInfoResponse', categoryResponse);
    if (categoryResponse.StatusCode == 200) {
      return Promise.resolve(categoryResponse);
    }
    return Promise.reject(categoryResponse);
  };
};

export const postBooking = (payload) => {
  return async (dispatch) => {
    const params = {
      param: {
        TourID: payload.tourId,
        StatusID: payload.statusId,
        TourGuideID: payload.tourGuideId,
        UserID: payload.userId,
        IsFreeTour: payload.isfreetour,
      },
    };
    const response = await makeAPICall(
      EndPoints.POST_BOOKING,
      params,
      payload.userId,
    );
    //alert(JSON.stringify(response.data))
    const categoryResponse = await response.data;
    console.log('postBooking ->postBooking', categoryResponse);
    if (categoryResponse.StatusCode == 200) {
      return Promise.resolve(categoryResponse);
    }
    return Promise.reject(categoryResponse);
  };
};

export const postReview = (payload) => {
  return async (dispatch) => {
    const params = {
      param: {
        Rating: payload.rating,
        Review: payload.review,
        TourGuideID: payload.tourGuideId,
        UserID: payload.userId,
      },
    };
    const response = await makeAPICall(
      EndPoints.POST_REVIEW,
      params,
      payload.userId,
    );
    // alert(JSON.stringify(response.data))
    const categoryResponse = await response.data;
    console.log('postBooking ->postBooking', categoryResponse);
    if (categoryResponse.StatusCode == 200) {
      return Promise.resolve(categoryResponse);
    }
    return Promise.reject(categoryResponse);
  };
};

export const getTourRequest = (payload) => {
  return async (dispatch) => {
    const params = {
      param: {
        TourID: payload.tourId,
        TourGuideID: payload.tourGuideId,
        UserID: payload.userId,
        LanguageID: payload.langId,
      },
    };
    const response = await makeAPICall(
      EndPoints.POST_TOURREQUEST,
      params,
      payload.userId,
    );
    // alert(JSON.stringify(response.data))
    const categoryResponse = await response.data;
    console.log('postTourRequest ->postTourRequest', categoryResponse);
    if (categoryResponse.StatusCode == 200) {
      return Promise.resolve(categoryResponse);
    }
    return Promise.reject(categoryResponse);
  };
};

export const getUpdateTourRequest = (payload) => {
  return async (dispatch) => {
    const params = {
      param: {
        TourBookingID: payload.tourBookingId,
        TourGuideID: payload.tourGuideId,
        StatusID: payload.statusId,
      },
    };
    const response = await makeAPICall(
      EndPoints.POST_UPDATETOURREQUEST,
      params,
      payload.userId,
    );
    // alert(JSON.stringify(response.data))
    const categoryResponse = await response.data;
    console.log(
      'postUpdateTourRequest ->postUpdateTourRequest',
      categoryResponse,
    );
    if (categoryResponse.StatusCode == 200) {
      return Promise.resolve(categoryResponse);
    }
    return Promise.reject(categoryResponse);
  };
};

export const getNotification = (payload) => {
  return async (dispatch) => {
    const params = {
      param: {
        UserID: payload.userId,
        LanguageID: payload.langId,
      },
    };
    const response = await makeAPICall(
      EndPoints.POST_NOTIFICATION,
      params,
      payload.userId,
    );
    // alert(JSON.stringify(response.data))
    const categoryResponse = await response.data;
    console.log('postNotification ->postNotification', categoryResponse);
    if (categoryResponse.StatusCode == 200) {
      return Promise.resolve(categoryResponse);
    }
    return Promise.reject(categoryResponse);
  };
};

// get countries
export const getCountries = (LanguageID) => {
  return async (dispatch) => {
    const response = await axios.post(
      EndPoints.GET_COUNTRIES,
      {
        param: {
          LanguageID: LanguageID,
        },
      },
      {
        headers: {contentType: 'application/json'},
      },
    );
    const apiResponse = await response.data;
    console.log('signIn -> signInResponse', apiResponse);
    if (apiResponse.StatusCode == 200) {
      // dispatch({
      //   type: SIGNIN,
      //   payload: {
      //     token: apiResponse.Token,
      //     user: apiResponse.Data,
      //   },
      // });
      return Promise.resolve(apiResponse);
    }
    return Promise.reject(apiResponse);
  };
};

// update user Country
export const updateCountry = (updateCountryID, userData) => {
  return async (dispatch) => {
    //creating param
    const params = {
      param: {
        UserID: userData.UserID,
        CountryID: updateCountryID,
        CityID: '',
        FullName: '',
        PhoneNo: '',
        EmailAddress: '',
        ProfileUrl: '',
        Bio: '',
      },
    };

    const response = await makeAPICall(
      EndPoints.UPDATE_PROFILE,
      params,
      userData.UserID,
    );
    // alert(JSON.stringify(response.data))
    const updateUserDataResponse = await response.data;
    console.log(
      'updateUserDataResponse ->updateUserDataResponse',
      updateUserDataResponse,
    );
    if (updateUserDataResponse.StatusCode == 200) {
      console.log('enter ===========>');
      // Dispatching action to the reducer
      dispatch({
        type: USER_COUNTYID,
        payload: {
          CountryID: updateCountryID,
        },
      });
      return Promise.resolve(updateUserDataResponse);
    }
    return Promise.reject(updateUserDataResponse);
  };
};

export const getRewardsAndTour = (payload) => {
  return async (dispatch) => {
    const params = {
      param: {
        UserID: payload.userId,
        LanguageID: payload.langId,
        PageNo: payload.pageNo,
        PageSize: payload.pageSize,
      },
    };
    const response = await makeAPICall(
      EndPoints.POST_REWARDTOUR,
      params,
      payload.userId,
    );
    // alert(JSON.stringify(response.data.Data.YourTours))
    console.log('data------->', response.data.Data);
    const categoryResponse = await response.data;

    console.log('postRewards ->postRewards', categoryResponse);
    if (categoryResponse.StatusCode == 200) {
      return Promise.resolve(categoryResponse);
    }
    return Promise.reject(categoryResponse);
  };
};

export const getCities = (payload) => {
  return async (dispatch) => {
    const params = {
      param: {
        CountryID: payload.countryId,
        LanguageID: 1,
      },
    };

    const response = await makeAPICall(
      EndPoints.POST_CITIES,
      params,
      payload.userId,
    );

    const categoryResponse = await response.data;
    // alert(JSON.stringify(categoryResponse))
    console.log('postities ->postCities', categoryResponse);
    if (categoryResponse.StatusCode == 200) {
      return Promise.resolve(categoryResponse);
    }
    return Promise.reject(categoryResponse);
  };
};

export const getmytour = (payload) => {
  return async (dispatch) => {
    const params = {
      param: {
        UserID: payload.userid,
        TourID: payload.tourId,
      },
    };

    const response = await makeAPICall(
      EndPoints.GET_MY_TOUR,
      params,
      payload.userId,
    );

    const categoryResponse = await response.data;
    // alert(JSON.stringify(categoryResponse))
    console.log('postities ->postCities', categoryResponse);
    if (categoryResponse.StatusCode == 200) {
      return Promise.resolve(categoryResponse);
    }
    return Promise.reject(categoryResponse);
  };
};

export const addTour = (payload) => {
  return async (dispatch) => {
    const params = {
      param: {
        UserID: payload.userid,
        VenueID: payload.venueId,
        TourName: payload.tourname,
        TourDate: payload.tourdate,
        Timing: payload.timing,
        TotalPerson: payload.totalperson,
        LatLng: payload.latlng,
        DirectionInfo: payload.directioninfo,
        Amount: payload.amount,
        CurrencyID: payload.currencyid,
      },
    };

    const response = await makeAPICall(
      EndPoints.ADD_TOUR,
      params,
      payload.userId,
    );

    const categoryResponse = await response.data;
    console.log('postStats ->postStats', categoryResponse);
    if (categoryResponse.StatusCode == 200) {
      return Promise.resolve(categoryResponse);
    }
    return Promise.reject(categoryResponse);
  };
};

export const currency = (payload) => {
  return async (dispatch) => {
    const params = {
      param: {
        LanguageID: LanguageID,
      },
    };

    const response = await makeAPICall(
      EndPoints.CURRENCY,
      params,
      payload.userId,
    );

    const categoryResponse = await response.data;
    // alert(JSON.stringify(categoryResponse))
    console.log('currency ->currency', categoryResponse);
    if (categoryResponse.StatusCode == 200) {
      return Promise.resolve(categoryResponse);
    }
    return Promise.reject(categoryResponse);
  };
};

export const getVenue = (payload) => {
  return async (dispatch) => {
    const params = {
      param: {
        CountryID: payload.countryId,
        CityID: payload.cityId,
      },
    };

    const response = await makeAPICall(
      EndPoints.GETVENUES,
      params,
      payload.userId,
    );

    const categoryResponse = await response.data;
    // alert(JSON.stringify(categoryResponse))
    console.log('currency ->currency', categoryResponse);
    if (categoryResponse.StatusCode == 200) {
      return Promise.resolve(categoryResponse);
    }
    return Promise.reject(categoryResponse);
  };
};

export const editTour = (payload) => {
  return async (dispatch) => {
    const params = {
      param: {
        TourID: payload.tourId,
        UserID: payload.userid,
        VenueID: payload.venueId,
        TourName: payload.tourname,
        TourDate: payload.tourdate,
        Timing: payload.timing,
        TotalPerson: payload.totalperson,
        LatLng: payload.latlng,
        DirectionInfo: payload.directioninfo,
        Amount: payload.amount,
        CurrencyID: payload.currencyid,
      },
    };

    const response = await makeAPICall(
      EndPoints.EDITTOUR,
      params,
      payload.userId,
    );

    const categoryResponse = await response.data;
    console.log('postStats ->postStats', categoryResponse);
    if (categoryResponse.StatusCode == 200) {
      return Promise.resolve(categoryResponse);
    }
    return Promise.reject(categoryResponse);
  };
};

export const deleteTour = (payload) => {
  return async (dispatch) => {
    const params = {
      param: {
        TourID: payload.tourId,
        UserID: payload.userId,
      },
    };
    const response = await makeAPICall(
      EndPoints.DELETETOUR,
      params,
      payload.userId,
    );
    // alert(JSON.stringify(response.data))
    const categoryResponse = await response.data;
    console.log(
      'postUpdateTourRequest ->postUpdateTourRequest',
      categoryResponse,
    );
    if (categoryResponse.StatusCode == 200) {
      return Promise.resolve(categoryResponse);
    }
    return Promise.reject(categoryResponse);
  };
};

export const getProfile = (payload) => {
  return async (dispatch) => {
    const params = {
      param: {
        UserID: payload.userId,
      },
    };
    const response = await makeAPICall(
      EndPoints.GETPROFILE,
      params,
      payload.userId,
    );
    // alert(JSON.stringify(response.data))
    const categoryResponse = await response.data;
    console.log('postNotification ->postNotification', categoryResponse);
    if (categoryResponse.StatusCode == 200) {
      return Promise.resolve(categoryResponse);
    }
    return Promise.reject(categoryResponse);
  };
};

export const checkEmail = (payload) => {
  return async (dispatch) => {
    const response = await axios.post(
      EndPoints.CHECKEMAIL,
      {
        param: {
          EmailAddress: payload.email,
        },
      },
      {
        headers: {contentType: 'application/json'},
      },
    );
    const apiResponse = await response.data;
    console.log('signIn -> signInResponse', apiResponse);
    if (apiResponse.StatusCode == 200) {
      return Promise.resolve(apiResponse);
    }
    return Promise.reject(apiResponse);
  };
};

export const forgetPassword = (payload) => {
  return async (dispatch) => {
    const response = await axios.post(
      EndPoints.FORGETPASSWORD,
      {
        param: {
          EmailAddress: payload.email,
        },
      },
      {
        headers: {contentType: 'application/json'},
      },
    );
    const apiResponse = await response.data;
    console.log('signIn -> signInResponse', apiResponse);
    if (apiResponse.StatusCode == 200) {
      return Promise.resolve(apiResponse);
    }
    return Promise.reject(apiResponse);
  };
};
