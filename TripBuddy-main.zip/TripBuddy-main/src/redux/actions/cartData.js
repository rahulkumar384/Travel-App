import {
  ADD_TO_CART,
  REMOVE_FROM_CART,
  ADD_QUANTITY,
  EMPTY_CART,
  ADD_SIZE,
} from '../reducers/cartData';

export const addToCart = (payload) => {
  return async (dispatch) => {
    try {
      dispatch({
        type: ADD_TO_CART,
        payload,
      });
      return Promise.resolve({itemAdded: true});
    } catch (error) {
      console.log('error', error);
      return Promise.reject({itemAdded: false});
    }
  };
};

export const removeFromCart = (id) => {
  return async (dispatch) => {
    try {
      dispatch({
        type: REMOVE_FROM_CART,
        id,
      });
    } catch (error) {
      console.log('error', error);
    }
  };
};

export const addQuantity = (payload) => {
  return async (dispatch) => {
    try {
      dispatch({
        type: ADD_QUANTITY,
        payload,
      });
    } catch (error) {
      console.log('error', error);
    }
  };
};

export const addSize = (payload) => {
  return async (dispatch) => {
    try {
      dispatch({
        type: ADD_SIZE,
        payload,
      });
    } catch (error) {
      console.log('error', error);
    }
  };
};

export const emptyCart = () => {
  return async (dispatch) => {
    try {
      dispatch({
        type: EMPTY_CART,
      });
    } catch (error) {
      console.log('error', error);
    }
  };
};
