export const CONFIRM_ORDER = '/app/confirmOrder';
export const SET_DATE = '/app/setDate';
export const GET_RESOURCES = '/app/getResources';
export const GET_TOKEN = '/app/getToken';
export const SIGNIN = '/app/signIn';
export const SIGNOUT = '/app/signOut';
export const GET_COUNTRIES = '/app/getcountries';
export const GET_LANGUAGES = '/app/getLanguages';
export const USER_COUNTYID = '/app/updateUserCountyID';
export const UPDATE_USER = '/app/updateUser';


const initialState = {
  orderDone: false,
  langId: 2,
  date: '',
  token: '',
  countries: '',
  languages: [],
  isSignedIn: false,
  user: {},
};

const appReducer = (state = initialState, action) => {
  switch (action.type) {
    case SET_DATE:
      return Object.assign({}, state, {
        ...state,
        date: action.date,
      });
    case GET_RESOURCES:
      //  alert(action.payload.resources)
      return Object.assign({}, state, {
        appResources: action.payload.resources,
      });
    case GET_TOKEN:
      return Object.assign({}, state, {
        token: action.payload.token,
      });
    case SIGNIN:
      return Object.assign({}, state, {
        token: action.payload.token,
        user: action.payload.user,
        isSignedIn: true,
      });
    case UPDATE_USER:
      return Object.assign({}, state, {
        user: action.payload.user,
      });
    case SIGNOUT:
      return Object.assign({}, state, {
        isSignedIn: false,
        user: {},
      });
      //  alert(action.payload.resources)
      return Object.assign({}, state, {
        token: action.payload.token,
      });
    case GET_COUNTRIES:
      //  alert(action.payload.resources)
      return Object.assign({}, state, {
        appResources: action.payload.resources,
      });
    case GET_LANGUAGES:
      //  alert(action.payload.resources)
      return Object.assign({}, state, {
        languages: action.payload.languages,
      });
    case USER_COUNTYID:
      console.log('[Redcer] ==>', state.user, ' more  ==>', action.payload.CountryID);
      const tempUser = {...state.user};
      tempUser.CountryID = action.payload.CountryID;
      console.log("dsjkfh sdjh ===>",tempUser)
      return Object.assign({}, state, {user: tempUser});
    default:
      return state;
  }
};
export default appReducer;
