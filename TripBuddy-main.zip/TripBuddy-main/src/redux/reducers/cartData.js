export const ADD_TO_CART = '/cartData/addCart';
export const REMOVE_FROM_CART = '/cartData/removeCart';
export const ADD_QUANTITY = '/cartData/addQuantity';
export const EMPTY_CART = '/cartData/emptyCart';
export const ADD_SIZE = '/cartData/addSize';

const initialState = {
  products: [],
};

const cartDataReducer = (state = initialState, action) => {
  switch (action.type) {
    case ADD_TO_CART:
      
      const ifExist = state.products.filter((element) => {
        return element.ProductID == action.payload.productDetail.ProductID;
      });
      if (ifExist.length > 0) {
        return {
          ...state,
        };
      }
      // merge count with product
      action.payload = {
        ...action.payload.productDetail,
        ...action.payload.details,
      };
      return Object.assign({}, state, {
        ...state,
        products: [...state.products, action.payload],
      });

    case REMOVE_FROM_CART:
      
      var cartItems = state.products;
      const itemNo = state.products.findIndex((element) => {
        if (action.id) return element.ProductID == action.id;
        else return false;
      });
      if (itemNo >= 0) {
        cartItems = state.products.filter((_, i) => i !== itemNo);
      }
      return Object.assign({}, state, {
        ...state,
        products: cartItems,
      });

    case ADD_QUANTITY:
      const products = [...state.products];
      const prodIndex = products.findIndex((x) => x.ProductID === action.payload.id);
      products[prodIndex].quantity = action.payload.quantity;
      return Object.assign({}, state, {
        products: [...products],
      });

    case ADD_SIZE:
      const items = [...state.products];
      const itemIndex = items.findIndex((x) => x.ProductID === action.payload.id);
      items[itemIndex].size = action.payload.size;
      return Object.assign({}, state, {
        products: [...items],
      });

    case EMPTY_CART:
      return Object.assign({}, state, {
        products: [],
      });

    default:
      return state;
  }
};
export default cartDataReducer;
