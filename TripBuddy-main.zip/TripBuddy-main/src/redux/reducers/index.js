import {combineReducers} from 'redux';
import app from './app';
import cartData from './cartData';

export default combineReducers({
  app,
  cartData,
});
