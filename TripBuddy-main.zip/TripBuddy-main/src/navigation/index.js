import 'react-native-gesture-handler';
import React, {useState} from 'react';
//import { RFPercentage, RFValue } from '../screens/Notifications/node_modules/react-native-responsive-fontsize';
import {View, Text, Image, Dimensions} from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import {
  BottomTabBar,
  createBottomTabNavigator,
} from '@react-navigation/bottom-tabs';
import {
  createDrawerNavigator,
  DrawerContentScrollView,
  DrawerItemList,
  DrawerItem,
} from '@react-navigation/drawer';

//ScenicProjectScreens
import Splash from '../screens/Splash';
import SignIn from '../screens/SignIn';
import SignUp from '../screens/SignUp';
import TourDetail from '../screens/TourDetail';
import ChooseGuide from '../screens/ChooseGuide';
import Guide from '../screens/Guide';
import Review from '../screens/Review';
import GuideTourDetail from '../screens/GuideTourDetail/Index';
import Discover from '../screens/Discover';
import Schedule from '../screens/Schedule';
import Notification from '../screens/Notifications';
import Rewards from '../screens/Rewards';
import Profile from '../screens/Profile';
import showProfile from '../screens/showProfile';
import SelectCountry from '../screens/SelectCountry/Index';
import GuideTours from '../screens/GuideTours/Index';
import SelectCountryForGuest from '../screens/SelectCountryForGuest';
import DiscoverForGuest from '../screens/DiscoverForGuest';
import TourDetailForGuest from '../screens/TourDetailForGuest';
import ViewGuideTour from '../screens/ViewGuideTour';
import EditGuideTour from '../screens/EditGuideTour';
import DiscoverForGuest1 from '../screens/DiscoverForGuest1';
import ForgetPassword from '../screens/ForgetPassword';
import Map from '../screens/Map';
import MapForUser from '../screens/MapForUser/Index';

import {Icons} from '../utils';
import {RFValue} from 'react-native-responsive-fontsize';
import SafeArea from 'react-native-safe-area';
const {width, height} = Dimensions.get('window');

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();
const CDrawer = createDrawerNavigator();

const bottomTabs = [
  {
    id: 1,
    name: 'Tour',
    component: User,
    iconActive: Icons.tourActive,
    iconInactive: Icons.tour,
  },
  {
    id: 2,
    name: 'Profile',
    component: Profile,
    iconActive: Icons.shapeActive,
    iconInactive: Icons.shape,
  },
  {
    id: 3,
    name: 'Rewards',
    component: Rewards,
    iconActive: require('../assets/giftboxActive.png'),
    iconInactive: require('../assets/giftboxUnaactive.png'),
  },

  {
    id: 4,
    name: 'Notifications',
    component: Notification,
    iconActive: Icons.notificationActive,
    iconInactive: Icons.notification,
  },
];
const bottomTabs2 = [
  {
    id: 1,
    name: 'Tour',
    component: Schedule,
    iconActive: Icons.tourActive,
    iconInactive: Icons.tour,
  },
  {
    id: 2,
    name: 'Profile',
    component: Profile,
    iconActive: Icons.shapeActive,
    iconInactive: Icons.shape,
  },
  {
    id: 3,
    name: 'GuideTours',
    component: GuideTours,
    iconActive: Icons.messageActive,
    iconInactive: Icons.message,
  },
];
export function User() {
  return (
    <Stack.Navigator
      initialRouteName="Discover"
      screenOptions={{
        headerShown: false,
      }}>
      <Stack.Screen name="TourDetail" component={TourDetail} />
      <Stack.Screen name="ChooseGuide" component={ChooseGuide} />
      <Stack.Screen name="Discover" component={Discover} />
      <Stack.Screen name="Guide" component={Guide} />
      <Stack.Screen name="Review" component={Review} />
    </Stack.Navigator>
  );
}
export function GuideTab() {
  return (
    <Stack.Navigator
      initialRouteName="Schedule"
      screenOptions={{
        headerShown: false,
      }}>
      <Stack.Screen name="GuideTourDetail" component={GuideTourDetail} />
      <Stack.Screen name="Schedule" component={Schedule} />
    </Stack.Navigator>
  );
}
export function AppTabs() {
  const [bottomInsets, setBottomInsets] = useState(0);
  SafeArea.getSafeAreaInsetsForRootView().then((res) =>
    setBottomInsets(res.safeAreaInsets.bottom),
  );
  SafeArea.getSafeAreaInsetsForRootView();

  return (
    <Tab.Navigator
      initialRouteName={'User'}
      tabBarOptions={{
        keyboardHidesTabBar: true,
        style: {
          height: height * 0.1 + bottomInsets,
          borderTopRightRadius: 25,
          borderTopLeftRadius: 25,
          backgroundColor: 'black',
          padding: 8,
          alignItems: 'center',
          position: 'absolute',
        },
      }}>
      {bottomTabs.map((value) => {
        return (
          <Tab.Screen
            name={value.name}
            component={value.component}
            options={{
              tabBarLabel: '',
              tabBarIcon: ({focused}) => {
                if (focused == true) {
                  return (
                    <View
                      style={{
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        width: RFValue(80, width),
                      }}>
                      <Image
                        source={value.iconActive}
                        style={{
                          resizeMode: 'contain',
                          width: 60,
                          height: '80%',
                        }}
                      />
                    </View>
                  );
                } else if (focused == false) {
                  return (
                    <View
                      style={{alignItems: 'center', width: RFValue(80, width)}}>
                      <Image
                        source={value.iconInactive}
                        style={{
                          resizeMode: 'contain',
                          width: 50,
                          height: '70%',
                        }}
                      />
                    </View>
                  );
                }
              },
            }}
          />
        );
      })}
    </Tab.Navigator>
  );
}

export function AppTabs2() {
  const [bottomInsets, setBottomInsets] = useState(0);
  SafeArea.getSafeAreaInsetsForRootView().then((res) => {
    setBottomInsets(res.safeAreaInsets.bottom);
  });
  SafeArea.getSafeAreaInsetsForRootView();
  return (
    <Tab.Navigator
      initialRouteName={'Schedule'}
      tabBarOptions={{
        style: {
          height: height * 0.1 + bottomInsets,
          borderTopRightRadius: 25,
          borderTopLeftRadius: 25,
          backgroundColor: 'black',
          padding: 10,
          alignItems: 'center',
        },
      }}>
      {bottomTabs2.map((value) => {
        return (
          <Tab.Screen
            name={value.name}
            component={value.component}
            options={{
              tabBarLabel: '',
              tabBarIcon: ({focused}) => {
                if (focused == true) {
                  return (
                    <View
                      style={{
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        width: RFValue(80, width),
                      }}>
                      <Image
                        source={value.iconActive}
                        style={{
                          resizeMode: 'contain',
                          width: 60,
                          height: '80%',
                        }}
                      />
                    </View>
                  );
                } else if (focused == false) {
                  return (
                    <View
                      style={{alignItems: 'center', width: RFValue(80, width)}}>
                      <Image
                        source={value.iconInactive}
                        style={{
                          resizeMode: 'contain',
                          width: 50,
                          height: '70%',
                        }}
                      />
                    </View>
                  );
                }
              },
            }}
          />
        );
      })}
    </Tab.Navigator>
  );
}

function Navigation() {
  return (
    <>
      <NavigationContainer>
        <Stack.Navigator
          initialRouteName="Splash"
          screenOptions={{
            headerShown: false,
          }}>
          <Stack.Screen name="Splash" component={Splash} />
          <Stack.Screen name="SignUp" component={SignUp} />
          <Stack.Screen name="SignIn" component={SignIn} />
          <Stack.Screen name="Discover" component={AppTabs} />
          <Stack.Screen name="Schedule" component={AppTabs2} />
          <Stack.Screen name="GuideTourDetail" component={GuideTourDetail} />
          <Stack.Screen name="showProfile" component={showProfile} />
          <Stack.Screen name="SelectCountry" component={SelectCountry} />
          <Stack.Screen name="DiscoverForGuest" component={DiscoverForGuest} />
          <Stack.Screen
            name="SelectCountryForGuest"
            component={SelectCountryForGuest}
          />
          <Stack.Screen
            name="TourDetailForGuest"
            component={TourDetailForGuest}
          />
          <Stack.Screen name="EditGuideTour" component={EditGuideTour} />
          <Stack.Screen name="ViewGuideTour" component={ViewGuideTour} />
          <Stack.Screen
            name="DiscoverForGuest1"
            component={DiscoverForGuest1}
          />
          <Stack.Screen name="ForgetPassword" component={ForgetPassword} />
          <Stack.Screen name="Map" component={Map} />
          <Stack.Screen name="MapForUser" component={MapForUser} />
        </Stack.Navigator>
      </NavigationContainer>
    </>
  );
}

export default Navigation;
