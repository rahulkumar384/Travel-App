import {StyleSheet, Dimensions} from 'react-native';
const {width, height} = Dimensions.get('window');
import { RFPercentage, RFValue } from 'react-native-responsive-fontsize';

export default StyleSheet.create({
   imgStyle:{
       width:'100%',
       height:'100%',
       resizeMode:'contain'
   },
   MarketPlaceUnActive:{
    width:'100%',
    height:'90%',
    resizeMode:'contain',
   
   
},
        tabChilds:{
        width:'20%',
        height:'60%',
  
        },
        tabChilds2:{
          width:'90%',
          height:'120%',
          borderRadius:RFPercentage(20),
        
          },
        tabContainer:{
            alignItems:'center',
            justifyContent:'space-between', backgroundColor:'white',
            width:width,
            height:height*0.08, 
        borderTopLeftRadius:RFPercentage(3),
        borderTopRightRadius:RFPercentage(3),
        paddingLeft:height*0.07,
        paddingRight:height*0.07,
        flexDirection:'row'
      },
        drawerContent: {
          flex: 1,
        },
        userInfoSection: {
          paddingLeft: 15,
          flexDirection:'row'
        },
        title: {
          fontSize: 16,
          marginTop: 3,
          fontWeight: 'bold',
          color: 'white',
        },
        caption: {
          fontSize: 14,
          lineHeight: 14,
        },
        row: {
          marginTop: 20,
          flexDirection: 'row',
          alignItems: 'center',
        },
        section: {
          flexDirection: 'row',
          alignItems: 'center',
          marginRight: 15,
        },
        paragraph: {
          fontWeight: 'bold',
          marginRight: 3,
        },
        drawerSection: {
          marginLeft: width * 0.037,
         
          height: '100%',
        },
        bottomDrawerSection: {
          marginBottom: 15,
          borderTopColor: '#f4f4f4',
          borderTopWidth: 1,
        },
        preference: {
          flexDirection: 'row',
          justifyContent: 'space-between',
          paddingVertical: 12,
          paddingHorizontal: 16,
        },
        Ketologo: {
          width: '100%',
          height: '100%',
        resizeMode:'contain'
        },
      });