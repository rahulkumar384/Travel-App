const _Environments = {
  development: {
    BASE_URL: 'http://110.93.230.117:19026/v1/json',
    DEVELOPMENT_URL: 'http://110.93.230.117:19026/v1/json',
    IMG_URL: 'http://110.93.230.117:19026/v1/json',
    GET_RESOURCES: '/data/get-allresources',
    GET_TOKEN: '/data/get-token',
    GET_TOURS: '/data/tours',
    SIGNIN: '/data/login',
    GET_LANGUGAES: '/data/get-languages',
    GET_TOURGUIDES: '/data/tour-guides',
    GET_TOURGUIDEDETAILS: '/data/tourandtourguides',
    GET_TOURGUIDEINFO: '/data/tour-guide-info',
    POST_BOOKING: '/data/tour-booking',
    POST_REVIEW: '/data/review',
    POST_TOURREQUEST: '/data/tour-requests',
    POST_UPDATETOURREQUEST: '/data/update-tour-request',
    POST_NOTIFICATION: '/data/notification',
    POST_REWARDTOUR: '/data/rewards-tours',
    POST_CITIES: 'data/cities',
    SIGNUP: '/data/register-user',
    GET_CATEGORIES: '/data/get-categories',
    GET_PRODUCTS_BY_CATEGORIES: '/data/get-products-by-category',
    GET_PRODUCT_DETAIL: '/data/get-product-detail',
    CONFIRM_ORDER: '/data/post/cart',
    CONTACT_US: '/data/post/contact-us',
    GET_SHIPMENTS: '/data/get-shipments',
    GET_CITIES: '/data/get-cities',
    GET_MY_TOUR: '/data/get-my-tours',
    ADD_TOUR: '/data/add-tour',
    CURRENCY: '/data/currencies',
    GETVENUES: '/data/venues',
    EDITTOUR: '/data/update-my-tour',
    DELETETOUR: '/data/delete-my-tour',
    GETPROFILE: '/data/get-profile',
    CHECKEMAIL: '/data/check-email',
    FORGETPASSWORD: '/data/forgot-password',

    GET_ALLPRODUCTS: '/data/get-products',
    GET_STORIES: '/data/get-stories',
    POST_STORY: '/data/post/story',
    GET_STORY: '/data/get-story',
    GET_COUNTRIES: '/data/countries',
    UPDATE_PROFILE: '/data/update-profile',
  },
};

function getEnvironment() {
  const platform = 'development';
  return _Environments[platform];
}

const Environment = getEnvironment();
module.exports = Environment;
