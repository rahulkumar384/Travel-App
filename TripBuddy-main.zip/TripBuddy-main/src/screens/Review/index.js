import React, {Component} from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  Image,
  ScrollView,
  Dimensions,
  FlatList,
  TextInput,
} from 'react-native';
import styles from './style';
import Icons from '../../utils/icons';
import LinearGradient from 'react-native-linear-gradient';
const {width, height} = Dimensions.get('window');
import CityFiler from '../../components/CityFilter';
import Header from '../../components/Header';
import icons from '../../utils/icons';
import {postReview} from '../../redux/actions/app';
import {RFValue} from 'react-native-responsive-fontsize';
import {Rating, AirbnbRating} from 'react-native-ratings';
import CustomAlert from '../../components/CustomAlert';
import {connect} from 'react-redux';
import LoaderView from '../../components/Loader';
class Review extends Component {
  constructor() {
    super();

    this.state = {
      review: '',
      loader: false,
      isRefreshing: false,
      alertMsg: '',
      showAlert: false,
      isReviewd: false,
      rating: 1,
    };
  }

  postReview = () => {
    const {params} = this.props.route;
    const guide = params.guide;
    const {user} = this.props;
    this.setState({loader: true});
    const {appResources} = this.props;
    let payload = {
      rating: this.state.rating,
      review: this.state.review,
      tourGuideId: guide.TourGuideID,
      userId: user.UserID,
    };
    //alert(JSON.stringify(payload))
    this.props.postReview(payload).then(
      (response) => {
        if (response.StatusCode == 200) {
          this.setState({
            showAlert: true,
            alertMsg: 'Reviewed Successfully',
            loader: false,
            isReviewd: true,
          });
        } else {
          this.setState({
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };

  render() {
    return (
      <View style={styles.container}>
        <CustomAlert
          isVisible={this.state.showAlert}
          onPress={
            this.state.isReviewd
              ? () => {
                  this.setState({showAlert: false, alertMsg: ''});
                  this.props.navigation.goBack();
                }
              : () => this.setState({showAlert: false, alertMsg: ''})
          }
          message={this.state.alertMsg}
        />
        <LoaderView isVisible={this.state.loader} />
        <LinearGradient
          start={{x: 0, y: 0}}
          end={{x: 1, y: 0}}
          colors={['#FC4F1C', '#F89230', '#F9B434']}
          style={styles.linearGradient}>
          <Header
            navigation={this.props.navigation}
            isLeft={true}
            leftIcon={icons.back}
            navi={() => this.props.navigation.goBack()}
            isBorder={true}
            isHead={true}
            Head={'Reviews'}
          />
        </LinearGradient>
        <View style={styles.mainUpperCont2}>
          <Text style={{fontSize: RFValue(25, height), fontWeight: 'bold'}}>
            Write a Review
          </Text>
        </View>
        <View style={{marginTop: height * 0.05, alignItems: 'center'}}>
          <AirbnbRating
            onFinishRating={(value) => {
              this.setState({rating: value});
            }}
            count={5}
            showRating={false}
            defaultRating={1}
            size={30}
            selectedColor={'#FFAA00'}
          />
          <Text style={{fontSize: RFValue(15, height), color: '#9BA4B3'}}>
            Tap a star to rate!
          </Text>
        </View>

        <TextInput
          style={styles.inputStyle}
          textAlignVertical="top"
          placeholder={'Review'}
          value={this.state.review}
          onChangeText={(text) => this.setState({review: text})}
        />

        <TouchableOpacity style={styles.bookButton} onPress={this.postReview}>
          <Text style={{fontSize: RFValue(18, height), color: 'white'}}>
            Submit Review
          </Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const mapStateToProps = (state) => {
  const {date, langId, user, appResources} = state.app;
  return {date, langId, user, appResources};
};

const mapDispatchToProps = {
  postReview,
};

export default connect(mapStateToProps, mapDispatchToProps)(Review);
