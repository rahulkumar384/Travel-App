import {StyleSheet, Dimensions} from 'react-native';
import theme from '../../common/theme';
const {width, height} = Dimensions.get('window');
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';

export default StyleSheet.create({
  container: {
    height: height,
    width: width,
    backgroundColor: theme.primaryColor,
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  mainUpperCont2: {
    width: '90%',

    marginTop: height * 0.05,
  },
  inputStyle: {
    width: '90%',
    height: height * 0.2,
    backgroundColor: '#F5F5F5',
    padding: height * 0.02,
    borderRadius: 20,
    marginTop: height * 0.05,
  },
  bookButton: {
    width: '80%',
    height: height * 0.07,
    backgroundColor: theme.secondaryColor,
    marginTop: height * 0.04,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
  linearGradient: {
    width: width,
    height: height * 0.1,
    // position: 'absolute',
    top: 0,
    //  zIndex: -1,
  },
});
