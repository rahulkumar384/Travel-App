import React, {Component} from 'react';
import {
  View,
  Text,
  ImageBackground,
  Dimensions,
  Modal,
  TouchableOpacity,
  FlatList,
  Image,
} from 'react-native';

//local import
import styles from './Style';
import LoaderView from '../../components/Loader';
import icons from '../../utils/icons';
import theme from '../../common/theme';

//other
const {width, height} = Dimensions.get('window');

// redux
import {connect} from 'react-redux';
import {getCountries} from '../../redux/actions/app';
import {RFPercentage} from 'react-native-responsive-fontsize';

class SelectCountry extends Component {
  constructor() {
    super();

    this.state = {
      isRefreshing: false,
      alertMsg: '',
      showAlert: false,
      Countries: [],
      loader: false,
      showAlert: false,
      alertMsg: '',
    };
  }

  componentDidMount = () => {
    this.loaddata();
  };

  loaddata = () => {
    this.setState({loader: true});
    const {appResources} = this.props;

    this.props.getCountries((LanguageID = 1)).then(
      (response) => {
        if (response.StatusCode == 200) {
          if (response.Data && response.Data.length > 0) {
            this.setState({
              Countries: response.Data,
              loader: false,
              moreDataLoader: false,
              isRefreshing: false,
            });
          } else {
            this.setState({
              loader: false,
              isRefreshing: false,
            });
          }
        } else {
          this.setState({
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };
  render() {
    return (
      <View style={styles.container}>
        {/** LOADER */}
        <LoaderView isVisible={this.state.loader} />
        <ImageBackground
          source={require('../../assets/Splash.png')}
          style={{height: height, width: width}}
          imageStyle={{resizeMode: 'stretch'}}>
          <View style={styles.centeredView}>
            <View style={styles.lModalView}>
              {/** model main heading start */}
              <View style={styles.openModelTitleView}>
                <Text style={styles.openModelTitle}>Select Country</Text>
              </View>
              <FlatList
                style={{width: '100%'}}
                data={this.state.Countries}
                keyExtractor={(item) => item.value}
                renderItem={({item}) => (
                  <TouchableOpacity
                    style={styles.litstItemView}
                    activeOpacity={10}
                    onPress={() =>
                      this.props.navigation.navigate('DiscoverForGuest', {
                        countries: item,
                      })
                    }>
                    <View style={styles.imgTextContainer}>
                      <Image
                        source={{
                          uri: item.flagUrl,
                        }}
                        resizeMode="contain"
                        style={{width: width * 0.08, height: height * 0.08}}
                      />

                      <Text style={styles.litstItem}>{item.CountryName}</Text>
                    </View>

                    <Image
                      source={icons.circuleUntick}
                      resizeMode="contain"
                      style={{width: width * 0.05, height: height * 0.05}}
                    />
                  </TouchableOpacity>
                )}
              />
              {/** Model countrt end */}
            </View>
          </View>

          <TouchableOpacity
            style={styles.box}
            onPress={() => this.props.navigation.navigate('SignIn')}>
            <Text
              style={{
                fontSize: RFPercentage(2),
                textAlign: 'center',
                color: 'white',
                fontWeight: 'bold',
              }}>
              SIGN IN
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.box}
            onPress={() => this.props.navigation.navigate('SignUp')}>
            <Text
              style={{
                fontSize: RFPercentage(2),
                textAlign: 'center',
                color: 'white',
                fontWeight: 'bold',
              }}>
              REGISTER
            </Text>
          </TouchableOpacity>
        </ImageBackground>
      </View>
    );
  }
}

const mapStateToProps = (state) => {
  const {langId, user} = state.app;
  return {langId, user};
};

const mapDispatchToProps = {
  getCountries,
};
export default connect(mapStateToProps, mapDispatchToProps)(SelectCountry);
