import {StyleSheet, Dimensions} from 'react-native';
import theme from '../../common/theme';
const {width, height} = Dimensions.get('window');
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';

export default StyleSheet.create({
  container: {
    height: height,
    width: width,
    backgroundColor: theme.primaryColor,
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  scrollViewStyle: {
    width,
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingBottom: height * 0.18,
  },

  aboutCont: {
    width: '85%',
    fontSize: width * 0.06,
    alignItems: 'center',
    justifyContent: 'flex-start',
  },

  aboutHeadng: {
    fontSize: width * 0.08,
    fontFamily: 'Product-Sans',
    fontWeight: 'bold',
    color: '#000',
    alignSelf: 'flex-start',
  },

  aboutTxt: {
    fontSize: RFValue(15, height),
    color: '#000',
    alignSelf: 'flex-start',
    //fontFamily: 'Montserrat-Regular',
    marginTop: height * 0.01,
    marginBottom: height * 0.01,
  },
  aboutbox: {
    flexDirection: 'row',
    marginTop: height * 0.02,
    // backgroundColor:'red'
  },
  linearGradient: {
    width: width,
    height: height * 0.1,
    // position: 'absolute',
    top: 0,
    //  zIndex: -1,
  },
});
