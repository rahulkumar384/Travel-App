import React, {Component} from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  Image,
  ScrollView,
  Dimensions,
  ImageBackground,
  Linking,
} from 'react-native';
import styles from './Style';
const {width, height} = Dimensions.get('window');
import Header from '../../components/Header';
import icons from '../../utils/icons';
import theme from '../../common/theme';
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';
import {getResources} from '../../redux/actions/app';
import {connect} from 'react-redux';
import LinearGradient from 'react-native-linear-gradient';

class TourDetail extends Component {
  constructor() {
    super();

    this.state = {
      mon: '',
      date: '',
    };
  }
  months = [
    'JAN',
    'FEB',
    'MAR',
    'APR',
    'MAY',
    'JUN',
    'JUL',
    'AUG',
    'SEP',
    'OCT',
    'NOV',
    'DEC',
  ];

  OpeningMap = () => {
    const {params} = this.props.route;
    const tour = params.tour;
    if (Platform.OS === 'android') {
      Linking.openURL(
        `geo:0,0?q=${tour.Latitude},${tour.Longitude}`,
      ).catch((err) => console.error('An error occurred', err));
    } else {
      Linking.openURL(
        `http://maps.apple.com/?ll=${tour.Latitude},${tour.Longitude}`,
      ).catch((err) => console.error('An error occurred', err));
    }
  };

  render() {
    const {params} = this.props.route;
    const tour = params.tour;
    // alert(JSON.stringify(tour));

    let d = new Date(tour.TourDate);
    var mon = this.months[d.getMonth()];
    var date = d.getDate();
    const {appResources} = this.props;
    const {user} = this.props;
    return (
      <View style={styles.container}>
        <ScrollView
          // style={{height: '100%'}}
          contentContainerStyle={styles.scrollViewStyle}>
          <LinearGradient
            start={{x: 0, y: 0}}
            end={{x: 1, y: 0}}
            colors={['#FC4F1C', '#F89230', '#F9B434']}
            style={styles.linearGradient}>
            <Header
              navigation={this.props.navigation}
              isLeft={true}
              leftIcon={icons.back}
              navi={() => this.props.navigation.goBack()}
              isBorder={true}
              isHead={true}
              Head={'Tour Details'}
            />
          </LinearGradient>
          <ImageBackground
            source={{uri: tour.LogoUrl}}
            imageStyle={{width: width, height: height * 0.33}}
            style={{width: width, height: height, resizeMode: 'stretch'}}>
            <View
              style={{
                width: width * 0.8,
                alignSelf: 'center',
                marginTop: height * 0.25,
                borderRadius: 10,
                backgroundColor: 'white',
                padding: height * 0.02,
                paddingBottom: 0,
                borderBottomLeftRadius: 20,
                borderBottomRightRadius: 20,
                elevation: 10,
                
              }}>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  width: '100%',
                  alignItems: 'center',
                }}>
                <Text style={{fontSize: RFValue(18, height), color: '#FFD700'}}>
                  {tour.TourName}
                </Text>
                <View
                  style={{
                    elevation: 10,
                    alignItems: 'center',
                    backgroundColor: 'white',
                    paddingLeft: height * 0.015,
                    paddingRight: height * 0.015,
                    paddingTop: height * 0.01,
                    paddingBottom: height * 0.01,
                    borderRadius: 2,
                    marginRight: width * 0.02,
                  }}>
                  <Text style={{color: '#AEAEAE'}}>{mon}</Text>
                  <Text
                    style={{
                      fontSize: RFValue(20, height),
                      fontWeight: 'bold',
                      color: theme.secondaryColor,
                    }}>
                    {date}
                  </Text>
                </View>
              </View>

              <View style={styles.aboutbox}>
                <View style={{flexDirection: 'row'}}>
                  <Image
                    style={{
                      resizeMode: 'contain',
                      width: width * 0.1,
                      height: height * 0.04,
                      marginRight: width * 0.03,
                    }}
                    source={require('../../assets/around-the-globe.png')}
                  />
                  <View style={{flexDirection: 'column'}}>
                    <Text
                      style={{
                        fontWeight: 'bold',
                        fontSize: RFValue(15, height),
                      }}>
                      {tour.VenueName}
                    </Text>
                    <Text style={{fontSize: RFValue(11, height)}}>
                      {tour.Timing}
                    </Text>
                  </View>
                </View>
              </View>

              <View style={styles.aboutbox}>
                <Image
                  style={{
                    resizeMode: 'contain',
                    width: width * 0.1,
                    height: height * 0.04,
                    marginRight: width * 0.03,
                  }}
                  source={require('../../assets/member.png')}
                />
                <View>
                  <Text
                    style={{
                      marginTop: height * 0.01,
                      fontWeight: 'bold',
                      fontSize: RFValue(15, height),
                    }}>
                    {tour.TotalPerson} people
                  </Text>
                </View>
              </View>

              <View style={styles.aboutbox}>
                <Image
                  style={{
                    resizeMode: 'contain',
                    width: width * 0.1,
                    height: height * 0.04,
                    marginRight: width * 0.03,
                  }}
                  source={require('../../assets/marker.png')}
                />
                <View>
                  <Text
                    onPress={this.OpeningMap}
                    style={{
                      marginTop: height * 0.01,
                      color: '#FFD700',
                      fontSize: RFValue(15, height),
                    }}>
                    {appResources.GetDirections}
                  </Text>
                </View>
              </View>

              <View style={styles.aboutbox}>
                <Image
                  style={{
                    resizeMode: 'contain',
                    width: width * 0.1,
                    height: height * 0.04,
                    marginRight: width * 0.03,
                  }}
                  source={require('../../assets/cv.png')}
                />
                <View style={{flexDirection: 'column', width: width * 0.6}}>
                  <Text
                    style={{
                      color: 'black',
                      fontWeight: 'bold',
                      fontSize: RFValue(15, height),
                    }}>
                    Tour Description
                  </Text>
                  <Text style={{color: 'black', fontSize: RFValue(11, height)}}>
                    {tour.DirectionInfo}
                  </Text>
                </View>
              </View>
              <TouchableOpacity
                style={{
                  width: width * 0.8,
                  height: height * 0.07,
                  alignSelf: 'center',
                  backgroundColor: theme.secondaryColor,
                  marginTop: height * 0.03,
                  borderBottomEndRadius: 15,
                  borderBottomStartRadius: 15,
                }}
                onPress={() =>
                  this.props.navigation.navigate('ChooseGuide', {
                    tour: tour,
                  })
                }>
                <Text
                  style={{
                    textAlign: 'center',
                    marginTop: height * 0.02,
                    fontSize: RFValue(18, height),
                    color: 'white',
                  }}>
                  BROWSE GUIDE
                </Text>
              </TouchableOpacity>
            </View>
          </ImageBackground>
        </ScrollView>
      </View>
    );
  }
}
const mapStateToProps = (state) => {
  const {date, appResources, user} = state.app;
  return {date, appResources, user};
};

const mapDispatchToProps = {
  getResources,
};

export default connect(mapStateToProps, null)(TourDetail);
