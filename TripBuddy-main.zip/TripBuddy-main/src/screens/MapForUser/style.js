import {StyleSheet, Dimensions} from 'react-native';
import theme from '../../common/theme';
const {width, height} = Dimensions.get('window');
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';

export default StyleSheet.create({
  container: {
    width: width,
    height: height,
    backgroundColor: theme.primaryColor,
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  mapCont: {
    width: '98%',
    height: '67%',
    // marginTop: height * 0.015,
    // backgroundColor: 'red',
  },
  maps: {
    width: '100%',
    height: '100%',
    ...StyleSheet.absoluteFillObject,
  },
  buttonCont: {
    width: width * 0.42,
    height: height * 0.08,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: theme.secondaryColor,
    margin: height * 0.015,
    borderRadius: 35,
  },
  buttonTxt: {
    color: 'black',
    // fontWeight: 'bold',
    fontSize: RFValue(25, height),
  },
 
  CallPolice: {
    width: width * 0.9,
    height: height * 0.08,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: theme.secondaryColor,
    marginTop: height * 0.015,
    alignSelf: 'center',
    borderRadius: 35,
  },
});
