import React, {Component} from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  Image,
  ScrollView,
  Dimensions,
  TextInput,
} from 'react-native';
import styles from './Style';
import Icons from '../../utils/icons';
import ImagePicker from 'react-native-image-crop-picker';
import qs from 'qs';
const {width, height} = Dimensions.get('window');
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';
import Header from '../../components/Header';
import LinearGradient from 'react-native-linear-gradient';
import icons from '../../utils/icons';
import MyProfile from '../../components/Profile';
import Svg, {Ellipse, Circle} from 'react-native-svg';
import {Avatar} from 'react-native-paper';
import CustomAlert from '../../components/CustomAlert';
import {getResources, signOut, updateUser} from '../../redux/actions/app';
import {connect} from 'react-redux';
import configs from '../../constants/config';
import {makeAPICall} from '../../utils/callAPI';
import LoaderView from '../../components/Loader';

class Profile extends Component {
  constructor() {
    super();

    this.state = {alertMsg: '', showAlert: false};
  }
  pressHandler = () => {
    this.props.signOut();
    this.props.navigation.reset({
      index: 0,
      routes: [{name: 'SignIn'}],
    });
  };
  render() {
    const {user} = this.props;
    //alert(JSON.stringify(user));
    console.log('***********************************>', user);
    const {appResources} = this.props;
    return (
      <View style={styles.container}>
        <LoaderView isVisible={this.state.isLoading} />
        <CustomAlert
          isVisible={this.state.showAlert}
          onPress={() =>
            this.setState({showAlert: false, alertMsg: this.state.alertMsg})
          }
          message={this.state.alertMsg}
        />
        <ScrollView
          contentContainerStyle={{
            alignItems: 'center',
            paddingBottom: height * 0.15,
          }}>
          <LinearGradient
            start={{x: 0, y: 0}}
            end={{x: 1, y: 0}}
            colors={['#FC4F1C', '#F89230', '#F9B434']}
            style={styles.linearGradient}>
            <Header
              navigation={this.props.navigation}
              isLeft={true}
              leftIcon={icons.back}
              navi={() => this.props.navigation.goBack()}
              isBorder={true}
              isHead={true}
              Head={'Profile'}
            />
          </LinearGradient>

          <View style={{width: width * 0.9, alignItems: 'center'}}>
            <View style={styles.circle}>
              <View
                style={{width: '100%', height: '100%', position: 'absolute'}}>
                <Svg style={{width: '100%', height: '100%'}}>
                  <Circle cx="50%" cy="50%" r="45%" fill="#EAF6F0" />
                </Svg>
              </View>
              <View
                style={{
                  width: '80%',
                  height: '80%',
                  alignItems: 'center',
                  position: 'absolute',
                  justifyContent: 'center',
                }}>
                <TouchableOpacity
                  onPress={() => {
                    ImagePicker.openPicker({
                      width: 300,
                      height: 400,
                      cropping: true,
                      multiple: false,
                      includeBase64: true,
                    }).then((image) => {
                      let params = qs.stringify({
                        UserID: this.props.user.UserID,
                        ProfileUrl: image.data,
                      });
                      this.setState({isLoading: true});
                      makeAPICall(
                        '/upload-profile-photo',
                        params,
                        this.props.user.UserID,
                        true,
                      )
                        .then((res) => {
                          console.log(res);
                          makeAPICall(
                            '/data/get-profile',
                            {
                              param: {
                                UserID: this.props.user.UserID,
                              },
                            },
                            this.props.id,
                          ).then((resUser) => {
                            if (
                              resUser.data.StatusMessage == 'Success' &&
                              resUser.data.Data
                            ) {
                              this.props.updateUser(resUser.data.Data);
                            }
                          });
                        })
                        .catch((e) => {})
                        .finally(() => {
                          this.setState({isLoading: false});
                        });
                    });
                  }}>
                  {user.ProfileUrl == '' ? (
                    <Avatar.Image
                      size={150}
                      style={{backgroundColor: '#EAF6F0'}}
                      source={require('../../assets/dummypicture.png')}
                    />
                  ) : (
                    <Avatar.Image
                      size={150}
                      style={{backgroundColor: '#EAF6F0'}}
                      source={{uri: user.ProfileUrl}}
                    />
                  )}
                </TouchableOpacity>
              </View>
            </View>

            <View>
              <MyProfile
                name={user.FullName}
                number={user.PhoneNo}
                email={user.EmailAddress}
                id={user.UserID}
                bio={user.Bio}
                user={user}
                setLoading={(val) => this.setState({isLoading: val})}
              />
            </View>
          </View>
          <TouchableOpacity
            style={styles.bookButton}
            onPress={this.pressHandler}>
            <Text style={{fontSize: RFValue(18, height), color: 'white'}}>
              Sign Out
            </Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
    );
  }
}
const mapStateToProps = (state) => {
  const {appResources, token, countries, languages, user} = state.app;
  return {appResources, token, countries, languages, user};
};

const mapDispatchToProps = {
  getResources,
  signOut,
  updateUser,
};

export default connect(mapStateToProps, mapDispatchToProps)(Profile);
