import React, {Component} from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  Dimensions,
  Image,
  FlatList,
  Linking,
} from 'react-native';
import styles from './style';
const {width, height} = Dimensions.get('window');
import Header from '../../components/Header';
import LinearGradient from 'react-native-linear-gradient';
import {getResources, getRewardsAndTour} from '../../redux/actions/app';
import {connect} from 'react-redux';
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';
import theme from '../../common/theme';
import icons from '../../utils/icons';
import CustomAlert from '../../components/CustomAlert';

class About extends Component {
  constructor() {
    super();

    this.state = {
      type: [{name: 'Rewards'}, {name: 'Your Tours'}],
      checked: 0,
      index: 0,
      YourTours: null,
      Rewards: [],
      showAlert: false,
      alertMsg: '',
    };
  }
  typeSelector = (input, index) => {
    this.setState({
      checked: index,
      Head: input.name,
    });
  };
  componentDidMount() {
    this.loadData();

    this.focusListener = this.props.navigation.addListener('focus', () => {
      this.loadData();
      //Put your Data loading function here instead of my this.loadData()
    });
  }

  loadData = () => {
    this.setState({loader: true});
    const {appResources} = this.props;
    const {user} = this.props;
    let payload = {
      userId: user.UserID,
      langId: 1,
      pageNo: 1,
      pageSize: 10,
    };

    this.props.getRewardsAndTour(payload).then(
      (response) => {
        if (response.StatusCode == 200) {
          this.setState({
            YourTours: response.Data.YourTours,
            Rewards: response.Data.Rewards,
            loader: false,
          });
          // alert(JSON.stringify(response.Data.YourTours))
        } else {
          this.setState({
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };

  handleClick = (ul) => {
    Linking.canOpenURL(ul).then((supported) => {
      if (supported) {
        Linking.openURL(ul);
      } else {
        console.log("Don't know how to open URI: " + this.props.url);
      }
    });
  };
  render() {
    const {Rewards} = this.state;
    const {appResources} = this.props;
    const {YourTours} = this.state;
    //alert(JSON.stringify(Rewards));

    return (
      <View style={styles.container}>
        <CustomAlert
          isVisible={this.state.showAlert}
          onPress={() => this.setState({showAlert: false, alertMsg: ''})}
          message={this.state.alertMsg}
        />
        <ScrollView
          contentContainerStyle={styles.scrollViewStyle}
          showsVerticalScrollIndicator={false}>
          <LinearGradient
            start={{x: 0, y: 0}}
            end={{x: 1, y: 0}}
            colors={['#FC4F1C', '#F89230', '#F9B434']}
            style={styles.linearGradient}>
            <Header
              navigation={this.props.navigation}
              isLeft={true}
              leftIcon={icons.back}
              navi={() => this.props.navigation.goBack()}
              isBorder={true}
              isHead={true}
              Head={'Rewards & Your Tours'}
            />
          </LinearGradient>

          <View style={styles.type}>
            {this.state.type.map((input, index) => {
              return this.state.checked == index ? (
                <TouchableOpacity style={styles.aTypeStyleActive}>
                  <Text style={styles.txtStyle}>{input.name}</Text>
                </TouchableOpacity>
              ) : (
                <TouchableOpacity
                  onPress={() => this.typeSelector(input, index)}
                  style={styles.aTypeStyle}>
                  <Text style={styles.txtStyle1}>{input.name}</Text>
                </TouchableOpacity>
              );
            })}
          </View>

          {this.state.checked == 0 ? (
            <View>
              <View
                style={{
                  width: width * 0.9,
                  justifyContent: 'space-between',
                  flexDirection: 'row',
                  alignSelf: 'center',
                  marginTop: height * 0.04,
                  //backgroundColor: 'yellow',
                }}>
                <View
                  style={{
                    width: width * 0.4,
                    height: height * 0.2,
                    borderWidth: 1,
                    borderColor: theme.secondaryColor,
                    //backgroundColor: theme.secondaryColor,
                    borderRadius: 8,
                  }}>
                  <Image
                    style={{
                      width: width * 0.2,
                      height: height * 0.08,
                      resizeMode: 'contain',
                      alignSelf: 'center',
                      marginTop: height * 0.01,
                    }}
                    source={require('../../assets/around-the-globe.png')}
                  />
                  <Text
                    style={{
                      fontSize: height * 0.021,
                      //fontWeight: 'bold',
                      textAlign: 'center',
                      padding: 10,
                    }}>
                    Your Need 5 Rides To Avail Free Ride
                  </Text>
                </View>
                <View
                  style={{
                    width: width * 0.4,
                    height: height * 0.2,
                    borderWidth: 1,
                    borderColor: theme.secondaryColor,
                    //backgroundColor: theme.secondaryColor,
                    borderRadius: 8,
                    alignItems: 'center',
                  }}>
                  <Image
                    style={{
                      width: width * 0.2,
                      height: height * 0.08,
                      resizeMode: 'contain',
                      alignSelf: 'center',
                      marginTop: height * 0.01,
                    }}
                    source={require('../../assets/marker.png')}
                  />
                  <Text
                    style={{
                      fontSize: height * 0.021,
                      //fontWeight: 'bold',
                      textAlign: 'center',
                      padding: 10,
                    }}>
                    You Have Completed{' '}
                    <Text
                      style={{
                        fontSize: height * 0.021,
                        fontWeight: 'bold',
                      }}>
                      {Rewards.Completed}
                    </Text>{' '}
                    Ride.
                  </Text>
                </View>
              </View>
              <View
                style={{
                  width: width * 0.9,
                  height: height * 0.25,
                  alignSelf: 'center',
                  justifyContent: 'center',
                  //backgroundColor: theme.secondaryColor,
                  marginTop: height * 0.05,
                  borderWidth: 1,
                  borderColor: theme.secondaryColor,
                  borderRadius: 8,
                  padding: 15,
                }}>
                <Image
                  style={{
                    width: width * 0.2,
                    height: height * 0.1,
                    resizeMode: 'contain',
                    alignSelf: 'center',
                  }}
                  source={require('../../assets/gift-boxNEw.png')}
                />
                <Text style={{fontSize: height * 0.04, textAlign: 'center'}}>
                  You have {Rewards.UnlockedTours} unlock
                </Text>
              </View>
            </View>
          ) : (
            // <View
            //   style={{
            //     width: width * 0.9,
            //     flexDirection: 'column',
            //     alignSelf: 'center',
            //     // backgroundColor: 'yellow',
            //     justifyContent: 'center',
            //     // paddingBottom: height * 0.12,
            //   }}>
            <FlatList
              data={this.state.YourTours}
              renderItem={({item}) => {
                return (
                  <View style={styles.Main}>
                    <Image
                      source={{uri: item.LogoUrl}}
                      style={styles.imgStyle}
                    />
                    <View style={styles.bottomCont}>
                      <View
                      // style={{
                      //   marginBottom: height * 0.04,
                      //   marginTop: height * 0.04,
                      // }}
                      >
                        <Text
                          style={{
                            //textAlign: 'center',
                            fontSize: RFValue(19, height),
                            fontWeight: '700',
                            color: 'white',
                            //textDecorationLine:'underline'
                          }}>
                          Tour Name:{' '}
                          <Text
                            style={{
                              //textAlign: 'center',
                              fontSize: RFValue(19, height),
                              fontWeight: '100',
                              color: 'white',
                            }}>
                            {item.TourName}
                          </Text>
                        </Text>
                        <Text
                          style={{
                            //textAlign: 'center',
                            fontSize: RFValue(19, height),
                            fontWeight: '700',
                            color: 'white',
                          }}>
                          Tour Guide Name:{' '}
                          <Text
                            style={{
                              //textAlign: 'center',
                              fontSize: RFValue(19, height),
                              fontWeight: '100',
                              color: 'white',
                            }}>
                            {item.TourGuideName}
                          </Text>
                        </Text>
                        <Text
                          style={{
                            //textAlign: 'center',
                            fontSize: RFValue(19, height),
                            fontWeight: '700',
                            color: 'white',
                          }}>
                          Status:{' '}
                          <Text
                            style={{
                              //textAlign: 'center',
                              fontSize: RFValue(19, height),
                              fontWeight: '100',
                              color: 'white',
                            }}>
                            {item.Status}
                          </Text>
                        </Text>
                      </View>
                      {item.AllowChat == true ? (
                        <TouchableOpacity
                          onPress={() => {
                            item.AllowChat == true
                              ? Linking.openURL(
                                  'whatsapp://send?text=hi&phone=' +
                                    item.PhoneNo,
                                )
                              : this.setState({
                                  showAlert: true,
                                  alertMsg: 'Open Chat is not allow',
                                });
                          }}
                          style={{
                            // backgroundColor: '#FF8C00',
                            width: width * 0.2,
                            height: height * 0.05,
                            borderRadius: 9,
                            justifyContent: 'center',
                            alignSelf: 'center',
                            borderWidth: 2,
                            borderColor: 'white',
                          }}>
                          <Text
                            style={{
                              textAlign: 'center',
                              fontSize: height * 0.02,
                              fontWeight: 'bold',
                              color: 'white',
                            }}>
                            Chat
                          </Text>
                        </TouchableOpacity>
                      ) : null}
                      {item.Status == 'Completed' ? (
                        <TouchableOpacity
                          onPress={() =>
                            this.props.navigation.navigate('Review', {
                              guide: item,
                            })
                          }
                          style={{
                            // backgroundColor: '#FF8C00',
                            width: width * 0.2,
                            height: height * 0.05,
                            borderRadius: 9,
                            justifyContent: 'center',
                            alignSelf: 'center',
                            borderWidth: 2,
                            borderColor: 'white',
                          }}>
                          <Text
                            style={{
                              textAlign: 'center',
                              fontSize: height * 0.02,
                              fontWeight: 'bold',
                              color: 'white',
                            }}>
                            Review
                          </Text>
                        </TouchableOpacity>
                      ) : null}
                      {item.Status == 'Started' ? (
                        <TouchableOpacity
                          onPress={() =>
                            this.props.navigation.navigate('MapForUser', {
                              items: item,
                            })
                          }
                          style={{
                            // backgroundColor: '#FF8C00',
                            width: width * 0.2,
                            height: height * 0.05,
                            borderRadius: 9,
                            justifyContent: 'center',
                            alignSelf: 'center',
                            borderWidth: 2,
                            borderColor: 'white',
                          }}>
                          <Text
                            style={{
                              textAlign: 'center',
                              fontSize: height * 0.02,
                              fontWeight: 'bold',
                              color: 'white',
                            }}>
                            Map
                          </Text>
                        </TouchableOpacity>
                      ) : null}
                    </View>
                  </View>
                );
              }}
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.listCont2}
              horizontal={false}
              ListEmptyComponent={
                <View
                  style={{
                    width: width * 0.9,
                    marginTop: height * 0.05,
                    marginBottom: height * 0.05,
                  }}>
                  <Text
                    style={{
                      fontSize: RFValue(20, height),
                      color: 'black',
                      textAlign: 'center',
                    }}>
                    No Notifications !
                  </Text>
                </View>
              }
            />
            // </View>
          )}
        </ScrollView>
      </View>
    );
  }
}

const mapStateToProps = (state) => {
  const {appResources, token, user} = state.app;
  return {appResources, token, user};
};

const mapDispatchToProps = {
  getResources,
  getRewardsAndTour,
};

export default connect(mapStateToProps, mapDispatchToProps)(About);
