import {StyleSheet, Dimensions} from 'react-native';
import theme from '../../common/theme';
const {width, height} = Dimensions.get('window');
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';

export default StyleSheet.create({
  bgImage: {
    height: height,
    width: width,
    justifyContent: 'center',
    alignItems: 'center',
  },

  linearGradient: {
    width: width,
    height: height * 0.1,
    // position: 'absolute',
    top: 0,
    //  zIndex: -1,
  },
  msgText: {
    fontSize: width * 0.04,
    color: '#000',
    //fontFamily: 'Montserrat-Regular',
    textAlign: 'center',
    paddingRight: 20,
    paddingLeft: 20,
  },
  okBox: {
    height: height * 0.05,
    paddingLeft: height * 0.015,
    paddingRight: height * 0.015,
    backgroundColor: theme.thirdColor,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: width * 0.025,
  },
  okText: {
    fontSize: width * 0.04,
    color: '#fff',
    //fontFamily: 'Montserrat-Bold',
  },
  centeredView: {
    height,
    width,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.7)',
  },
  lModalView: {
    height: height * 0.35,
    width: width * 0.6,
    backgroundColor: '#fff',
    justifyContent: 'space-evenly',
    alignItems: 'center',
    borderRadius: width * 0.05,
  },
  logoBox: {
    width: width * 0.3,
    height: height * 0.13,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoStyle: {
    width: '100%',
    height: '100%',
    resizeMode: 'contain',
  },
  container: {
    height: height,
    width: width,
    backgroundColor: theme.primaryColor,
    justifyContent: 'flex-start',
    alignItems: 'center',
    // paddingBottom: height * 0.13,
  },
  scrollViewStyle: {
    justifyContent: 'flex-start',
    alignItems: 'center',
    // paddingBottom: height * 0.13,
    width: width,
  },

  type: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: width * 0.9,
    height: height * 0.07,
    marginBottom: height * 0.01,
    marginTop: height * 0.02,
  },
  aTypeStyle: {
    width: '50%',
    height: '100%',
    borderColor: theme.secondaryColor,
    borderWidth: 1.9,
    backgroundColor: 'transparent',
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: width * 0.015,
  },

  aTypeStyleActive: {
    width: '50%',
    height: '100%',
    backgroundColor: theme.secondaryColor,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: width * 0.015,
  },
  txtStyle: {
    fontSize: RFValue(17, height),
    color: 'white',
    fontWeight: 'bold',
  },
  txtStyle1: {
    fontSize: RFValue(17, height),
    color: theme.secondaryColor,
    fontWeight: 'bold',
  },
  NewPostCont: {
    width: theme.appWidth,

    marginTop: height * 0.03,
    alignItems: 'center',
  },
  Main: {
    height: height * 0.3,
    // backgroundColor:'red',
    width: width * 0.9,
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 10,
    marginTop: height * 0.02,
  },
  bottomCont: {
    backgroundColor: theme.secondaryColor,
    height: height * 0.11,
    width: width * 0.9,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingLeft: height * 0.02,
    paddingRight: height * 0.02,
    borderBottomLeftRadius: 15,
    borderBottomRightRadius: 15,
  },
  imgStyle: {
    width: width * 0.9,
    height: height * 0.2,
    resizeMode: 'cover',
    borderTopRightRadius: 15,
    borderTopLeftRadius: 15,
  },
  listCont2: {
    paddingBottom: height * 0.14,
  },
});
