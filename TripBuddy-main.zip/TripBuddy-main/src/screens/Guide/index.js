import React, {Component} from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  Image,
  ScrollView,
  Dimensions,
  FlatList,
  ImageBackground,
  Modal,
} from 'react-native';
import styles from './style';
import Icons from '../../utils/icons';
import LinearGradient from 'react-native-linear-gradient';
import Header from '../../components/Header';
const {width, height} = Dimensions.get('window');
import ReadMore from 'react-native-read-more-text';

import icons from '../../utils/icons';
import {
  getTourGuideInfo,
  postBooking,
  getRewardsAndTour,
  getProfile,
} from '../../redux/actions/app';
import images from '../../utils/images';
import {Avatar} from 'react-native-paper';
import theme from '../../common/theme';
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';
import CustomAlert from '../../components/CustomAlert';
import {connect} from 'react-redux';
import LoaderView from '../../components/Loader';
class Guide extends Component {
  constructor() {
    super();

    this.state = {
      otherPlaces: [
        {name: 'Venice', image: images.test},
        {name: 'Venice', image: images.test},
        {name: 'adsase', image: images.test},
      ],
      loader: true,
      isRefreshing: false,
      alertMsg: '',
      showAlert: false,
      GuideInfo: '',
      isbooked: false,
      isVisible: false,
      Rewards: [],
      Profile: [],
    };
  }

  componentDidMount = () => {
    this.loadData();
    this.Rewards();
    this.guideProfile();
  };
  componentWillUnmount() {}
  componentWillMount() {
    this.focusListener = this.props.navigation.addListener('focus', () => {
      this.loadData();
      //Put your Data loading function here instead of my this.LoadData()
    });
  }

  _renderTruncatedFooter = (handlePress) => {
    return (
      <Text
        style={{color: 'red', marginTop: 5, fontSize: RFValue(12, height)}}
        onPress={handlePress}>
        Read more
      </Text>
    );
  };

  _renderRevealedFooter = (handlePress) => {
    return (
      <Text
        style={{color: 'red', marginTop: 5, fontSize: RFValue(12, height)}}
        onPress={handlePress}>
        Show less
      </Text>
    );
  };

  Rewards = () => {
    this.setState({loader: true});
    const {appResources} = this.props;
    const {user} = this.props;
    let payload = {
      userId: user.UserID,
      langId: 1,
      pageNo: 1,
      pageSize: 10,
    };

    this.props.getRewardsAndTour(payload).then(
      (response) => {
        if (response.StatusCode == 200) {
          this.setState({
            YourTours: response.Data.YourTours,
            Rewards: response.Data.Rewards,
            loader: false,
          });
        } else {
          this.setState({
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };

  postBooking = () => {
    const {params} = this.props.route;
    const guide = params.guide;
    const tour = params.tour;
    const {user} = this.props;
    this.setState({loader: true});
    const {appResources} = this.props;
    let payload = {
      tourId: tour.TourID,
      statusId: 4,
      tourGuideId: guide.TourGuideID,
      userId: user.UserID,
      isfreetour: false,
    };
    // alert(JSON.stringify(payload))
    this.props
      .postBooking(payload)
      .then(
        (response) => {
          if (response.StatusCode == 200) {
            this.setState({
              showAlert: true,
              alertMsg:
                'Tour has been booked, you will be notified once the Tour Guide accepts the tour',
              loader: false,
              isbooked: true,
            });
          } else {
            this.setState({
              showAlert: true,
              alertMsg:
                appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
            });
          }
        },
        (error) => {
          this.setState({
            loader: false,
            isRefreshing: false,
            showAlert: true,
            alertMsg:
              error && error.message
                ? error.message
                : appResources &&
                  appResources.OopsSomething &&
                  appResources.OopsSomething,
          });
        },
      )
      .finally(() => {
        this.setState({
          isVisible: false,
        });
      });
  };
  postBookingFreeTour = () => {
    const {params} = this.props.route;
    const guide = params.guide;
    const tour = params.tour;
    const {user} = this.props;
    this.setState({loader: true});
    const {appResources} = this.props;
    let payload = {
      tourId: tour.TourID,
      statusId: 4,
      tourGuideId: guide.TourGuideID,
      userId: user.UserID,
      isfreetour: true,
    };
    // alert(JSON.stringify(payload))
    this.props
      .postBooking(payload)
      .then(
        (response) => {
          if (response.StatusCode == 200) {
            this.setState({
              showAlert: true,
              alertMsg:
                'Tour has been booked, you will be notified once the Tour Guide accepts the tour',
              loader: false,
              isbooked: true,
            });
          } else {
            this.setState({
              showAlert: true,
              alertMsg:
                appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
            });
          }
        },
        (error) => {
          this.setState({
            loader: false,
            isRefreshing: false,
            showAlert: true,
            alertMsg:
              error && error.message
                ? error.message
                : appResources &&
                  appResources.OopsSomething &&
                  appResources.OopsSomething,
          });
        },
      )
      .finally(() => {
        this.setState({
          isVisible: false,
        });
      });
  };

  loadData = () => {
    const {params} = this.props.route;
    const guide = params.guide;
    const tour = params.tour;
    // alert(JSON.stringify(guide.TourGuideID));
    this.setState({loader: true});
    const {appResources} = this.props;
    let payload = {
      langId: this.props.langId,
      tourGuideId: guide.TourGuideID,
      venueId: tour.VenueID,
    };

    this.props.getTourGuideInfo(payload).then(
      (response) => {
        if (response.StatusCode == 200) {
          this.setState({
            GuideInfo: response.Data,
            loader: false,
          });
          console.log(JSON.stringify(response.Data));
        } else {
          this.setState({
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };

  guideProfile = () => {
    const {params} = this.props.route;
    const guide = params.guide;
    // alert(JSON.stringify(guide.TourGuideID));
    this.setState({loader: true});
    const {appResources} = this.props;
    let payload = {
      userId: guide.TourGuideID,
    };

    this.props.getProfile(payload).then(
      (response) => {
        if (response.StatusCode == 200) {
          this.setState({
            Profile: response.Data,
            loader: false,
          });
          // alert(JSON.stringify(response.Data));
        } else {
          this.setState({
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };

  render() {
    const {Rewards} = this.state;
    const {params} = this.props.route;
    const {GuideInfo} = this.state;
    const {Profile} = this.state;
    const tour = params.tour;
    const guide = params.guide;

    let image = null;
    //  alert(JSON.stringify(GuideInfo.Pictures));
    if (GuideInfo && GuideInfo.Pictures.length <= 2) {
      image = GuideInfo.Pictures.map((input, index) => {
        return (
          <Image
            style={
              GuideInfo.Pictures.length == 1
                ? styles.onePicture
                : styles.twoPicture
            }
            source={{uri: input.AttachmentUrl}}
          />
        );
      });
    }
    if (GuideInfo && GuideInfo.Pictures.length == 3) {
      image = (
        <View
          style={{
            width: '100%',
            height: '100%',
            flexDirection: 'row',
            justifyContent: 'space-between',
          }}>
          <Image
            style={styles.pictureLeft}
            source={{uri: GuideInfo.Pictures[0].AttachmentUrl}}
          />
          <View style={styles.pictureRightCont}>
            <Image
              style={{
                width: '100%',
                height: '47%',
                borderRadius: 10,
                elevation: 10,
                resizeMode: 'cover',
              }}
              source={{uri: GuideInfo.Pictures[1].AttachmentUrl}}
            />
            <Image
              style={{
                width: '100%',
                height: '47%',
                borderRadius: 10,
                elevation: 10,
              }}
              source={{uri: GuideInfo.Pictures[2].AttachmentUrl}}
            />
          </View>
        </View>
      );
    }
    console.log(JSON.stringify(guide));
    return (
      <View style={{backgroundColor: 'white'}}>
        <Modal
          animationType="fade"
          transparent={true}
          visible={this.state.isVisible}>
          <View style={styles.centeredView}>
            <View style={styles.lModalView}>
              <TouchableOpacity
                style={{
                  width: '20%',
                  height: '18%',
                  top: 5,
                  right: 10,
                  position: 'absolute',
                }}
                onPress={() => this.setState({isVisible: false})}>
                <Image
                  source={require('../../assets/Close.png')}
                  style={{width: '100%', height: '100%', resizeMode: 'contain'}}
                />
              </TouchableOpacity>
              <View style={styles.logoBox}>
                <Image
                  source={require('../../assets/around-the-globe.png')}
                  style={styles.logoStyle}
                />
              </View>
              <Text style={styles.msgText}>Book Tour:</Text>

              <View style={{flexDirection: 'row'}}>
                <TouchableOpacity
                  onPress={this.postBooking}
                  style={styles.okBox}>
                  <Text style={styles.okText}>Book</Text>
                </TouchableOpacity>

                {Rewards.UnlockedTours != 0 ? (
                  <TouchableOpacity
                    onPress={this.postBookingFreeTour}
                    style={styles.okBox}>
                    <Text style={styles.okText}>Free</Text>
                  </TouchableOpacity>
                ) : null}
              </View>
            </View>
          </View>
        </Modal>

        <CustomAlert
          isVisible={this.state.showAlert}
          onPress={
            this.state.isbooked
              ? () => {
                  this.setState({showAlert: false, alertMsg: ''});
                  this.props.navigation.push('Discover');
                }
              : () => this.setState({showAlert: false, alertMsg: ''})
          }
          message={this.state.alertMsg}
        />
        <LoaderView isVisible={this.state.loader} />
        <LinearGradient
          start={{x: 0, y: 0}}
          end={{x: 1, y: 0}}
          colors={['#FC4F1C', '#F89230', '#F9B434']}
          style={styles.linearGradient}>
          <Header
            navigation={this.props.navigation}
            isLeft={true}
            leftIcon={icons.back}
            navi={() => this.props.navigation.goBack()}
            isBorder={true}
            isHead={true}
            Head={'Guide'}
          />
        </LinearGradient>
        <ScrollView contentContainerStyle={styles.container}>
          <ImageBackground
            style={styles.guideImgCont}
            imageStyle={{
              width: '100%',
              height: '100%',
              resizeMode: 'cover',
              // marginTop: height * 0.06,
            }}
            source={{uri: GuideInfo.ProfileUrl}}>
            {/* <TouchableOpacity
              onPress={() => this.props.navigation.goBack()}
              style={{marginBottom: height * 0.23, marginLeft: width * 0.03}}>
              <Image
                style={{
                  // backgroundColor: 'red',
                  resizeMode: 'contain',
                  width: width * 0.07,
                  height: height * 0.05,
                }}
                source={icons.back}
              />
            </TouchableOpacity> */}

            <View style={styles.guideInfo2}></View>
            <View style={styles.guideInfo}>
              <View style={styles.ratingCont}>
                <Image
                  source={icons.star}
                  style={{resizeMode: 'contain', height: '100%', width: '25%'}}
                />
                <Text style={{color: 'white', fontWeight: 'bold'}}>
                  {GuideInfo.Rating}
                </Text>
              </View>
              <Text style={styles.nameStyle}>{GuideInfo.FullName}</Text>

              <ReadMore
                numberOfLines={1}
                renderTruncatedFooter={this._renderTruncatedFooter}
                renderRevealedFooter={this._renderRevealedFooter}
                onReady={this._handleTextReady}>
                <Text style={styles.description}>{Profile.Bio}</Text>
              </ReadMore>
              <View
                style={{
                  width: width * 0.9,
                  // backgroundColor: 'red',
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                }}>
                <View style={styles.peopleCont}>
                  {GuideInfo && GuideInfo.Reviews.length >= 1 ? (
                    <View style={styles.lastCont1}>
                      <View>
                        <Avatar.Image
                          size={25}
                          source={{
                            uri: GuideInfo && GuideInfo.Reviews[0].ProfileUrl,
                          }}
                        />
                      </View>
                    </View>
                  ) : null}

                  <View
                    style={{
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      //  backgroundColor:'blue',
                      marginLeft: width * 0.026,
                    }}>
                    {GuideInfo.Reviews && GuideInfo.Reviews.length > 0 ? (
                      <>
                        <Text
                          style={{
                            color: theme.secondaryColor,
                            fontSize: RFValue(13, height),
                          }}>
                          {GuideInfo.Reviews && GuideInfo.Reviews.length}{' '}
                        </Text>
                        <Text
                          style={{
                            color: 'white',
                            fontSize: RFValue(13, height),
                          }}>
                          {' '}
                          People Reviewed{' '}
                        </Text>
                      </>
                    ) : (
                      <Text
                        style={{color: 'white', fontSize: RFValue(13, height)}}>
                        No reviews yet
                      </Text>
                    )}
                  </View>
                </View>
                <Text style={styles.locationStyle}>
                  Location : {GuideInfo && GuideInfo.CityName}
                </Text>
              </View>
            </View>
          </ImageBackground>
          <View style={styles.mainCont}>
            <View style={styles.mainUpperCont}>
              <Text style={{fontSize: RFValue(20, height), fontWeight: 'bold'}}>
                Pictures
              </Text>
              <TouchableOpacity
                style={styles.review}
                onPress={() =>
                  this.props.navigation.navigate('Review', {
                    guide: guide,
                  })
                }>
                <Text style={{color: 'white'}}>Review</Text>
              </TouchableOpacity>
            </View>
            {image != null ? (
              <View style={styles.pictureCont}>{image}</View>
            ) : (
              <View style={styles.NoDataFound}>
                <Image
                  style={styles.pictureLeft}
                  source={require('../../assets/default.jpg')}
                />
              </View>
            )}
            <View style={styles.mainUpperCont2}>
              <Text style={{fontSize: RFValue(20, height), fontWeight: 'bold'}}>
                Other Places
              </Text>
            </View>
            <View style={{height: height * 0.12, marginTop: height * 0.02}}>
              <FlatList
                showsHorizontalScrollIndicator={false}
                data={GuideInfo.Venues}
                renderItem={({item, index}) => {
                  return (
                    <ImageBackground
                      style={{
                        width: width * 0.28,
                        height: '100%',
                        marginRight: height * 0.02,
                        //backgroundColor:'red'
                      }}
                      imageStyle={{
                        width: '100%',
                        height: '100%',
                        resizeMode: 'stretch',
                        borderRadius: 10,
                      }}
                      source={{uri: item.LogoUrl}}>
                      <Text style={styles.cityText}>{item.CityName}</Text>
                    </ImageBackground>
                  );
                }}
                contentContainerStyle={{
                  height: height * 0.12,
                  flexDirection: 'row',
                }}
                ListEmptyComponent={
                  <View
                    style={{
                      width: width * 0.9,
                      marginTop: height * 0.05,
                      marginBottom: height * 0.05,
                    }}>
                    <Text
                      style={{
                        fontSize: RFValue(20, height),
                        color: 'black',
                        textAlign: 'center',
                      }}>
                      No Record Found !
                    </Text>
                  </View>
                }
                horizontal={true}
              />
            </View>
            <View style={styles.mainUpperCont2}>
              <Text style={{fontSize: RFValue(20, height), fontWeight: 'bold'}}>
                Reviews
              </Text>
            </View>
            {GuideInfo && GuideInfo.Reviews.length >= 1 ? (
              <View style={styles.lastCont}>
                <View style={{width: '15%'}}>
                  <Avatar.Image
                    size={40}
                    source={{uri: GuideInfo && GuideInfo.Reviews[0].ProfileUrl}}
                  />
                </View>
                <ReadMore
                  numberOfLines={1}
                  renderTruncatedFooter={this._renderTruncatedFooter}
                  renderRevealedFooter={this._renderRevealedFooter}
                  onReady={this._handleTextReady}>
                  <Text
                    style={{
                      fontSize: RFValue(16, height),
                      // textAlign: 'right',
                      alignSelf: 'center',
                      // width: width * 0.7,
                    }}>
                    {GuideInfo && GuideInfo.Reviews[0].Review}
                  </Text>
                </ReadMore>
              </View>
            ) : (
              <Text style={{textAlign: 'left', fontSize: RFValue(19, height)}}>
                No reviews yet
              </Text>
            )}

            <TouchableOpacity
              style={styles.bookButton}
              onPress={() => this.setState({isVisible: true})}>
              <Text style={{fontSize: RFValue(18, height), color: 'white'}}>
                Book Guide
              </Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    );
  }
}

const mapStateToProps = (state) => {
  const {date, langId, user, appResources} = state.app;
  return {date, langId, user, appResources};
};

const mapDispatchToProps = {
  getTourGuideInfo,
  postBooking,
  getRewardsAndTour,
  getProfile,
};

export default connect(mapStateToProps, mapDispatchToProps)(Guide);
