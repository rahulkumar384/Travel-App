import React, {Component, useEffect} from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  Image,
  ScrollView,
  Dimensions,
  ImageBackground,
} from 'react-native';
import styles from './style';
import {getResources, getToken, getLanguages} from '../../redux/actions/app';
import {connect} from 'react-redux';
const {width, height} = Dimensions.get('window');
class Splash extends Component {
  Hide = () => {
    if (this.props?.isSignedIn) {
      if (this.props?.user?.IsTourGuide) {
        this.props.navigation.reset({
          index: 0,
          routes: [{name: 'Schedule'}],
        });
      } else {
        this.props.navigation.reset({
          index: 0,
          routes: [{name: 'Discover'}],
        });
      }
    } else {
      this.props.navigation.reset({
        index: 0,
        routes: [{name: 'DiscoverForGuest1'}],
      });
      //this.props.navigation.navigate('SignIn')
    }
  };
  componentDidMount = () => {
    let languageId = this.props.langId ? this.props.langId : 2;
    this.props.getResources(languageId).then(
      (response) => {
        // alert(JSON.stringify(response))
      },
      (error) => {
        //alert(JSON.stringify(error))
      },
    );
    // this.props.getToken();
    //  this.props.getLanguages(this.props.langId);
    this.timer = setTimeout(() => {
      this.Hide();
    }, 2000);
  };
  render() {
    return (
      <View style={styles.container}>
        <ImageBackground
          source={require('../../assets/Splash.png')}
          style={{height: height, width: width}}
          imageStyle={{resizeMode: 'stretch'}}>
          <View
            style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
            <Image
              source={require('../../assets/compass.png')}
              style={{
                width: width * 0.2,
                height: height * 0.1,
                resizeMode: 'contain',
              }}
            />
            <Text
              style={{
                fontSize: width * 0.09,
                fontWeight: 'bold',
                color: 'white',
              }}>
              Trip Buddy
            </Text>
          </View>
        </ImageBackground>
      </View>
    );
  }
}
const mapStateToProps = (state) => {
  const {langId, appResources, isSignedIn, user} = state.app;
  return {langId, appResources, isSignedIn, user};
};
const mapDispatchToProps = {
  getResources,
  getToken,
  getLanguages,
};

export default connect(mapStateToProps, mapDispatchToProps)(Splash);

// import React, {useRef, Component} from 'react';
// import {
//   Text,
//   View,
//   Image,
//   Dimensions,
//   StyleSheet,
//   TouchableOpacity,
//   Linking,
//   PermissionsAndroid,
// } from 'react-native';

// // third party
// import MapView, {Marker} from 'react-native-maps';
// import MapViewDirections from 'react-native-maps-directions';
// import Geolocation from 'react-native-geolocation-service';
// import {connect} from 'react-redux';

// import icons from '../../utils/icons';
// const {width, height} = Dimensions.get('window');
// import styles from './style';
// const GOOGLE_API_KEY = 'AIzaSyB0qsIzkPBrWMOFH8dcz6sfozSEL6kWE7A';
// class App extends Component {
//   constructor(props) {
//     super(props);

//     this.state = {
//       lng: 0,
//       log: 0,
//       location: null,
//       hasLocationPermission: true,
//       // coordinates: [
//       //   {
//       //     latitude: Number(items.StartLatitude),
//       //     longitude: Number(items.StartLongitude),
//       //   },
//       //   {
//       //     latitude: Number(items.EndLatitude),
//       //     longitude: Number(items.EndLongitude),
//       //   },
//       // ],
//     };
//     // this.mapView = null;
//   }
//   requestPermissions = async () => {
//     if (Platform.OS === 'android') {
//       const granted = await PermissionsAndroid.request(
//         PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
//       );
//       if (granted === PermissionsAndroid.RESULTS.GRANTED) {
//         this.location();
//       }
//     }
//   };

//   location = () => {
//     Geolocation.getCurrentPosition(
//       (position) => {
//         console.log(position);

//         this.setState({
//           lng: position.coords.latitude,
//           log: position.coords.longitude,
//         });
//         // alert(JSON.stringify(position.coords.latitude));
//       },
//       (error) => {
//         // See error code charts below.
//         console.log(error.code, error.message);
//       },
//       {enableHighAccuracy: true, timeout: 15000, maximumAge: 10000},
//     );
//   };
//   componentDidMount = () => {
//     this.requestPermissions();
//   };

//   render() {
//     alert(JSON.stringify(this.state.log));
//     return (
//       <View style={{width: width, height: height}}>
//         <View style={styles.mapCont}>
//           <MapView
//             style={styles.maps}
//             initialRegion={{
//               latitude: this.state.lng,
//               longitude: this.state.log,
//               latitudeDelta: 0.005,
//               longitudeDelta: 0.005,
//             }}>
//             <Marker
//               coordinate={{
//                 latitude: this.state.lng,
//                 longitude: this.state.log,
//               }}>
//               <Image
//                 source={icons.startPoint}
//                 style={{height: 35, width: 35, resizeMode: 'contain'}}
//               />
//             </Marker>
//             {/* <MapViewDirections
//             origin={this.state.coordinates[0]}
//             destination={this.state.coordinates[1]}
//             apikey={GOOGLE_API_KEY} // insert your API Key here
//             strokeWidth={4}
//             strokeColor="#111111"
//             optimizeWaypoints={true}
//           />
//           <Marker coordinate={this.state.coordinates[0]}>
//             <Image
//               source={icons.startPoint}
//               style={{height: 35, width: 35, resizeMode: 'contain'}}
//             />
//           </Marker>
//           <Marker coordinate={this.state.coordinates[1]}>
//             <Image
//               source={icons.endPoint}
//               style={{height: 35, width: 35, resizeMode: 'contain'}}
//             />
//           </Marker> */}
//           </MapView>
//         </View>
//       </View>
//     );
//   }
// }

// export default App;

// import React, {useState} from 'react';
// import {View, Image, Text, Dimensions} from 'react-native';

// const {width, height} = Dimensions.get('window');

// Splash = () => {
//   return (
//     <View style={{width: width, height: height}}>
//       <View
//         style={{
//           width: width,
//           height: height * 0.13,
//           backgroundColor: 'red',
//           flexDirection: 'row',
//           justifyContent: 'space-between',
//           alignItems: 'center',
//         }}>
//         <Image
//           style={{
//             width: width * 0.08,
//             height: height * 0.08,
//             resizeMode: 'contain',
//           }}
//           source={require('../../assets/image.webp')}
//         />
//         {/* <Text style={{fontSize: width * 0.04}}>Hello</Text> */}
//         <Text style={{fontSize: width * 0.04}}>Hello</Text>
//         <Text style={{fontSize: width * 0.04}}>Hello</Text>
//       </View>
//       {/* <Image
//         style={{
//           width: width * 0.3,
//           height: height * 0.3,
//           alignSelf: 'center',
//           resizeMode: 'contain',
//         }}
//         source={require('../../assets/image.webp')}
//       /> */}
//     </View>
//   );
// };

// export default Splash;
