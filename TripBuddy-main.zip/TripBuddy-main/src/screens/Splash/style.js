import {StyleSheet, Dimensions} from 'react-native';
import theme from '../../common/theme';
const {width, height} = Dimensions.get('window');
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';

export default StyleSheet.create({
  container: {
    height: height,
    width: width,
    backgroundColor: theme.primaryColor,
    // justifyContent: 'flex-start',
    // alignItems: 'center',
  },
  maps: {
    width: '100%',
    height: '100%',
    ...StyleSheet.absoluteFillObject,
  },
  mapCont: {
    width: '98%',
    height: '67%',
    // marginTop: height * 0.015,
    // backgroundColor: 'red',
  },
});
