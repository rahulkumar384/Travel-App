import {StyleSheet, Dimensions} from 'react-native';
import theme from '../../common/theme';
const {width, height} = Dimensions.get('window');
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';

export default StyleSheet.create({
  container: {
    height: height,
    width: width,
    //backgroundColor: 'red',
    justifyContent: 'flex-start',
    alignItems: 'center',
    //paddingBottom: height * 0.19
  },
  scrollViewStyle: {
    width,
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingBottom: height * 0.15,
  },
  inputFields: {
    width: '80%',
    // backgroundColor: 'blue',
    height: height * 0.085,
    //borderEndWidth:1,
    borderBottomWidth: 1,
    borderBottomColor: 'white',
    fontSize: RFValue(18, height),
    color: '#000',
    //paddingHorizontal: width * 0.05,
    marginTop: height * 0.02,
    flexDirection: 'row',
  },
  inputFields1: {
    width: '80%',
    marginTop: height * 0.01,
    // backgroundColor: 'blue',
  },
  bttn: {
    marginTop: height * 0.02,
    backgroundColor: 'white',
    width: width * 0.8,
    height: height * 0.07,
    alignSelf: 'center',
    justifyContent: 'center',
  },
  back: {
    marginTop: height * 0.02,
    backgroundColor: 'transparent',
    width: width * 0.2,
    height: height * 0.04,
    alignSelf: 'center',
    justifyContent: 'center',
  },
  imageStyle: {
    //backgroundColor:'red',
    resizeMode: 'contain',
    width: width * 0.07,
    height: height * 0.04,
    // marginTop: height * 0.02,
    alignSelf: 'center',
    marginRight: width * 0.02,
  },
});
