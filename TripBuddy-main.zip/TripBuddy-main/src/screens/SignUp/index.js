import React, {Component} from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  Image,
  ScrollView,
  Dimensions,
  ImageBackground,
  TextInput,
} from 'react-native';
import styles from './style';
import {RFValue} from 'react-native-responsive-fontsize';

import {getResources, signUp} from '../../redux/actions/app';
import DropDownPicker from 'react-native-dropdown-picker';
import {connect} from 'react-redux';
const {width, height} = Dimensions.get('window');
import CustomAlert from '../../components/CustomAlert';
import LoaderView from '../../components/Loader';
import ValidationComponent from 'react-native-form-validator';
import ImagePicker from 'react-native-image-crop-picker';
import ImgToBase64 from 'react-native-image-base64';

class SignUp extends ValidationComponent {
  constructor(props) {
    super(props);
    this.state = {
      name: '',
      email: '',
      password: '',
      gender: '',
      phone: '',
      //photo: '',
      data: null,
      loader: false,
      isRefreshing: false,
      alertMsg: '',
      showAlert: false,
    };
  }

 
  handleName = (text) => {
    this.setState({name: text});
  };
  handleEmail = (text) => {
    this.setState({email: text});
  };
  handlePassword = (text) => {
    this.setState({password: text});
  };
  handlePhone = (text) => {
    this.setState({phone: text});
  };

  signUp = () => {
    if (
      // !this.state.photo ||
      !this.state.name ||
      !this.state.email ||
      !this.state.password ||
      !this.state.phone
    ) {
      return this.setState({
        showAlert: true,
        alertMsg: 'Please Enter All Field',
      });
    } else {
      this.setState({loader: true});
      const {appResources} = this.props;
      let payload = {
        fullname: this.state.name,
        email: this.state.email,
        password: this.state.password,
        phoneno: this.state.phone,
        gender: 1,
        // profileurl: this.state.photo,
      };
      this.props.signUp(payload).then(
        (response) => {
          if (response.StatusCode == 200) {
            if (response.Token) {
              this.setState({
                loader: false,
                showAlert: true,
                alertMsg: 'Successfull!',
              });

              if (response.Data != null) {
                this.props.navigation.reset({
                  index: 0,
                  routes: [{name: 'SelectCountry'}],
                });
              }
            } else {
              this.setState({
                loader: false,
                showAlert: true,
                alertMsg: 'wrong credentials',
              });
            }
          } else {
            this.setState({
              showAlert: true,
              alertMsg:
                appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
            });
          }
        },
        (error) => {
          this.setState({
            loader: false,
            isRefreshing: false,
            showAlert: true,
            alertMsg: 'Email Already Registered',
          });
        },
      );
    }
  };

  render() {
    const {appResources, token} = this.props;
    console.log(token);
    return (
      <View style={styles.container}>
        <CustomAlert
          isVisible={this.state.showAlert}
          onPress={() => this.setState({showAlert: false, alertMsg: ''})}
          message={this.state.alertMsg}
        />
        <LoaderView isVisible={this.state.loader} />
        <ImageBackground
          source={require('../../assets/Signin.png')}
          style={{height: height, width: width}}
          imageStyle={{resizeMode: 'stretch'}}>
          <ScrollView
            keyboardDismissMode={true}
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={styles.scrollViewStyle}>
            <View style={{alignItems: 'center', marginTop: height * 0.27}}>
              <Text
                style={{
                  fontSize: RFValue(40, height),
                  fontWeight: 'bold',
                  color: 'white',
                }}>
               Trip Buddy
              </Text>
              <Text
                style={{
                  fontSize: RFValue(20, height),
                  fontWeight: 'normal',
                  color: 'white',
                  marginTop: height * 0.02,
                }}>
                Book Guide
              </Text>
            </View>

            <View style={{alignItems: 'center'}}>
              <View style={styles.inputFields}>
                <Image
                  source={require('../../assets/profile.png')}
                  style={styles.imageStyle}
                />
                <TextInput
                  placeholder={'Full Name'}
                  onChangeText={this.handleName}
                  style={[
                    {
                      height: height * 0.0815,
                      width: width * 0.72,
                      color: 'white',
                      //backgroundColor:'red'
                    },
                  ]}
                  placeholderTextColor="white"
                  //keyboardType={'email-address'}
                />
              </View>
              <View style={styles.inputFields}>
                <Image
                  source={require('../../assets/user.png')}
                  style={styles.imageStyle}
                />
                <TextInput
                  placeholder={'Email-Address'}
                  onChangeText={this.handleEmail}
                  style={[
                    {
                      height: height * 0.0815,
                      width: width * 0.72,
                      color: 'white',
                      //backgroundColor:'red'
                    },
                  ]}
                  placeholderTextColor="white"
                  keyboardType={'email-address'}
                />
              </View>

              <View style={styles.inputFields}>
                <Image
                  source={require('../../assets/lock.png')}
                  style={styles.imageStyle}
                />
                <TextInput
                  placeholder={'Password'}
                  secureTextEntry={true}
                  onChangeText={this.handlePassword}
                  style={[
                    {
                      height: height * 0.0815,
                      width: width * 0.72,
                      color: 'white',
                    },
                  ]}
                  placeholderTextColor="white"
                />
              </View>

              <View style={styles.inputFields}>
                <Image
                  source={require('../../assets/phoneNNo.png')}
                  style={styles.imageStyle}
                />
                <TextInput
                  maxLength={15}
                  placeholder={'Phone Number'}
                  onChangeText={this.handlePhone}
                  style={[
                    {
                      height: height * 0.0815,
                      width: width * 0.72,
                      color: 'white',
                      //backgroundColor:'red'
                    },
                  ]}
                  placeholderTextColor="white"
                  keyboardType={'number-pad'}
                />
              </View>

              <TouchableOpacity style={styles.bttn} onPress={this.signUp}>
                <Text
                  style={{
                    textAlign: 'center',
                    alignContent: 'center',
                    fontSize: RFValue(17, height),
                    fontWeight: '300',
                  }}>
                  Sign Up
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.back}
                onPress={() => this.props.navigation.goBack()}>
                <Text
                  style={{
                    textAlign: 'center',
                    alignContent: 'center',
                    fontSize: RFValue(15, height),
                    color: 'white',
                  }}>
                  Back
                </Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </ImageBackground>
      </View>
    );
  }
}

const mapStateToProps = (state) => {
  const {langId, appResources, token} = state.app;
  return {langId, appResources, token};
};

const mapDispatchToProps = {
  getResources,
  signUp,
};

export default connect(mapStateToProps, mapDispatchToProps)(SignUp);
