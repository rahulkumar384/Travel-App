import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  ImageBackground,
  Dimensions,
  Modal,
  TouchableOpacity,
  FlatList,
  Image,
} from 'react-native';

//local import
import styles from './style';
import LoaderView from '../../components/Loader';
import icons from '../../utils/icons';

//other
const {width, height} = Dimensions.get('window');

// redux
import {connect} from 'react-redux';
import {getCountries, updateCountry} from '../../redux/actions/app';

function SelectCountry(props) {
  const [loader, setloader] = useState(false);
  const [isModelOpen, setisModelOpen] = useState(false);
  const [countries, setcountries] = useState([]);
  //CDM
  useEffect(() => {
    //console.log('CMD props', props);
    //alert(JSON.stringify(props.user));
    // loader state
    setloader(true);
    setisModelOpen(false);
    props.getCountries(props.langId).then((response) => {
      //console.log('lol ==>', response);
      const tempCountryArr = response.Data.map((singleCountry) => {
        return {
          label: singleCountry.CountryName,
          value: singleCountry.CountryID,
          flagUrl: singleCountry.flagUrl,
        };
      });

      //CL the transfrom array
      //console.log('Transfrom array ==>', tempCountryArr);
      setcountries(tempCountryArr);
      setloader(false);
      setisModelOpen(true);
    });
  }, []);

  // handle select country
  const handleCountry = (updateCountryID) => {
    //setting loader
    setloader(true);

    //making API call for update country
    props.updateCountry(updateCountryID, props.user).then((response) => {
      //console.log('response update ===>', response);
      props.navigation.navigate('Discover');
      setloader(false);
      setisModelOpen(false);
    });
  };

  return (
    <View style={styles.container}>
      {/** LOADER */}
      <LoaderView isVisible={loader} />
      <ImageBackground
        source={require('../../assets/Splash.png')}
        style={{height: height, width: width}}
        imageStyle={{resizeMode: 'stretch'}}>
        <Modal transparent={true} visible={isModelOpen}>
          <TouchableOpacity style={styles.centeredView}>
            <View style={styles.lModalView}>
              {/** model main heading start */}
              <View style={styles.openModelTitleView}>
                <Text style={styles.openModelTitle}>Select Country</Text>
              </View>
              {/** model main heading end */}

              {/** Model countrt start */}
              <FlatList
                style={{width: '100%'}}
                data={countries}
                keyExtractor={(item) => item.value}
                renderItem={({item, index, separators}) => (
                  <TouchableOpacity
                    style={styles.litstItemView}
                    activeOpacity={10}
                    onPress={() => handleCountry(item.value)}>
                    <View style={styles.imgTextContainer}>
                      <Image
                        source={{
                          uri: item.flagUrl,
                        }}
                        resizeMode="contain"
                        style={{width: width * 0.08, height: height * 0.08}}
                      />

                      <Text style={styles.litstItem}>{item.label}</Text>
                    </View>

                    <Image
                      source={icons.circuleUntick}
                      resizeMode="contain"
                      style={{width: width * 0.05, height: height * 0.05}}
                    />
                  </TouchableOpacity>
                )}
              />
              {/** Model countrt end */}
            </View>
          </TouchableOpacity>
        </Modal>
      </ImageBackground>
    </View>
  );
}

const mapStateToProps = (state) => {
  const {langId, user} = state.app;
  return {langId, user};
};

const mapDispatchToProps = {
  getCountries,
  updateCountry,
};
export default connect(mapStateToProps, mapDispatchToProps)(SelectCountry);
