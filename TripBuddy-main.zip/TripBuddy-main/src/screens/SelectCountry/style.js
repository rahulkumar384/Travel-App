import {StyleSheet, Dimensions} from 'react-native';
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';

const {width, height} = Dimensions.get('window');

export default StyleSheet.create({
  container: {
    height: height,
    width: width,
  },
  centeredView: {
    height,
    width,
    justifyContent: 'center',
    alignItems: 'center',
    //backgroundColor: 'rgba(0,0,0,0.7)',
  },
  lModalView: {
    height: height * 0.43, //height * 0.262
    width: '75%',
    backgroundColor: 'white',
    //justifyContent: 'space-evenly',
    alignItems: 'center',
    borderRadius: width * 0.03,
    overflow: 'hidden',
  },
  openModelTitleView: {
    marginTop: height * 0.03,
    paddingBottom: height * 0.03,
    width: width,
    justifyContent: 'center',
    alignItems: 'center',
    //backgroundColor: 'red',
    borderBottomColor: '#eee',
    borderBottomWidth: width * 0.003,
  },
  openModelTitle: {
    fontSize: RFValue(15, height),
    fontWeight: 'bold',
    color: '#616161',
  },
  litstItemView: {
    //backgroundColor: 'red',
    width: '100%',
    height: height * 0.08,

    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomColor: '#eee',
    borderBottomWidth: width * 0.001,
    padding: width * 0.08,
    paddingLeft: width * 0.04,
  },
  imgTextContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  litstItem: {
    height: 20,
    marginLeft: width * 0.04,
    fontSize: RFValue(15, height),
    //backgroundColor:"red",
    color: '#616161',
  },
});
