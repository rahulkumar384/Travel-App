import React, {useRef, Component} from 'react';
import {
  Text,
  View,
  Image,
  Dimensions,
  StyleSheet,
  TouchableOpacity,
  Linking,
} from 'react-native';

// third party
import MapView, {Marker} from 'react-native-maps';
import MapViewDirections from 'react-native-maps-directions';
import LinearGradient from 'react-native-linear-gradient';
import {getUpdateTourRequest} from '../../redux/actions/app';
import {connect} from 'react-redux';

const {width, height} = Dimensions.get('window');

// local
import Header from '../../components/Header';

import styles from './style';
import icons from '../../utils/icons';

const GOOGLE_API_KEY = 'AIzaSyBLCP-eIampi_rzlupQY5g5-lD2DDovrkQ';
class App extends Component {
  constructor(props) {
    super(props);
    const {params} = this.props.route;
    const items = params.items;
    this.state = {
      isVisible: true,
      coordinates: [
        {
          latitude: Number(items.StartLatitude),
          longitude: Number(items.StartLongitude),
        },
        {
          latitude: Number(items.EndLatitude),
          longitude: Number(items.EndLongitude),
        },
      ],
    };
    this.mapView = null;
  }

  onPress = (status, tourBookingId) => {
    let payload = {
      tourBookingId: tourBookingId,
      tourGuideId: this.props.user.UserID,
      statusId: status,
    };
    this.props.getUpdateTourRequest(payload).then(
      (response) => {
        if (response.StatusCode == 200) {
          if (response.Data && response.Data.length > 0) {
            this.setState({loader: false, isVisible: false});
          } else {
            this.setState({
              loader: false,
              isRefreshing: false,
            });
          }
        } else {
          this.setState({
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };
  DoubleE = (status, tourBookingId) => {
    let payload = {
      tourBookingId: tourBookingId,
      tourGuideId: this.props.user.UserID,
      statusId: status,
    };
    this.props.getUpdateTourRequest(payload).then(
      (response) => {
        if (response.StatusCode == 200) {
          if (response.Data && response.Data.length > 0) {
            this.props.navigation.navigate('Schedule');
          } else {
            this.setState({
              loader: false,
              isRefreshing: false,
            });
          }
        } else {
          this.setState({
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };
  render() {
    const {params} = this.props.route;
    const items = params.items;
    // alert(JSON.stringify(this.props.user.UserID));
    return (
      <View style={styles.container}>
        <LinearGradient
          start={{x: 0, y: 0}}
          end={{x: 1, y: 0}}
          colors={['#FC4F1C', '#F89230', '#F9B434']}
          style={styles.linearGradient}>
          <Header
            navigation={this.props.navigation}
            isLeft={true}
            leftIcon={icons.back}
            navi={() => this.props.navigation.goBack()}
            isBorder={true}
            isHead={true}
            Head="Tour Route"
          />
        </LinearGradient>
        {/* map cont */}
        <View style={styles.mapCont}>
          <MapView
            style={styles.maps}
            initialRegion={{
              latitude: this.state.coordinates[0].latitude,
              longitude: this.state.coordinates[0].longitude,
              latitudeDelta: 0.005,
              longitudeDelta: 0.005,
            }}>
            <MapViewDirections
              origin={this.state.coordinates[0]}
              destination={this.state.coordinates[1]}
              apikey={GOOGLE_API_KEY} // insert your API Key here
              strokeWidth={4}
              strokeColor="#111111"
              optimizeWaypoints={true}
            />
            <Marker coordinate={this.state.coordinates[0]}>
              <Image
                source={icons.startPoint}
                style={{height: 35, width: 35, resizeMode: 'contain'}}
              />
            </Marker>
            <Marker coordinate={this.state.coordinates[1]}>
              <Image
                source={icons.endPoint}
                style={{height: 35, width: 35, resizeMode: 'contain'}}
              />
            </Marker>
          </MapView>
        </View>

        {this.state.isVisible == true ? (
          <TouchableOpacity
            onPress={() => this.onPress(8, items.TourBookingID)}
            style={styles.Start}>
            <Text style={styles.buttonTxt}>Start</Text>
          </TouchableOpacity>
        ) : (
          <View>
            <View style={styles.ViewFor}>
              <TouchableOpacity
                onPress={() => this.DoubleE(10, items.TourBookingID)}
                style={styles.buttonCont}>
                <Text style={styles.buttonTxt}>Emergency</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => this.DoubleE(10, items.TourBookingID)}
                style={styles.buttonCont}>
                <Text style={styles.buttonTxt}>END</Text>
              </TouchableOpacity>
            </View>

            <TouchableOpacity
              onPress={() => {
                Linking.openURL('tel:999');
              }}
              style={styles.CallPolice}>
              <Text style={styles.buttonTxt}>Call Police</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
    );
  }
}

const mapStateToProps = (state) => {
  const {date, langId, user, appResources} = state.app;
  return {date, langId, user, appResources};
};

const mapDispatchToProps = {
  getUpdateTourRequest,
};

export default connect(mapStateToProps, mapDispatchToProps)(App);

// import React, {useState, useEffect} from 'react';
// import {StyleSheet, View, Dimensions} from 'react-native';
// import MapView, {Marker} from 'react-native-maps';
// import MapViewDirections from 'react-native-maps-directions';
// const GOOGLE_API_KEY = 'AIzaSyB0qsIzkPBrWMOFH8dcz6sfozSEL6kWE7A';

// const App = (props) => {
//   console.log('props', props.route.params.items.StartLatitude);
//   useEffect(() => {
//     setCooridinates([
//       {
//         latitude: Number(props.route.params.items.StartLatitude),
//         longitude: Number(props.route.params.items.StartLongitude),
//       },
//       {
//         latitude: Number(props.route.params.items.EndLatitude),
//         longitude: Number(props.route.params.items.EndLongitude),
//       },
//     ]);
//   }, []);
//   const [coordinates, setCooridinates] = useState([
//     {
//       latitude: 48.8587741,
//       longitude: 2.2069771,
//     },
//     {
//       latitude: 48.8323785,
//       longitude: 2.3361663,
//     },
//   ]);
//   return (
//     <View style={styles.container}>
//       <MapView
//         style={styles.maps}
//         region={{
//           latitude: coordinates[0].latitude,
//           longitude: coordinates[0].longitude,
//           latitudeDelta: 0.0622,
//           longitudeDelta: 0.0121,
//         }}>
//         <MapViewDirections
//           origin={coordinates[0]}
//           destination={coordinates[1]}
//           apikey={GOOGLE_API_KEY} // insert your API Key here
//           strokeWidth={4}
//           strokeColor="#111111"
//         />
//         <Marker coordinate={coordinates[0]} />
//         <Marker coordinate={coordinates[1]} />
//       </MapView>
//     </View>
//   );
// };
// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//   },
//   maps: {
//     width: '100%',
//     height: '100%',
//     ...StyleSheet.absoluteFillObject,
//   },
// });
// export default App;
