import React, {Component} from 'react';
import {View, Dimensions, FlatList, Text} from 'react-native';
import styles from './Style';
import Header from '../../components/Header';
import LinearGradient from 'react-native-linear-gradient';
const {width, height} = Dimensions.get('window');
import CityFiler from '../../components/CityFilter';
import PlaceForGuest from '../../components/PlaceForGuest/Index';
import {getTours, getResources, getCities} from '../../redux/actions/app';
import CustomAlert from '../../components/CustomAlert';
import {connect} from 'react-redux';
import LoaderView from '../../components/Loader';
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';

class Discover extends Component {
  constructor() {
    super();

    this.state = {
      filter: [],
      checked: 0,
      Places: [],
      loader: true,
      isRefreshing: false,
      alertMsg: '',
      showAlert: false,
    };
  }

  componentDidMount = () => {
    this.getCity();
  };

  loaddata = (cityid) => {
    const {params} = this.props.route;
    const countries = params.countries;
    this.setState({loader: true});
    const {appResources} = this.props;
    let payload = {
      countryId: countries.CountryID,
      cityId: cityid,
      tourId: '',
      token: this.props.token,
    };

    this.props.getTours(payload).then(
      (response) => {
        console.log('load datat city id 1 ===>', cityid);
        if (response.StatusCode == 200) {
          console.log(
            'load datat city id 2 ===>',
            cityid,
            'and its length ',
            response.Data.length,
          );
          if (response.Data) {
            console.log('load datat city id 3 ===>', cityid);
            this.setState({
              Places: response.Data,
              loader: false,
              moreDataLoader: false,
              isRefreshing: false,
              checked: cityid,
            });
            //alert(JSON.stringify(response.Data));
          } else {
            this.setState({
              loader: false,
              isRefreshing: false,
              // checked: cityid,
            });
          }
        } else {
          this.setState({
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };

  getCity = () => {
    const {params} = this.props.route;
    const countries = params.countries;
    this.setState({loader: true});
    const {appResources} = this.props;
    let payload = {
      countryId: countries.CountryID,
    };
    this.props.getCities(payload).then(
      (response) => {
        // console.log('---------------------->>>', response);
        if (response.StatusCode == 200) {
          if (response.Data && response.Data.length > 0) {
            this.setState(
              {
                filter: response.Data,
                loader: false,
                moreDataLoader: false,
                isRefreshing: false,
              },
              () => {
                //console.log(
                //   '====> what city id we have iin array',
                //   response.Data[0].CityID,
                // );
                this.loaddata(response.Data[0].CityID);
              },
            );
          } else {
            this.setState({
              loader: false,
              isRefreshing: false,
            });
          }
        } else {
          this.setState({
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };

  pressHandler = (item, index) => {
    //console.log('item we get ====>', item.CityID);
    this.setState({Places: []}, () => {
      this.loaddata(item.CityID);
    });
  };
  render() {
    console.log('city ids:', this.state.checked);
    return (
      <View style={styles.container}>
        <CustomAlert
          isVisible={this.state.showAlert}
          onPress={() => this.setState({showAlert: false, alertMsg: ''})}
          message={this.state.alertMsg}
        />
        <LoaderView isVisible={this.state.loader} />

        <View style={{width: width}}>
          <FlatList
            data={this.state.Places}
            renderItem={({item, index}) => {
              return (
                <PlaceForGuest
                  data={this.state.Places[index]}
                  navigation={this.props.navigation}
                />
              );
            }}
            contentContainerStyle={styles.listCont2}
            horizontal={false}
            ListHeaderComponent={
              <View>
                <LinearGradient
                  start={{x: 0, y: 0}}
                  end={{x: 1, y: 0}}
                  colors={['#FC4F1C', '#F89230', '#F9B434']}
                  style={styles.linearGradient}>
                  <Header
                    navigation={this.props.navigation}
                    isLeft={true}
                    leftIcon={require('../../assets/icons8-around-the-globe-64(1).png')}
                    navi={() =>
                      this.props.navigation.navigate('SelectCountryForGuest')
                    }
                    navi2={() => this.props.navigation.navigate('SignIn')}
                    isBorder={true}
                    isHead={true}
                    isRight={true}
                    right={'Sign In'}
                    Head={'Discover'}
                  />
                </LinearGradient>
                <FlatList
                  data={this.state.filter}
                  renderItem={({item, index}) => {
                    return this.state.checked == item.CityID ? (
                      <CityFiler
                        name={item.CityName}
                        isSelected={true}
                        NotSeletedText={true}
                      />
                    ) : (
                      <CityFiler
                        name={item.CityName}
                        onPress={() => this.pressHandler(item, index)}
                      />
                    );
                  }}
                  contentContainerStyle={styles.listCont}
                  horizontal={true}
                  showsHorizontalScrollIndicator={false}
                />
              </View>
            }
          />
        </View>
      </View>
    );
  }
}

const mapStateToProps = (state) => {
  const {appResources, token, user} = state.app;
  return {appResources, token, user};
};

const mapDispatchToProps = {
  getCities,
  getTours,
  getResources,
};

export default connect(mapStateToProps, mapDispatchToProps)(Discover);
