import {StyleSheet, Dimensions} from 'react-native';
import theme from '../../common/theme';
const {width, height} = Dimensions.get('window');
import { RFPercentage, RFValue } from 'react-native-responsive-fontsize';


export default StyleSheet.create({
  container: {
    height: height,
    width: width,
    backgroundColor: theme.primaryColor,
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  linearGradient: {
    width: width,
    height: height * 0.1,
    // position: 'absolute',
    top: 0,
    //  zIndex: -1,
  },
listCont:{
  flexDirection:'row',
  paddingLeft:width*0.04,
  marginTop:height*0.03,
  height:height*0.045,
},
listCont2:{
  paddingBottom: height * 0.07,
}
  
});
