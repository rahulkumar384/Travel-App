import {StyleSheet, Dimensions} from 'react-native';
import theme from '../../common/theme';
const {width, height} = Dimensions.get('window');
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';

export default StyleSheet.create({
  bgImage: {
    height: height,
    width: width,
    justifyContent: 'center',
    alignItems: 'center',
  },

  linearGradient: {
    width: width,
    // height: height * 0.1,
    // position: 'absolute',
    top: 0,
    //  zIndex: -1,
  },
  msgText: {
    fontSize: width * 0.04,
    color: '#000',
    fontFamily: 'Montserrat-Regular',
    textAlign: 'center',
    paddingRight: 20,
    paddingLeft: 20,
  },
  okBox: {
    height: height * 0.05,
    paddingLeft: height * 0.015,
    paddingRight: height * 0.015,
    backgroundColor: theme.thirdColor,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: width * 0.025,
  },
  okText: {
    fontSize: width * 0.04,
    color: '#fff',
    fontFamily: 'Montserrat-Bold',
  },
  centeredView: {
    height,
    width,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.7)',
  },
  lModalView: {
    height: height * 0.35,
    width: width * 0.6,
    backgroundColor: '#fff',
    justifyContent: 'space-evenly',
    alignItems: 'center',
    borderRadius: width * 0.05,
  },
  logoBox: {
    width: width * 0.3,
    height: height * 0.13,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoStyle: {
    width: '100%',
    height: '100%',
    resizeMode: 'contain',
  },
  container: {
    height: height,
    width: width,
    backgroundColor: theme.primaryColor,
    justifyContent: 'flex-start',
    alignItems: 'center',
    // paddingBottom: height * 0.13,
  },
  scrollViewStyle: {
    justifyContent: 'flex-start',
    alignItems: 'center',
    // paddingBottom: height * 0.02,
    width: width,
  },

  type: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: width * 0.9,
    height: height * 0.07,
    marginBottom: height * 0.02,
    // marginTop: height * 0.01,
  },
  aTypeStyle: {
    width: '50%',
    height: '100%',
    borderColor: 'white',
    borderWidth: 1.9,
    backgroundColor: 'white',
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: width * 0.015,
    borderColor: theme.secondaryColor,
  },

  aTypeStyleActive: {
    width: '50%',
    height: '100%',
    backgroundColor: theme.secondaryColor,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: width * 0.015,
  },
  txtStyle: {
    fontSize: RFValue(17, height),
    color: 'white',
    fontWeight: 'bold',
  },
  txtStyle1: {
    fontSize: RFValue(17, height),
    color: theme.secondaryColor,
    fontWeight: 'bold',
  },
  NewPostCont: {
    width: theme.appWidth,
    marginTop: height * 0.03,
    alignItems: 'center',
  },
  margin: {
    borderBottomWidth: 1,
    width: width * 0.73,
    marginBottom: height * 0.02,
    // backgroundColor:'red'
  },
  heading: {
    fontSize: RFPercentage(1.5),
    fontWeight: 'bold',
  },
  Main: {
    height: height * 0.3,
    width: width * 0.9,
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 10,
    marginTop: height * 0.015,
  },
  bottomCont: {
    backgroundColor: theme.secondaryColor,
    height: height * 0.09,
    width: width * 0.9,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingLeft: height * 0.01,
    paddingRight: height * 0.02,
    borderBottomLeftRadius: 15,
    borderBottomRightRadius: 15,
  },
  imgStyle: {
    width: width * 0.9,
    height: height * 0.21,
    resizeMode: 'cover',
    borderTopRightRadius: 15,
    borderTopLeftRadius: 15,
  },
  txt1: {
    //textAlign: 'center',
    fontSize: RFValue(16, height),
    fontWeight: '700',
    color: 'white',
  },
  txt2: {
    //textAlign: 'center',
    fontSize: RFValue(15, height),
    fontWeight: '100',
    //color: 'white',
  },
  listCont2: {
    paddingBottom: height * 0.13,
  },
});
