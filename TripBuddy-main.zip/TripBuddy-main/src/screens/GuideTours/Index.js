import React, {Component} from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  Dimensions,
  Image,
  FlatList,
  TextInput,
  Button,
} from 'react-native';
import styles from './Style';
const {width, height} = Dimensions.get('window');
import Header from '../../components/Header';
import LinearGradient from 'react-native-linear-gradient';
import {connect} from 'react-redux';
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';
import theme from '../../common/theme';
import CustomAlert from '../../components/CustomAlert';
import LoaderView from '../../components/Loader';
import moment from 'moment';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import DropDownPicker from 'react-native-dropdown-picker';
import {
  getCities,
  getCountries,
  getmytour,
  addTour,
  currency,
  getVenue,
  deleteTour,
} from '../../redux/actions/app';
import icons from '../../utils/icons';

class AboutUs extends Component {
  constructor() {
    super();

    this.state = {
      type: [{name: 'Tour Listing'}, {name: 'Add Tours'}],
      checked: 0,
      index: 0,
      YourTours: [],
      Rewards: [],
      showAlert: false,
      alertMsg: '',
      ammount: '',
      tourname: '',
      totalperson: '',
      description: '',
      latlng: '',
      directioninfo: '',
      chosendate: '',
      chosentime: '',
      chosencurrency: '',
      chosenvenue: '',
      isVisibleDate: false,
      isVisibleTime: false,
      CountryList: [],
      CitiesList: [],
      Currency: [],
      VenuesList: [],
      country: '',
      city: '',
      data: null,
    };
  }

  showDatePicker = () => {
    this.setState({isVisibleDate: true});
  };
  hideDatePicker = () => {
    this.setState({isVisibleDate: false});
  };
  handleConfirm = (date) => {
    this.setState({
      isVisibleDate: false,
      chosendate: moment(date).format('YYYY-MM-DD'),
    });
    console.log('A date has been picked: ', date);
  };

  showTimePicker = () => {
    this.setState({isVisibleTime: true});
  };
  handleTimeConfirm = (time) => {
    this.setState({
      isVisibleTime: false,
      chosentime: moment(time).format('LTS'),
    });
    console.log('A time has been picked: ', time);
  };
  hideTimePicker = () => {
    this.setState({isVisibleTime: false});
  };
  /*----------------------------------------------------------------- */

  typeSelector = (input, index) => {
    this.setState({
      checked: index,
      Head: input.name,
    });
  };

  handleTourName = (text) => {
    this.setState({tourname: text});
  };
  handleTotalPerson = (text) => {
    this.setState({totalperson: text});
  };
  handleammount = (text) => {
    this.setState({ammount: text});
  };
  handleDirectionInfo = (text) => {
    this.setState({directioninfo: text});
  };

  handleLatitudeAndLongitude = (text) => {
    this.setState({latlng: text});
  };

  componentDidMount() {
    this.country();
    this.loaddata();
    this.getCurrency();
  }

  getCurrency = () => {
    const {appResources} = this.props;

    this.props.currency((LanguageID = 1)).then(
      (response) => {
        //alert(JSON.stringify(response));
        if (response.StatusCode == 200) {
          this.setState({
            Currency: response.Data,
            loader: false,
          });
          //alert(JSON.stringify(response.Data));
        } else {
          this.setState({
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };

  country = () => {
    const {appResources} = this.props;

    this.props.getCountries((LanguageID = 1)).then(
      (response) => {
        if (response.StatusCode == 200) {
          this.setState({
            CountryList: response.Data,
            loader: false,
          });
          //alert(JSON.stringify(response.Data));
        } else {
          this.setState({
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };

  cities = () => {
    const {appResources} = this.props;
    console.log('ksdjfn;asdjfn;asdjfm', this.state.country);
    let payload = {
      langId: 1,
      countryId: this.state.country,
    };

    this.props.getCities(payload).then(
      (response) => {
        if (response.StatusCode == 200) {
          this.setState({
            CitiesList: response.Data,
            loader: false,
          });

          //alert(JSON.stringify(response.Data));
        } else {
          this.setState({
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };

  Venues = () => {
    const {appResources} = this.props;
    let payload = {
      countryId: this.state.country,
      cityId: this.state.city,
    };

    this.props.getVenue(payload).then(
      (response) => {
        //alert(JSON.stringify(response));
        if (response.StatusCode == 200) {
          this.setState({
            VenuesList: response.Data,
            loader: false,
          });
          // alert(JSON.stringify(response.Data));
        } else {
          this.setState({
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };
  /**----------------Tour listing----------------------------------------- */
  loaddata = () => {
    const {user} = this.props;
    //alert(JSON.stringify(user))
    const {appResources} = this.props;
    let payload = {
      userid: user.UserID,
      tourId: '',
    };

    this.props.getmytour(payload).then(
      (response) => {
        if (response.StatusCode == 200) {
          this.setState({
            YourTours: response.Data,
            loader: false,
          });

          // alert(JSON.stringify(response.Data));
        } else {
          this.setState({
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };
  /**----------------Tour listing----------------------------------------- */
  onPress = (tourid) => {
    this.setState({loader: true});

    let payload = {
      tourId: tourid,
      userId: this.props.user.UserID,
    };

    this.props.deleteTour(payload).then(
      (response) => {
        if (response.StatusCode == 200) {
          if (response.Data) {
            this.setState(
              {
                YourTours: [],
                loader: false,
                showAlert: true,
                alertMsg: 'Tour Deleted Successfully',
              },
              () => {
                this.loaddata();
              },
            );
          } else {
            this.setState({
              loader: false,
              isRefreshing: false,
            });
          }
        } else {
          this.setState({
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };
  addMytour = () => {
    if (
      !this.state.tourname ||
      !this.state.chosendate ||
      !this.state.chosentime ||
      !this.state.totalperson ||
      !this.state.country ||
      !this.state.city ||
      !this.state.chosenvenue ||
      !this.state.latlng ||
      !this.state.directioninfo ||
      !this.state.ammount ||
      !this.state.chosencurrency
    ) {
      return this.setState({
        showAlert: true,
        alertMsg: 'Please Enter All Field',
      });
    } else {
      //alert(this.state.tourname);
      console.log(this.state.tourname);
      console.log(this.state.chosendate);
      console.log('-----', this.state.chosentime);
      console.log('*****', this.state.totalperson);
      console.log(this.state.country);
      console.log(this.state.city);
      console.log('-----', this.state.chosenvenue);
      console.log('*****', this.state.ammount);
      console.log(this.state.latlng);
      console.log(this.state.directioninfo);
      const {user} = this.props;
      const {appResources} = this.props;
      let payload = {
        userid: user.UserID,
        venueId: this.state.chosenvenue,
        tourname: this.state.tourname,
        tourdate: this.state.chosendate,
        timing: this.state.chosentime,
        totalperson: this.state.totalperson,
        latlng: this.state.latlng,
        directioninfo: this.state.directioninfo,
        amount: this.state.ammount,
        currencyid: this.state.chosencurrency,
      };

      this.props.addTour(payload).then(
        (response) => {
          if (response.StatusCode == 200) {
            this.setState({
              loader: false,
              showAlert: true,
              alertMsg:
                'Tour has been created and waiting for approval by Admin',
            });
            if (response.Data != null) {
              this.props.navigation.push('Schedule');
            }
          } else {
            this.setState({
              loader: false,
              showAlert: true,
              alertMsg: 'wrong credentials',
            });
          }
        },
        (error) => {
          this.setState({
            loader: false,
            isRefreshing: false,
            showAlert: true,
            alertMsg:
              error && error.message
                ? error.message
                : appResources &&
                  appResources.OopsSomething &&
                  appResources.OopsSomething,
          });
        },
      );
    }
  };

  render() {
    // alert(JSON.stringify(this.props.user))
    return (
      <View style={styles.container}>
        <LoaderView isVisible={this.state.loader} />
        <CustomAlert
          isVisible={this.state.showAlert}
          onPress={() => this.setState({showAlert: false, alertMsg: ''})}
          message={this.state.alertMsg}
        />
        <ScrollView
          contentContainerStyle={styles.scrollViewStyle}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}>
          <LinearGradient
            start={{x: 0, y: 0}}
            end={{x: 1, y: 0}}
            colors={['#FC4F1C', '#F89230', '#F9B434']}
            style={styles.linearGradient}>
            <Header
              navigation={this.props.navigation}
              isLeft={true}
              leftIcon={icons.back}
              navi={() => this.props.navigation.goBack()}
              isBorder={true}
              isHead={true}
              Head={'Manage Tour'}
            />
          </LinearGradient>
          <View
            style={{
              width: width * 0.9,
              marginTop: height * 0.02,
              // backgroundColor: 'black',
              alignSelf: 'center',
            }}
          />
          <View style={styles.type}>
            {this.state.type.map((input, index) => {
              return this.state.checked == index ? (
                <TouchableOpacity style={styles.aTypeStyleActive}>
                  <Text style={styles.txtStyle}>{input.name}</Text>
                </TouchableOpacity>
              ) : (
                <TouchableOpacity
                  onPress={() => this.typeSelector(input, index)}
                  style={styles.aTypeStyle}>
                  <Text style={styles.txtStyle1}>{input.name}</Text>
                </TouchableOpacity>
              );
            })}
          </View>

          {this.state.checked == 0 ? (
            <FlatList
              data={this.state.YourTours}
              renderItem={({item}) => {
                return (
                  <TouchableOpacity style={styles.Main}>
                    <Image
                      source={{uri: item.LogoUrl}}
                      style={styles.imgStyle}
                    />
                    <View style={styles.bottomCont}>
                      <View
                        style={{
                          flexDirection: 'row',
                          justifyContent: 'space-between',
                          // marginTop: height * 0.01,
                          paddingLeft: 7,
                          paddingRight: 7,
                          width: width * 0.85,
                        }}>
                        <View
                          style={{
                            // marginRight: width * 0.04,
                            width: width * 0.425,
                            // bac
                          }}>
                          <Text style={styles.txt1}>
                            Tour Name:{' '}
                            <Text style={styles.txt2}>{item.TourName}</Text>
                          </Text>
                          <Text style={styles.txt1}>
                            Tour Date:{' '}
                            <Text style={styles.txt2}>{item.TourDate}</Text>
                          </Text>
                          <Text style={styles.txt1}>
                            Status:{' '}
                            {item.IsApproved == false ? (
                              <Text style={styles.txt2}>Not Approved </Text>
                            ) : (
                              <Text style={styles.txt2}>Approved</Text>
                            )}
                          </Text>
                        </View>
                        <View
                          style={{
                            flexDirection: 'row',
                            width: width * 0.425,
                          }}>
                          <TouchableOpacity
                            onPress={() =>
                              this.props.navigation.navigate('ViewGuideTour', {
                                viewTour: item,
                              })
                            }
                            style={{
                              backgroundColor: 'green',
                              width: width * 0.13,
                              height: height * 0.04,
                              borderRadius: 9,
                              justifyContent: 'center',
                              alignSelf: 'center',
                              marginRight: width * 0.01,
                            }}>
                            <Text
                              style={{
                                textAlign: 'center',
                                fontSize: RFPercentage(1.5),
                                fontWeight: 'bold',
                                color: 'white',
                              }}>
                              View
                            </Text>
                          </TouchableOpacity>
                          <TouchableOpacity
                            onPress={() =>
                              this.props.navigation.push('EditGuideTour', {
                                item: item,
                              })
                            }
                            style={{
                              // backgroundColor: '#FF8C00',
                              width: width * 0.13,
                              height: height * 0.04,
                              borderRadius: 9,
                              justifyContent: 'center',
                              alignSelf: 'center',
                              marginRight: width * 0.01,
                              borderWidth: 2,
                              borderColor: 'white',
                            }}>
                            <Text
                              style={{
                                textAlign: 'center',
                                fontSize: RFPercentage(1.5),
                                fontWeight: 'bold',
                                color: 'white',
                              }}>
                              Edit
                            </Text>
                          </TouchableOpacity>
                          <TouchableOpacity
                            style={{
                              backgroundColor: 'red',
                              width: width * 0.13,
                              height: height * 0.04,
                              borderRadius: 9,
                              justifyContent: 'center',
                              alignSelf: 'center',
                            }}
                            onPress={() => this.onPress(item.TourID)}>
                            <Text
                              style={{
                                textAlign: 'center',
                                fontSize: RFPercentage(1.5),
                                fontWeight: 'bold',
                                color: 'white',
                              }}>
                              Delete
                            </Text>
                          </TouchableOpacity>
                        </View>
                      </View>
                    </View>
                  </TouchableOpacity>
                );
              }}
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.listCont2}
              horizontal={false}
              ListEmptyComponent={
                <View
                  style={{
                    width: width * 0.8,
                    height: height * 0.2,
                    alignSelf: 'center',
                    justifyContent: 'center',
                    //backgroundColor: theme.secondaryColor,
                    marginTop: height * 0.05,
                    borderWidth: 5,
                    borderColor: theme.secondaryColor,
                    borderRadius: 8,
                    padding: 15,
                  }}>
                  <Text style={{fontSize: height * 0.04, textAlign: 'center'}}>
                    No Tours !
                  </Text>
                </View>
              }
            />
          ) : (
            <View
              style={{
                width: width * 0.9,
                alignSelf: 'center',
                // backgroundColor: 'yellow',
                justifyContent: 'center',
                paddingBottom: height * 0.138,
              }}>
              <View style={styles.margin}>
                <TextInput
                  placeholder={'Enter Tour Name'}
                  onChangeText={this.handleTourName}
                  style={[
                    {
                      height: height * 0.07,
                      width: width * 0.7,
                      color: 'black',
                      //backgroundColor: 'red',
                      marginLeft: width * 0.015,
                    },
                  ]}
                  placeholderTextColor="#D3D3D3"
                />
              </View>

              {/* ------------------------------------date picker------------------------------------ */}

              <DateTimePickerModal
                isVisible={this.state.isVisibleDate}
                mode={'date'}
                onConfirm={this.handleConfirm}
                onCancel={this.hideDatePicker}
              />
              <DateTimePickerModal
                isVisible={this.state.isVisibleTime}
                mode={'time'}
                onConfirm={this.handleTimeConfirm}
                onCancel={this.hideTimePicker}
              />
              {/* ------------------------------------date picker------------------------------------ */}
              <View
                style={{
                  justifyContent: 'space-between',
                  flexDirection: 'row',
                  width: width * 0.5,
                  marginBottom: height * 0.02,
                  alignItems: 'center',
                }}>
                <Text style={styles.heading}>Tour Date:</Text>
                <Text style={{fontSize: RFPercentage(1.5)}}>
                  {'   '}
                  {this.state.chosendate}
                  {'   '}
                </Text>
                <TouchableOpacity
                  style={{
                    width: width * 0.2,
                    height: height * 0.04,
                    alignContent: 'center',
                    justifyContent: 'center',
                    backgroundColor: theme.secondaryColor,
                    borderRadius: 9,
                  }}
                  onPress={this.showDatePicker}>
                  <Text
                    style={{
                      color: 'white',
                      textAlign: 'center',
                      fontSize: RFValue(10, height),
                    }}>
                    SELECT DATE
                  </Text>
                </TouchableOpacity>
                {/* <Button title="Select Date" onPress={this.showDatePicker} /> */}
              </View>
              <View
                style={{
                  justifyContent: 'space-between',
                  flexDirection: 'row',
                  width: width * 0.5,
                  marginBottom: height * 0.02,
                  alignItems: 'center',
                }}>
                <Text style={styles.heading}>Tour Timing:</Text>
                <Text style={{fontSize: RFPercentage(1.5)}}>
                  {'   '}
                  {this.state.chosentime}
                  {'   '}
                </Text>
                <TouchableOpacity
                  style={{
                    width: width * 0.2,
                    height: height * 0.04,
                    alignContent: 'center',
                    justifyContent: 'center',
                    backgroundColor: theme.secondaryColor,
                    borderRadius: 9,
                  }}
                  onPress={this.showTimePicker}>
                  <Text
                    style={{
                      color: 'white',
                      textAlign: 'center',
                      fontSize: RFValue(10, height),
                    }}>
                    SELECT TIME
                  </Text>
                </TouchableOpacity>
                {/* <Button title="Select Time" onPress={this.showTimePicker} /> */}
              </View>
              <View style={styles.margin}>
                <TextInput
                  placeholder={'Enter Total Person'}
                  onChangeText={this.handleTotalPerson}
                  style={[
                    {
                      height: height * 0.07,
                      width: width * 0.7,
                      color: 'black',
                      //backgroundColor: 'red',
                      marginLeft: width * 0.015,
                    },
                  ]}
                  placeholderTextColor="#D3D3D3"
                  keyboardType={'number-pad'}
                />
              </View>

              {/* ------------------------------------------------------------------------------------------------ */}

              <DropDownPicker
                zIndex={5000}
                items={this.state.CountryList.map((item) => ({
                  label: item.CountryName,
                  value: item.CountryID,
                }))}
                containerStyle={{
                  height: height * 0.08,
                  width: width * 0.7,
                }}
                style={{
                  backgroundColor: 'transparent',
                  // height: height * 0.0815,
                  width: width * 0.73,
                  // borderWidth: 1,
                  borderColor: 'black',
                  borderTopWidth: 0,
                  borderBottomWidth: 1.5,
                  borderLeftWidth: 0,
                  borderRightWidth: 0,
                }}
                itemStyle={{
                  justifyContent: 'flex-start',
                  backgroundColor: 'transparent',
                }}
                defaultValue={this.state.data}
                placeholder={'Enter Country'}
                placeholderStyle={{color: '#D3D3D3'}}
                showArrow={false}
                labelStyle={{
                  zIndex: 5000,
                  backgroundColor: 'transparent',
                  color: 'black',
                }}
                dropDownStyle={{backgroundColor: 'white'}}
                onChangeItem={(item) =>
                  this.setState(
                    {
                      country: item.value,
                      CitiesList: [],
                    },
                    () => {
                      this.cities();
                    },
                  )
                }
              />

              {/* <TouchableOpacity onPress={this.cities(this.state.country)} /> */}
              <View style={{height: height * 0.02}} />

              <DropDownPicker
                zIndex={3000}
                items={this.state.CitiesList.map((item) => ({
                  label: item.CityName,
                  value: item.CityID,
                }))}
                containerStyle={{
                  height: height * 0.08,
                  width: width * 0.7,
                }}
                style={{
                  // backgroundColor:'red',
                  backgroundColor: 'transparent',
                  // height: height * 0.0815,
                  width: width * 0.73,
                  // borderWidth: 1,
                  borderColor: 'black',
                  borderTopWidth: 0,
                  borderBottomWidth: 1.5,
                  borderLeftWidth: 0,
                  borderRightWidth: 0,
                }}
                itemStyle={{
                  justifyContent: 'flex-start',
                  backgroundColor: 'transparent',
                }}
                defaultValue={this.state.data}
                placeholder={'Enter City'}
                placeholderStyle={{color: '#D3D3D3'}}
                showArrow={false}
                labelStyle={{
                  zIndex: 5000,
                  backgroundColor: 'transparent',
                  color: 'black',
                }}
                dropDownStyle={{backgroundColor: 'white'}}
                onChangeItem={(item) =>
                  this.setState(
                    {
                      city: item.value,
                      VenuesList: [],
                    },
                    () => {
                      //this.country();
                      this.Venues();
                    },
                  )
                }
              />

              {/* ------------------------------------------------------------------------------------------------ */}
              <View style={{height: height * 0.02}} />
              <DropDownPicker
                zIndex={1000}
                items={this.state.VenuesList.map((item) => ({
                  label: item.VenueName,
                  value: item.VenueID,
                }))}
                containerStyle={{
                  height: height * 0.08,
                  width: width * 0.7,
                  // backgroundColor: '#F5F5F5',
                }}
                style={{
                  // backgroundColor:'red',
                  backgroundColor: 'transparent',
                  // height: height * 0.0815,
                  width: width * 0.73,
                  // borderWidth: 1,
                  borderColor: 'black',
                  borderTopWidth: 0,
                  borderBottomWidth: 1.5,
                  borderLeftWidth: 0,
                  borderRightWidth: 0,
                }}
                itemStyle={{
                  justifyContent: 'flex-start',
                  backgroundColor: 'transparent',
                }}
                defaultValue={this.state.data}
                placeholder={'Enter Venue'}
                placeholderStyle={{color: '#D3D3D3'}}
                showArrow={false}
                labelStyle={{
                  zIndex: 5000,
                  backgroundColor: 'transparent',
                  color: 'black',
                }}
                dropDownStyle={{backgroundColor: 'white'}}
                onChangeItem={(item) =>
                  this.setState({
                    chosenvenue: item.value,
                  })
                }
              />
              <View style={{height: height * 0.02}} />

              <View style={styles.margin}>
                <TextInput
                  placeholder={'Enter Amount'}
                  keyboardType={'number-pad'}
                  onChangeText={this.handleammount}
                  style={[
                    {
                      height: height * 0.07,
                      width: width * 0.7,
                      color: 'black',
                      //backgroundColor: 'red',
                      marginLeft: width * 0.015,
                    },
                  ]}
                  placeholderTextColor="#D3D3D3"
                />
              </View>
              <DropDownPicker
                zIndex={5000}
                items={this.state.Currency.map((item) => ({
                  label: item.Currency,
                  value: item.CurrencyID,
                }))}
                containerStyle={{
                  height: height * 0.08,
                  width: width * 0.7,
                  // backgroundColor: '#F5F5F5',
                }}
                style={{
                  // backgroundColor:'red',
                  backgroundColor: 'transparent',
                  // height: height * 0.0815,
                  width: width * 0.73,
                  // borderWidth: 1,
                  borderColor: 'black',
                  borderTopWidth: 0,
                  borderBottomWidth: 1.5,
                  borderLeftWidth: 0,
                  borderRightWidth: 0,
                }}
                itemStyle={{
                  justifyContent: 'flex-start',
                  backgroundColor: 'transparent',
                }}
                defaultValue={this.state.data}
                placeholder={'Enter Currency'}
                placeholderStyle={{color: '#D3D3D3'}}
                showArrow={false}
                labelStyle={{
                  zIndex: 5000,
                  backgroundColor: 'transparent',
                  color: 'black',
                }}
                dropDownStyle={{backgroundColor: 'white'}}
                onChangeItem={(item) =>
                  this.setState({
                    chosencurrency: item.value,
                  })
                }
              />
              <View style={{height: height * 0.02}} />
              <View style={styles.margin}>
                <TextInput
                  placeholder={'Enter Latitude, Longitude'}
                  onChangeText={this.handleLatitudeAndLongitude}
                  style={[
                    {
                      height: height * 0.07,
                      width: width * 0.7,
                      color: 'black',
                      //backgroundColor: 'red',
                      marginLeft: width * 0.015,
                    },
                  ]}
                  placeholderTextColor="#D3D3D3"
                  keyboardType={'numbers-and-punctuation'}
                />
              </View>
              <View style={styles.margin}>
                <TextInput
                  placeholder={'Enter Tour Description'}
                  onChangeText={this.handleDirectionInfo}
                  style={[
                    {
                      height: height * 0.07,
                      width: width * 0.7,
                      color: 'black',
                      //backgroundColor: 'red',
                      marginLeft: width * 0.015,
                    },
                  ]}
                  placeholderTextColor="#D3D3D3"
                />
              </View>
              <TouchableOpacity
                style={{
                  width: width * 0.7,
                  height: height * 0.06,
                  backgroundColor: theme.secondaryColor,
                  alignSelf: 'center',
                  borderRadius: 15,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
                onPress={this.addMytour}>
                <Text
                  style={{
                    fontSize: RFPercentage(2),
                    textAlign: 'center',
                    color: 'white',
                  }}>
                  SUBMIT
                </Text>
              </TouchableOpacity>
            </View>
          )}
        </ScrollView>
      </View>
    );
  }
}

const mapStateToProps = (state) => {
  const {appResources, token, user} = state.app;
  return {appResources, token, user};
};

const mapDispatchToProps = {
  getCities,
  getCountries,
  getmytour,
  addTour,
  currency,
  getVenue,
  deleteTour,
};

export default connect(mapStateToProps, mapDispatchToProps)(AboutUs);
