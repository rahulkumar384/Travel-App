import React, {Component} from 'react';
import {
  View,
  Text,
  ImageBackground,
  Dimensions,
  Modal,
  TouchableOpacity,
  FlatList,
  Image,
  TextInput,
} from 'react-native';

//local import
import styles from './Style';
import LoaderView from '../../components/Loader';
import CustomAlert from '../../components/CustomAlert';

//other
const {width, height} = Dimensions.get('window');

// redux
import {connect} from 'react-redux';
import {forgetPassword, checkEmail} from '../../redux/actions/app';
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';

class SelectCountry extends Component {
  constructor() {
    super();

    this.state = {
      isRefreshing: false,
      alertMsg: '',
      showAlert: false,
      Countries: [],
      loader: false,
      showAlert: false,
      alertMsg: '',
      email: '',
    };
  }
  handleEmail = (text) => {
    this.setState({email: text});
  };

  loaddata = () => {
    this.setState({loader: true});
    const {appResources} = this.props;
    let payload = {email: this.state.email};

    this.props.forgetPassword(payload).then(
      (response) => {
        if (response.StatusCode == 200) {
          this.setState({
            loader: false,
            showAlert: true,
            alertMsg: 'Password has been sent to your email',
          });
          this.props.navigation.navigate('SignIn');
        } else {
          this.setState({
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };
  EmailCheck = () => {
    this.setState({loader: false});
    let payload = {
      email: this.state.email,
    };
    this.props.checkEmail(payload).then(
      (response) => {
        if (response.StatusCode == 200) {
          if (response.Data.IsExists == 1) {
            this.loaddata();
          } else {
            this.setState({
              showAlert: true,
              alertMsg: 'Email Not Exist',
            });
          }
        } else {
          this.setState({
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };
  render() {
    return (
      <View style={styles.container}>
        {/** LOADER */}
        <LoaderView isVisible={this.state.loader} />
        <CustomAlert
          isVisible={this.state.showAlert}
          onPress={() => this.setState({showAlert: false, alertMsg: ''})}
          message={this.state.alertMsg}
        />
        <ImageBackground
          source={require('../../assets/Splash.png')}
          style={{
            height: height,
            width: width,
            alignItems: 'center',
            justifyContent: 'center',
          }}
          imageStyle={{resizeMode: 'stretch'}}>
          <View style={{alignItems: 'center', marginBottom: height * 0.01}}>
            <Text
              style={{
                fontSize: RFValue(40, height),
                fontWeight: 'bold',
                color: 'white',
              }}>
              Trip Buddy
            </Text>
          </View>
          <View>
            <Text
              style={{
                fontSize: RFValue(27, height),
                fontWeight: 'bold',
                color: 'white',
              }}>
              ACCOUNT RECOVERY
            </Text>
          </View>
          <View style={styles.inputFields}>
            <Image
              source={require('../../assets/user.png')}
              style={{
                //backgroundColor:'red',
                resizeMode: 'contain',
                width: width * 0.07,
                height: height * 0.04,
                alignSelf: 'center',
                marginRight: width * 0.02,
              }}
            />
            <TextInput
              placeholder={'Email-Address'}
              onChangeText={this.handleEmail}
              style={[
                {
                  height: height * 0.0815,
                  width: width * 0.72,
                  color: 'white',
                },
              ]}
              placeholderTextColor="white"
              keyboardType={'email-address'}
            />
          </View>
          <TouchableOpacity style={styles.box} onPress={this.EmailCheck}>
            <Text
              style={{
                fontSize: RFPercentage(2),
                textAlign: 'center',
                color: 'white',
                fontWeight: 'bold',
              }}>
              RESET PASSWORD
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.back}
            onPress={() => this.props.navigation.goBack()}>
            <Text
              style={{
                fontSize: RFValue(17, height),
                textAlign: 'center',
                color: 'white',
                fontWeight: 'bold',
              }}>
              BACK
            </Text>
          </TouchableOpacity>
        </ImageBackground>
      </View>
    );
  }
}

const mapStateToProps = (state) => {
  const {langId, user} = state.app;
  return {langId, user};
};

const mapDispatchToProps = {
  forgetPassword,
  checkEmail,
};
export default connect(mapStateToProps, mapDispatchToProps)(SelectCountry);
