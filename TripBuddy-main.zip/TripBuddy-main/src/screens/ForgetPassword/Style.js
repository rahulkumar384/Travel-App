import {StyleSheet, Dimensions} from 'react-native';
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';
import theme from '../../common/theme';
const {width, height} = Dimensions.get('window');

export default StyleSheet.create({
  container: {
    height: height,
    width: width,
  },
  centeredView: {
    height: height * 0.6,
    width: width * 0.9,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
    marginTop: height * 0.15,
    //backgroundColor:'red'
  },
  lModalView: {
    height: height * 0.435, //height * 0.262
    width: '75%',
    backgroundColor: 'white',
    //justifyContent: 'space-evenly',
    alignItems: 'center',
    borderRadius: width * 0.03,
    overflow: 'hidden',
  },
  openModelTitleView: {
    marginTop: height * 0.03,
    paddingBottom: height * 0.03,
    width: width,
    justifyContent: 'center',
    alignItems: 'center',
    //backgroundColor: 'red',
    borderBottomColor: '#eee',
    borderBottomWidth: width * 0.003,
  },
  openModelTitle: {
    fontSize: RFValue(15, height),
    fontWeight: 'bold',
    color: '#616161',
  },
  litstItemView: {
    //backgroundColor: 'red',
    width: '100%',
    height: height * 0.08,

    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomColor: '#eee',
    borderBottomWidth: width * 0.001,
    padding: width * 0.08,
    paddingLeft: width * 0.04,
  },
  imgTextContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  litstItem: {
    height: 20,
    marginLeft: width * 0.04,
    fontSize: RFValue(15, height),
    //backgroundColor:"red",
    color: '#616161',
  },
  back: {
    width: width * 0.2,
    height: height * 0.05,
    // backgroundColor: theme.secondaryColor,
    alignSelf: 'center',
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
    //marginLeft: width * 0.05,
    marginTop: height * 0.015,
  },
  inputFields: {
    width: '80%',
    height: height * 0.085,
    borderBottomWidth: 1,
    borderBottomColor: 'white',
    fontSize: RFValue(18, height),
    color: '#000',
    marginTop: height * 0.02,
    flexDirection: 'row',
    marginBottom: height * 0.02,
  },
  box: {
    width: width * 0.65,
    height: height * 0.05,
    backgroundColor: theme.secondaryColor,
    alignSelf: 'center',
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
    //marginLeft: width * 0.05,
    marginTop: height * 0.015,
  },
});
