import {StyleSheet, Dimensions} from 'react-native';
import theme from '../../common/theme';
const {width, height} = Dimensions.get('window');
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';

export default StyleSheet.create({
  container: {
    height: height,
    width: width,
    backgroundColor: theme.primaryColor,
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingBottom: height * 0.13,
  },
  linearGradient: {
    width: width,
    // height: height * 0.05,
    // position: 'absolute',
    top: 0,
    //  zIndex: -1,
  },
  listCont: {
    flexDirection: 'row',
    marginLeft: width * 0.05,
    marginTop: height * 0.05,

    height: height * 0.045,
  },
});
