import React, {Component} from 'react';
import {
  View,
  Dimensions,
  FlatList,
  TouchableOpacity,
  Text,
  Image,
} from 'react-native';
import styles from './Style';
import LinearGradient from 'react-native-linear-gradient';
const {width, height} = Dimensions.get('window');
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';
import Place from '../../components/Place';
import {
  getToursGuideDetails,
  getResources,
  getCities,
} from '../../redux/actions/app';
import CustomAlert from '../../components/CustomAlert';
import {connect} from 'react-redux';
import LoaderView from '../../components/Loader';
import icons from '../../utils/icons';
import Header from '../../components/Header';

class Schedule extends Component {
  constructor() {
    super();

    this.state = {
      checked: 0,
      Places: [],
      loader: true,
      isRefreshing: false,
      alertMsg: '',
      showAlert: false,
    };
  }
  componentDidMount = () => {
    this.loaddata();
  };

  loaddata = () => {
    this.setState({loader: true});
    const {appResources} = this.props;
    // alert(JSON.stringify(this.props.user.UserID))
    let payload = {
      userId: this.props.user.UserID,
      tourguideId: this.props.user.UserID,
      countryId: '',
      cityId: '',
    };
    this.props.getToursGuideDetails(payload).then(
      (response) => {
        if (response.StatusCode == 200) {
          if (response.Data && response.Data.length > 0) {
            this.setState({
              Places: response.Data,
              loader: false,
              moreDataLoader: false,
              isRefreshing: false,
            });
            //alert(JSON.stringify(response.Data[11]))
          } else {
            this.setState({
              loader: false,
              isRefreshing: false,
            });
          }
        } else {
          this.setState({
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };
  onRefresh() {
    this.setState({Places: [], isRefreshing: true}, () => {
      this.loaddata();
    });
  }

  render() {
    const {appResources} = this.props;
    return (
      <View style={styles.container}>
        <CustomAlert
          isVisible={this.state.showAlert}
          onPress={() => this.setState({showAlert: false, alertMsg: ''})}
          message={this.state.alertMsg}
        />
        <LoaderView isVisible={this.state.loader} />

        <LinearGradient
          start={{x: 0, y: 0}}
          end={{x: 1, y: 0}}
          colors={['#FC4F1C', '#F89230', '#F9B434']}
          style={styles.linearGradient}
        />

        <View style={{width: width}}>
          <FlatList
            data={this.state.Places}
            renderItem={({item, index}) => {
              return (
                <Place
                  data={this.state.Places[index]}
                  navigation={this.props.navigation}
                  isGuide={true}
                />
              );
            }}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.listCont2}
            horizontal={false}
            onRefresh={() => this.onRefresh()}
            refreshing={this.state.isRefreshing}
            ListHeaderComponent={
              <LinearGradient
                start={{x: 0, y: 0}}
                end={{x: 1, y: 0}}
                colors={['#FC4F1C', '#F89230', '#F9B434']}
                style={styles.linearGradient}>
                <Header
                  navigation={this.props.navigation}
                  isLeft={true}
                  leftIcon={require('../../assets/icons8-around-the-globe-64(1).png')}
                  isBorder={true}
                  isHead={true}
                  Head={'Schedule'}
                />
              </LinearGradient>
            }
          />
        </View>
      </View>
    );
  }
}

const mapStateToProps = (state) => {
  const {appResources, token, user} = state.app;
  return {appResources, token, user};
};

const mapDispatchToProps = {
  getToursGuideDetails,
  getResources,
  getCities,
};

export default connect(mapStateToProps, mapDispatchToProps)(Schedule);
