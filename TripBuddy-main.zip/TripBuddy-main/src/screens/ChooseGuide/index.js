import React, {Component} from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  Image,
  ScrollView,
  Dimensions,
  ImageBackground,
  Platform,
} from 'react-native';
import styles from './style';
const {width, height} = Dimensions.get('window');
import LinearGradient from 'react-native-linear-gradient';
import Header from '../../components/Header';
import icons from '../../utils/icons';
import theme from '../../common/theme';
import ChooseGuideComp from '../../components/ChooseGuideComp';
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';
import {
  getTourGuides,
  getLanguages,
  getResources,
} from '../../redux/actions/app';
import CustomAlert from '../../components/CustomAlert';
import {connect} from 'react-redux';
import LoaderView from '../../components/Loader';
import DropDownPicker from 'react-native-dropdown-picker';
class ChooseGuide extends Component {
  constructor(props) {
    super(props);
    const {params} = props.route;
    const tour = params.tour;
    this.state = {
      loader: true,
      isRefreshing: false,
      alertMsg: '',
      showAlert: false,
      Guides: [],
      loader: false,
      tourId: tour.TourID,
      from: '',
      to: '',
      language: '',
      gender: '',
      rating: '',
      languages: '',
      isfilter: false,
      data1: [],
      data: null,
    };
  }
  getLanguages = () => {
    this.setState({loader: true});
    const payload = {
      userId: this.props.userId,
      langId: 2,
    };
    this.props.getLanguages(payload).then(
      (response) => {
        if (response.StatusCode == 200) {
          this.setState({load: false, languages: response.Data});
        } else {
          this.setState({
            loader: false,
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };
  componentDidMount = () => {
    this.loaddata();
    this.getLanguages();
  };

  loaddata = () => {
    const {params} = this.props.route;
    this.setState({loader: true});
    const {appResources} = this.props;
    let payload = {
      tourId: this.state.tourId,
      from: this.state.from,
      to: this.state.to,
      language: this.state.language,
      gender: this.state.gender,
      rating: this.state.rating,
    };

    this.props.getTourGuides(payload).then(
      (response) => {
        if (response.StatusCode == 200) {
          if (response.Data.TourGuides && response.Data.TourGuides.length > 0) {
            this.setState({
              Guides: response.Data,
              loader: false,
            });
          } else {
            this.setState({
              showAlert: true,
              loader: false,
              isRefreshing: false,
              alertMsg: 'No Tour Guide Available, Please Try Again',
            });
          }
        } else {
          this.setState({
            loader: false,
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };
  press = () => {
    this.setState({Guides: [], loader: true, isfilter: false}, () => {
      this.loaddata();
    });
  };
  render() {
    const {appResources} = this.props;
    console.log(this.state.Guides.TourGuides);
    const {params} = this.props.route;
    const tour = params.tour;
    var languages = [];
    var lang = [];
    var langs = [];
    this.props.languages.forEach(function (item) {
      lang = [
        {
          label: item.LanguageName,
          value: item.LanguageID,
          icon: () => (
            <Image
              source={{uri: item.FlagUrl}}
              style={{
                height: height * 0.02,
                width: width * 0.08,
                resizeMode: 'contain',
              }}
            />
          ),
        },
      ];
      languages = languages.concat(lang);
    });
    return (
      <View style={styles.container}>
        <CustomAlert
          isVisible={this.state.showAlert}
          onPress={() =>
            this.setState({showAlert: false, alertMsg: this.state.alertMsg})
          }
          message={this.state.alertMsg}
        />
        <LoaderView isVisible={this.state.loader} />
        <ScrollView contentContainerStyle={styles.scrollViewStyle}>
          <LinearGradient
            start={{x: 0, y: 0}}
            end={{x: 1, y: 0}}
            colors={['#FC4F1C', '#F89230', '#F9B434']}
            style={styles.linearGradient}>
            <Header
              navigation={this.props.navigation}
              isLeft={true}
              leftIcon={icons.back}
              navi={() => this.props.navigation.goBack()}
              isBorder={true}
              isHead={true}
              Head={'Choose Guide'}
            />
          </LinearGradient>
          <ImageBackground
            source={{uri: tour.LogoUrl}}
            imageStyle={{width: width, height: height * 0.33}}
            style={{width: width, height: height, resizeMode: 'stretch'}}>
            <View
              style={{
                width: width * 0.8,
                alignSelf: 'center',
                marginTop: height * 0.26,
                borderRadius: 10,
                backgroundColor: 'white',
                paddingLeft: height * 0.02,
                paddingRight: height * 0.02,
                //elevation:10,
              }}>
              <View style={{marginTop: height * 0.03}}>
                <Text style={{fontSize: RFValue(20, height), color: '#FFD700'}}>
                  {tour.TourName}
                </Text>
                <Text
                  style={{
                    fontSize: RFValue(14, height),
                    color: 'black',
                    marginTop: height * 0.01,
                  }}>
                  {this.state.Guides.Description}
                </Text>
              </View>

              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  width: '100%',
                }}>
                <Text
                  style={{
                    fontSize: RFValue(18, height),
                    color: 'black',
                    fontWeight: 'bold',
                  }}>
                  {appResources.ChooseGuide}
                </Text>
                <TouchableOpacity
                  onPress={() =>
                    this.setState({isfilter: !this.state.isfilter})
                  }>
                  <Image
                    style={{
                      resizeMode: 'contain',
                      width: width * 0.05,
                      height: height * 0.05,
                    }}
                    source={require('../../assets/filter.png')}
                  />
                </TouchableOpacity>
              </View>

              {this.state.isfilter ? (
                <View>
                  <View style={{height: height * 0.01}} />
                  <DropDownPicker
                    zIndex={5000}
                    items={[
                      {label: '5-star rating', value: '5'},
                      {label: '4-star rating', value: '4'},
                      {label: '3-star rating', value: '3'},
                      {label: '2-star rating', value: '2'},
                      {label: '1-star rating', value: '1'},
                    ]}
                    searchable={false}
                    containerStyle={{
                      height: height * 0.07,
                      width: width * 0.68,
                      alignSelf: 'center',
                    }}
                    style={{
                      borderColor: theme.secondaryColor,
                      borderTopLeftRadius: 40,
                      borderTopRightRadius: 40,
                      borderBottomLeftRadius: 40,
                      borderBottomRightRadius: 40,
                      justifyContent: 'center',
                    }}
                    itemStyle={{}}
                    dropDownStyle={{backgroundColor: 'white'}}
                    onChangeItem={(item) =>
                      this.setState({
                        rating: item.value,
                      })
                    }
                    defaultValue={this.state.data}
                    placeholder={appResources.Rating}
                    placeholderStyle={{textAlign: 'center', fontWeight: 'bold'}}
                    showArrow={false}
                    //arrowStyle={{backgroundColor:'red'}}
                    labelStyle={{textAlign: 'center'}}
                  />
                  <View style={{height: height * 0.015}} />

                  <DropDownPicker
                    zIndex={4000}
                    items={languages}
                    multiple={true}
                    multipleText="%d language has been selected"
                    min={0}
                    max={3}
                    searchable={true}
                    containerStyle={{
                      height: height * 0.07,
                      width: width * 0.68,
                      alignSelf: 'center',
                    }}
                    style={{
                      borderColor: theme.secondaryColor,
                      borderTopLeftRadius: 40,
                      borderTopRightRadius: 40,
                      borderBottomLeftRadius: 40,
                      borderBottomRightRadius: 40,
                      justifyContent: 'center',
                    }}
                    itemStyle={{
                      justifyContent: 'flex-start',
                    }}
                    dropDownStyle={{backgroundColor: 'white'}}
                    onChangeItem={(item) =>
                      this.setState({
                        language: item,
                      })
                    }
                    defaultValue={this.state.data1}
                    placeholder={appResources.LanguageSpoken}
                    placeholderStyle={{textAlign: 'center', fontWeight: 'bold'}}
                    showArrow={false}
                    // arrowStyle={{marginRight: 10,backgroundColor:'green'}}
                    //arrowStyle={{backgroundColor:'red'}}
                    labelStyle={{textAlign: 'center'}}
                  />
                  <View style={{height: height * 0.015}} />

                  <DropDownPicker
                    zIndex={3000}
                    items={[
                      {label: '20 - 30', value: 1},
                      {label: '30 - 40', value: 2},
                      {label: '40 - 50', value: 3},
                      {label: '50 - 60', value: 4},
                      {label: '60 - 70', value: 5},
                      {label: '70 - 80', value: 6},
                      {label: '80 - 90', value: 7},
                      {label: '90 - 100', value: 8},
                    ]}
                    //searchable={true}

                    containerStyle={{
                      height: height * 0.07,
                      width: width * 0.68,
                      alignSelf: 'center',
                    }}
                    style={{
                      borderColor: theme.secondaryColor,
                      borderTopLeftRadius: 40,
                      borderTopRightRadius: 40,
                      borderBottomLeftRadius: 40,
                      borderBottomRightRadius: 40,
                      justifyContent: 'center',
                    }}
                    itemStyle={{
                      justifyContent: 'flex-start',
                    }}
                    dropDownStyle={{backgroundColor: 'white'}}
                    onChangeItem={(item) => {
                      if (item.value == 1) {
                        console.log('adsad');
                        this.setState({
                          From: 20,
                          To: 30,
                        });
                      } else if (item.value == 2) {
                        this.setState({
                          From: 30,
                          To: 40,
                        });
                      } else if (item.value == 3) {
                        this.setState({
                          From: 40,
                          To: 50,
                        });
                      } else if (item.value == 4) {
                        this.setState({
                          From: 50,
                          To: 60,
                        });
                      }
                    }}
                    defaultValue={this.state.data}
                    placeholder={appResources.Age}
                    placeholderStyle={{textAlign: 'center', fontWeight: 'bold'}}
                    showArrow={false}
                    //arrowStyle={{backgroundColor:'red'}}
                    labelStyle={{textAlign: 'center'}}
                  />

                  <View style={{height: height * 0.015}} />
                  <DropDownPicker
                    zIndex={1000}
                    items={[
                      {label: 'Male', value: 1},
                      {label: 'Female', value: 2},
                    ]}
                    // searchable={true}
                    multiple={true}
                    containerStyle={{
                      height: height * 0.08,
                      width: width * 0.68,
                      alignSelf: 'center',
                    }}
                    style={{
                      borderColor: theme.secondaryColor,
                      borderTopLeftRadius: 40,
                      borderTopRightRadius: 40,
                      borderBottomLeftRadius: 40,
                      borderBottomRightRadius: 40,
                      justifyContent: 'center',
                    }}
                    itemStyle={{
                      justifyContent: 'flex-start',
                    }}
                    dropDownStyle={{backgroundColor: 'white'}}
                    onChangeItem={(item) =>
                      this.setState({
                        gender: item,
                      })
                    }
                    defaultValue={this.state.data1}
                    placeholder={appResources.Gender}
                    placeholderStyle={{textAlign: 'center', fontWeight: 'bold'}}
                    showArrow={false}
                    //arrowStyle={{backgroundColor:'red'}}
                    labelStyle={{textAlign: 'center'}}
                  />
                  <TouchableOpacity
                    onPress={this.press}
                    style={{
                      opacity: 1,
                      width: width * 0.72,
                      height: height * 0.07,
                      alignSelf: 'center',
                      backgroundColor: theme.secondaryColor,
                      marginTop: height * 0.01,
                      borderBottomEndRadius: 15,
                      borderBottomStartRadius: 15,
                    }}>
                    <Text
                      style={{
                        textAlign: 'center',
                        marginTop: height * 0.02,
                        fontSize: RFValue(15, height),
                        color: 'white',
                      }}>
                      Apply Filter
                    </Text>
                  </TouchableOpacity>
                </View>
              ) : (
                this.state.Guides.TourGuides &&
                this.state.Guides.TourGuides.map((input, index) => {
                  return (
                    <ChooseGuideComp
                      navigation={this.props.navigation}
                      data={input}
                      tourData={tour}
                    />
                  );
                })
              )}
            </View>
          </ImageBackground>
        </ScrollView>
      </View>
    );
  }
}
const mapStateToProps = (state) => {
  const {langId, appResources, token, countries, languages, user} = state.app;
  return {langId, appResources, token, countries, languages, user};
};

const mapDispatchToProps = {
  getTourGuides,
  getLanguages,
  getResources,
};

export default connect(mapStateToProps, mapDispatchToProps)(ChooseGuide);
