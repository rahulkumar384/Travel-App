import React, {Component} from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  Image,
  ScrollView,
  Dimensions,
  TextInput,
} from 'react-native';
import styles from './style';

const {width, height} = Dimensions.get('window');
import Header from '../../components/Header';
import LinearGradient from 'react-native-linear-gradient';
import MyProfile from '../../components/Profile';
import Svg, {Ellipse, Circle} from 'react-native-svg';
import {Avatar} from 'react-native-paper';
import CustomAlert from '../../components/CustomAlert';
import LoaderView from '../../components/Loader';
import {getResources, signOut} from '../../redux/actions/app';
import {connect} from 'react-redux';
import icons from '../../utils/icons';
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';

class showProfile extends Component {
  constructor() {
    super();

    this.state = {alertMsg: '', showAlert: false, loader: false};
  }
  pressHandler = () => {
    this.props.signOut();
    this.props.navigation.reset({
      index: 0,
      routes: [{name: 'SignIn'}],
    });
  };
  render() {
    const {params} = this.props.route;
    const user = params.user;

    let gender = null;
    if (user.GenderID == 1) {
      gender = 'Male';
    } else {
      gender = 'Female';
    }
    const {appResources} = this.props;
    return (
      <View style={styles.container}>
        <CustomAlert
          isVisible={this.state.showAlert}
          onPress={() =>
            this.setState({showAlert: false, alertMsg: this.state.alertMsg})
          }
          message={this.state.alertMsg}
        />
        <LoaderView isVisible={this.state.loader} />
        <ScrollView
          contentContainerStyle={{
            alignItems: 'center',
            paddingBottom: height * 0.15,
          }}>
          <LinearGradient
            start={{x: 0, y: 0}}
            end={{x: 1, y: 0}}
            colors={['#FC4F1C', '#F89230', '#F9B434']}
            style={styles.linearGradient}>
            <Header
              navigation={this.props.navigation}
              isLeft={true}
              leftIcon={icons.back}
              navi={() => this.props.navigation.goBack()}
              isBorder={true}
              isHead={true}
              Head={'Profile'}
            />
          </LinearGradient>

          <View style={{width: width * 0.9, alignItems: 'center'}}>
            <View style={styles.circle}>
              <View
                style={{width: '100%', height: '100%', position: 'absolute'}}>
                <Svg style={{width: '100%', height: '100%'}}>
                  <Circle cx="50%" cy="50%" r="45%" fill="#EAF6F0" />
                </Svg>
              </View>
              <View
                style={{
                  width: '80%',
                  height: '80%',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                {user.ProfileUrl == '' ? (
                  <Avatar.Image
                    size={150}
                    style={{backgroundColor: '#EAF6F0'}}
                    source={require('../../assets/dummypicture.png')}
                  />
                ) : (
                  <Avatar.Image
                    size={150}
                    style={{backgroundColor: '#EAF6F0'}}
                    source={{uri: user.ProfileUrl}}
                  />
                )}
              </View>
            </View>

            <View style={{alignItems: 'center', marginBottom: height * 0.03}}>
              <Text style={styles.aboutMain}>{user.FullName}</Text>
            </View>

            <View>
              <View style={styles.cont}>
                <View
                  style={{
                    width: width * 0.9,
                    flexDirection: 'row',
                    marginTop: height * 0.02,
                    justifyContent: 'space-between',
                  }}>
                  <View
                    style={{flexDirection: 'column', marginLeft: width * 0.04}}>
                    <Text style={styles.heading}>Name:</Text>
                    <Text style={styles.aboutMain}>{user.FullName}</Text>
                  </View>
                </View>
              </View>

              <View style={styles.cont}>
                <View
                  style={{
                    width: width * 0.9,
                    flexDirection: 'row',
                    marginTop: height * 0.02,
                    justifyContent: 'space-between',
                  }}>
                  <View
                    style={{flexDirection: 'column', marginLeft: width * 0.04}}>
                    <Text style={styles.heading}>Phone No:</Text>
                    <Text style={styles.aboutMain}>{user.PhoneNo}</Text>
                  </View>
                </View>
              </View>

              <View style={styles.cont}>
                <View
                  style={{
                    width: width * 0.9,
                    flexDirection: 'row',
                    marginTop: height * 0.02,
                    justifyContent: 'space-between',
                  }}>
                  <View
                    style={{flexDirection: 'column', marginLeft: width * 0.04}}>
                    <Text style={styles.heading}>Email Address:</Text>
                    <Text style={styles.aboutMain}>{user.EmailAddress}</Text>
                  </View>
                </View>
              </View>
            </View>
          </View>
        </ScrollView>
      </View>
    );
  }
}
const mapStateToProps = (state) => {
  const {appResources, token, countries, languages, user} = state.app;
  return {appResources, token, countries, languages, user};
};

const mapDispatchToProps = {
  getResources,
  signOut,
};

export default connect(mapStateToProps, mapDispatchToProps)(showProfile);
