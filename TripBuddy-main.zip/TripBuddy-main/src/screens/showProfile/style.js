import {StyleSheet, Dimensions} from 'react-native';
import theme from '../../common/theme';
const {width, height} = Dimensions.get('window');
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';

export default StyleSheet.create({
  container: {backgroundColor: 'white', width: width, height: height},
  bookButton: {
    width: '80%',
    height: height * 0.07,
    backgroundColor: theme.secondaryColor,
    marginTop: height * 0.02,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
  bgImage: {
    height: height,
    width: width,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scrollViewStyle: {
    width,
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingBottom: height * 0.07,
    marginTop: height * 0.03,
  },
  linearGradient: {
    width: width,
    // height: height * 0.1,
    // position: 'absolute',
    top: 0,
    //  zIndex: -1,
  },
  circle: {
    width: 150,
    height: 150,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: height * 0.05,
    marginBottom: height * 0.02,
  },

  Viewall: {
    justifyContent: 'center',
    alignItems: 'center',
    color: 'green',
    fontSize: RFValue(15, height),
    marginRight: width * 0.04,
  },
  aboutMain: {
    fontSize: RFValue(18, height),
    //fontFamily: 'Montserrat-Regular',
    //fontWeight: 'bold',
    color: 'black',
    marginBottom: height * 0.01,
  },
  cont: {
    backgroundColor: '#F0F7F2',
    width: width * 0.9,
    borderRadius: 15,
    marginBottom: height * 0.02,
    paddingBottom: height * 0.01,
  },
  heading:{
    fontSize: RFValue(20, height),
    //fontFamily: 'Montserrat-Regular',
    fontWeight: 'bold',
    color: 'black',
    marginBottom: height * 0.01,
    textDecorationLine: 'underline'
  }
});
