import React, {Component} from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  Dimensions,
  ImageBackground,
  FlatList,
  Modal,
} from 'react-native';
import styles from './style';
const {width, height} = Dimensions.get('window');
import Header from '../../components/Header';
import icons from '../../utils/icons';
import CustomAlert from '../../components/CustomAlert';
import {connect} from 'react-redux';
import LoaderView from '../../components/Loader';
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';
import theme from '../../common/theme';
import {Avatar} from 'react-native-paper';
import {getTourRequest, getUpdateTourRequest} from '../../redux/actions/app';
import LinearGradient from 'react-native-linear-gradient';

class GuideTourDetail extends Component {
  constructor() {
    super();

    this.state = {
      isRefreshing: false,
      alertMsg: '',
      showAlert: false,
      TourRequest: [],
      loader: false,
      showAlert: false,
      alertMsg: '',
      statusID: null,
      isVisible: true,
    };
  }

  componentDidMount = () => {
    this.loaddata();
  };

  loaddata = () => {
    const {params} = this.props.route;
    const tour = params.tour;
    this.setState({loader: true});
    const {appResources} = this.props;
    let payload = {
      tourId: tour.VenueID,
      tourGuideId: this.props.user.UserID,
      langId: 2,
    };
    this.props.getTourRequest(payload).then(
      (response) => {
        if (response.StatusCode == 200) {
          if (response.Data) {
            this.setState({
              TourRequest: response.Data,
              loader: false,
              moreDataLoader: false,
              isRefreshing: false,
            });
            // alert(JSON.stringify(response.Data));
          } else {
            this.setState({
              loader: false,
              isRefreshing: false,
            });
          }
        } else {
          this.setState({
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };

  onPress = (status, tourBookingId) => {
    this.setState({loader: true});
    let payload = {
      tourBookingId: tourBookingId,
      tourGuideId: this.props.user.UserID,
      statusId: status,
    };

    this.props.getUpdateTourRequest(payload).then(
      (response) => {
        if (response.StatusCode == 200) {
          if (response.Data && response.Data.length > 0) {
            this.setState({TourRequest: [], loader: false}, () => {
              this.loaddata();
            });
          } else {
            this.setState({
              loader: false,
              isRefreshing: false,
            });
          }
        } else {
          this.setState({
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };

  onRefresh() {
    this.setState({TourRequest: [], isRefreshing: true}, () => {
      this.loaddata();
    });
  }

  render() {
    const {params} = this.props.route;
    const tour = params.tour;

    return (
      <View style={styles.container}>
        <CustomAlert
          isVisible={this.state.showAlert}
          onPress={() => this.setState({showAlert: false, alertMsg: ''})}
          message={this.state.alertMsg}
        />
        <LoaderView isVisible={this.state.loader} />

        <ScrollView contentContainerStyle={styles.scrollViewStyle}>
          <LinearGradient
            start={{x: 0, y: 0}}
            end={{x: 1, y: 0}}
            colors={['#FC4F1C', '#F89230', '#F9B434']}
            style={styles.linearGradient}>
            <Header
              navigation={this.props.navigation}
              isLeft={true}
              leftIcon={icons.back}
              navi={() => this.props.navigation.goBack()}
              isBorder={true}
              isHead={true}
              Head={'Tour Request'}
            />
          </LinearGradient>
          <ImageBackground
            source={{uri: tour.LogoUrl}}
            imageStyle={{width: width, height: height * 0.33}}
            style={{width: width, resizeMode: 'stretch'}}>
            <View
              style={{
                width: width * 0.92,
                alignSelf: 'center',
                marginTop: height * 0.18,
                borderRadius: 15,
                backgroundColor: 'white',
                // elevation: 10,
              }}>
              <View style={{padding: height * 0.015}}>
                <View
                  style={{
                    marginTop: height * 0.02,
                  }}>
                  <Text
                    style={{fontSize: RFValue(20, height), color: '#FFD700'}}>
                    {tour.TourName}
                  </Text>
                </View>

                <View>
                  <Text
                    style={{
                      fontSize: RFValue(17, height),
                      marginTop: height * 0.01,
                    }}>
                    You can Accept or Reject Tours :
                  </Text>
                </View>

                <View style={{marginLeft: width * 0.01}}>
                  <Text
                    style={{
                      color: 'black',
                      fontWeight: 'bold',
                      fontSize: RFValue(20, height),
                      marginTop: height * 0.01,
                    }}>
                    Tour Requests
                  </Text>
                </View>
              </View>
              <FlatList
                data={this.state.TourRequest}
                style={{
                  height: height * 0.5,
                }}
                renderItem={({item}) => {
                  return (
                    <TouchableOpacity
                      onPress={() =>
                        this.props.navigation.navigate('showProfile', {
                          user: item,
                        })
                      }
                      style={{
                        flexDirection: 'row',
                        justifyContent: 'space-between',
                        width: width * 0.88,
                        alignSelf: 'center',
                        padding: height * 0.01,
                      }}>
                      {item.ProfileUrl == '' ? (
                        <View
                          style={{
                            width: width * 0.1,
                            marginRight: width * 0.01,
                          }}>
                          <Avatar.Image
                            size={50}
                            source={require('../../assets/dummypicture.png')}
                          />
                        </View>
                      ) : (
                        <View
                          style={{
                            width: width * 0.1,
                            marginRight: width * 0.01,
                          }}>
                          <Avatar.Image
                            size={50}
                            source={{uri: item.ProfileUrl}}
                          />
                        </View>
                      )}

                      <View
                        style={{
                          alignSelf: 'center',
                          width: '45%',
                          //  backgroundColor: 'red',
                        }}>
                        <Text
                          style={{
                            fontWeight: 'bold',
                            fontSize: RFValue(12, height),
                          }}>
                          {item.FullName}
                        </Text>
                        <Text style={{fontSize: RFValue(10, height)}}>
                          {item.DurationText}
                        </Text>
                      </View>
                      <View
                        style={{
                          flexDirection: 'row',
                          justifyContent: 'space-between',
                          height: '100%',
                        }}>
                        {item.StatusID == 5 ? (
                          <View
                            style={{
                              // backgroundColor: 'blue',
                              width: width * 0.27,
                            }}>
                            <TouchableOpacity
                              onPress={
                                () =>
                                  this.props.navigation.navigate('Map', {
                                    items: item,
                                  })
                                // this.onPress(9, item.TourBookingID)
                              }
                              style={{
                                width: width * 0.2,
                                height: height * 0.04,
                                //padding: height * 0.008,
                                backgroundColor:
                                  ('#FC4F1C', '#F89230', '#F9B434'),
                                alignSelf: 'center',
                                justifyContent: 'center',
                                borderRadius: 10,
                                //marginRight: 5,
                                alignItems: 'center',
                              }}>
                              <Text
                                style={{
                                  color: 'white',
                                  textAlign: 'center',
                                  fontSize: RFValue(10, height),
                                }}>
                                START
                              </Text>
                            </TouchableOpacity>
                          </View>
                        ) : null}

                        {item.StatusID == 4 ? (
                          <View
                            style={{
                              //   backgroundColor: 'blue',
                              width: width * 0.28,
                              flexDirection: 'row',
                            }}>
                            <TouchableOpacity
                              onPress={() =>
                                this.onPress(5, item.TourBookingID)
                              }
                              style={{
                                width: width * 0.14,
                                padding: height * 0.008,
                                backgroundColor: 'green',
                                alignSelf: 'center',
                                justifyContent: 'center',
                                borderRadius: 10,
                                marginRight: 5,
                              }}>
                              <Text
                                style={{
                                  color: 'white',
                                  textAlign: 'center',
                                  fontSize: RFValue(12, height),
                                }}>
                                Accept
                              </Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                              onPress={() =>
                                this.onPress(6, item.TourBookingID)
                              }
                              style={{
                                width: width * 0.14,
                                padding: height * 0.008,
                                backgroundColor: 'red',
                                alignSelf: 'center',
                                justifyContent: 'center',
                                borderRadius: 10,
                              }}>
                              <Text
                                style={{
                                  color: 'white',
                                  textAlign: 'center',
                                  fontSize: RFValue(12, height),
                                }}>
                                Reject
                              </Text>
                            </TouchableOpacity>
                          </View>
                        ) : null}
                      </View>
                    </TouchableOpacity>
                  );
                }}
                contentContainerStyle={styles.flatelist}
                horizontal={false}
                showsHorizontalScrollIndicator={false}
                ListEmptyComponent={
                  <Text
                    style={{
                      fontSize: RFValue(20, height),
                      color: theme.secondaryColor,
                      marginBottom: height * 0.02,
                      marginLeft: width * 0.04,
                    }}>
                    No Tour Requests for now!
                  </Text>
                }></FlatList>
           
            </View>
          </ImageBackground>
        </ScrollView>
      </View>
    );
  }
}

const mapStateToProps = (state) => {
  const {date, langId, user, appResources} = state.app;
  return {date, langId, user, appResources};
};

const mapDispatchToProps = {
  getTourRequest,
  getUpdateTourRequest,
};

export default connect(mapStateToProps, mapDispatchToProps)(GuideTourDetail);
