import {StyleSheet, Dimensions} from 'react-native';
import theme from '../../common/theme';
const {width, height} = Dimensions.get('window');
import { RFPercentage, RFValue } from 'react-native-responsive-fontsize';


export default StyleSheet.create({
  container: {
    height: height,
    width: width,
    //backgroundColor: 'red',
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingBottom: 10
  },
  scrollViewStyle: {
    height,
    width,
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingBottom:height*0.02
  },
  inputFields: {
    width: '80%',
    height: height * 0.085,
    borderBottomWidth:1,
    borderBottomColor:'white',
    fontSize: RFValue(18, height),
    color: '#000',
    marginTop: height * 0.02,
    flexDirection:'row',
  }

  
});
