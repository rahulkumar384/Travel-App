import React, {Component} from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  Image,
  ScrollView,
  Dimensions,
  ImageBackground,
  TextInput,
} from 'react-native';
import styles from './style';
// import {GoogleSignin,statusCodes} from '@react-native-community/google-signin';
import {RFValue} from 'react-native-responsive-fontsize';

// GoogleSignin.configure({
//   webClientId:
//     '131304223639-a5tugs60smfld5q5r3bnt9s28u8c4j3f.apps.googleusercontent.com',
// });
import {
  getResources,
  signIn,
  signIn2,
  checkEmail,
} from '../../redux/actions/app';
// import {
//   LoginButton,
//   AccessToken,
//   LoginManager,
//   GraphRequest,
//   GraphRequestManager,
// } from 'react-native-fbsdk';
import {connect} from 'react-redux';
const {width, height} = Dimensions.get('window');
import CustomAlert from '../../components/CustomAlert';
import LoaderView from '../../components/Loader';
class SignIn extends Component {
  state = {
    email: '',
    password: '',
    loader: false,
    isRefreshing: false,
    alertMsg: '',
    showAlert: false,
  };
  handleEmail = (text) => {
    this.setState({email: text});
  };
  handlePassword = (text) => {
    this.setState({password: text});
  };

  SignIn = () => {
    this.setState({loader: true});
    const {appResources} = this.props;
    let payload = {
      email: this.state.email,
      password: this.state.password,
    };
    this.props.signIn(payload).then(
      (response) => {
        if (response.StatusCode == 200) {
          if (response.Token) {
            this.setState({
              loader: false,
            });
            //  alert(JSON.stringify(response.Data.IsTourGuide))
            if (response.Data.IsTourGuide) {
              // alert(JSON.stringify(response.Data.IsTourGuide))
              this.props.navigation.reset({
                index: 0,
                routes: [{name: 'Schedule'}],
              });
            } else {
              //  alert(JSON.stringify(response.Data.IsTourGuide))
              this.props.navigation.reset({
                index: 0,
                routes: [{name: 'Discover'}],
              });
            }
          } else {
            this.setState({
              loader: false,
              showAlert: true,
              alertMsg: 'Invalid Email Or Password',
            });
          }
        } else {
          this.setState({
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };

 

  render() {
    const {appResources, token} = this.props;
    console.log(token);
    return (
      <View style={styles.container}>
        <CustomAlert
          isVisible={this.state.showAlert}
          onPress={() => this.setState({showAlert: false, alertMsg: ''})}
          message={this.state.alertMsg}
        />
        <LoaderView isVisible={this.state.loader} />
        <ScrollView
          keyboardDismissMode={true}
          contentContainerStyle={styles.scrollViewStyle}>
          <ImageBackground
            source={require('../../assets/Signin.png')}
            style={{height: height, width: width}}
            imageStyle={{resizeMode: 'cover'}}>
            <View style={{alignItems: 'center', marginTop: height * 0.27}}>
              <Text
                style={{
                  fontSize: RFValue(40, height),
                  fontWeight: 'bold',
                  color: 'white',
                }}>
                Trip Buddy
              </Text>
              <Text
                style={{
                  fontSize: RFValue(20, height),
                  fontWeight: 'normal',
                  color: 'white',
                  marginTop: height * 0.02,
                }}>
                Book Guide
              </Text>
            </View>

            <View style={{alignItems: 'center'}}>
              <View style={styles.inputFields}>
                <Image
                  source={require('../../assets/user.png')}
                  style={{
                    //backgroundColor:'red',
                    resizeMode: 'contain',
                    width: width * 0.07,
                    height: height * 0.04,
                    alignSelf: 'center',
                    marginRight: width * 0.02,
                  }}
                />
                <TextInput
                  placeholder={'Email-Address'}
                  onChangeText={this.handleEmail}
                  style={[
                    {
                      height: height * 0.0815,
                      width: width * 0.72,
                      color: 'white',
                      //backgroundColor:'red'
                    },
                  ]}
                  placeholderTextColor="white"
                  keyboardType={'email-address'}
                />
              </View>

              <View style={styles.inputFields}>
                <Image
                  source={require('../../assets/lock.png')}
                  style={{
                    //backgroundColor:'red',
                    resizeMode: 'contain',
                    width: width * 0.07,
                    height: height * 0.04,
                    alignSelf: 'center',
                    marginRight: width * 0.02,
                  }}
                />
                <TextInput
                  placeholder={'Password'}
                  secureTextEntry={true}
                  onChangeText={this.handlePassword}
                  style={[
                    {
                      height: height * 0.0815,
                      width: width * 0.72,
                      color: 'white',
                    },
                  ]}
                  placeholderTextColor="white"
                />
              </View>
            </View>

            <TouchableOpacity
              onPress={this.SignIn}
              style={{
                width: width * 0.8,
                height: height * 0.065,
                alignSelf: 'center',
                marginTop: height * 0.06,
              }}>
              <View
                style={{
                  resizeMode: 'contain',
                  width: width * 0.8,
                  height: height * 0.07,
                  backgroundColor: 'white',
                  justifyContent: 'center',
                  alignItems: 'center',
                }}>
                <Text
                  style={{
                    color: 'black',
                    textAlign: 'center',
                    fontSize: RFValue(17, height),
                  }}>
                  Sign In
                </Text>
              </View>
            </TouchableOpacity>
            <View
              style={{
                width: width * 0.79,
                height: height * 0.07,
                // backgroundColor: 'red',
                marginTop: height * 0.02,
                justifyContent: 'space-between',
                flexDirection: 'row',
                alignSelf: 'center',
              }}>
              <TouchableOpacity
                onPress={() => this.props.navigation.navigate('SignUp')}
                style={{
                  // width: width * 0.8,
                  // height: height * 0.065,

                  // backgroundColor: 'yellow',
                  alignSelf: 'center',
                  // justifyContent: 'center',
                }}>
                <Text
                  style={{
                    color: 'white',
                    textAlign: 'center',
                    fontSize: RFValue(15, height),
                  }}>
                  Sign Up
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={()=> this.props.navigation.navigate('ForgetPassword')}
                style={{
                  // width: width * 0.8,
                  // height: height * 0.065,
                  // backgroundColor: 'blue',
                  alignSelf: 'center',
                  // justifyContent: 'center',
                }}>
                <Text
                  style={{
                    color: 'white',
                    textAlign: 'center',
                    fontSize: RFValue(15, height),
                  }}>
                  Forget Password?
                </Text>
              </TouchableOpacity>
            </View>
          </ImageBackground>
        </ScrollView>
      </View>
    );
  }
}

const mapStateToProps = (state) => {
  const {langId, appResources, token} = state.app;
  return {langId, appResources, token};
};

const mapDispatchToProps = {
  getResources,
  signIn2,
  signIn,
  checkEmail,
};

export default connect(mapStateToProps, mapDispatchToProps)(SignIn);
