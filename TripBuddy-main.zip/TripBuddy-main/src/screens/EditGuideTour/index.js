import React, {Component} from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  Dimensions,
  TextInput,
  Image,
} from 'react-native';
import styles from './Style';
import LinearGradient from 'react-native-linear-gradient';
const {width, height} = Dimensions.get('window');
import Header from '../../components/Header';
import {editTour, currency} from '../../redux/actions/app';
import {connect} from 'react-redux';
import LoaderView from '../../components/Loader';
import CustomAlert from '../../components/CustomAlert';
import moment from 'moment';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import DropDownPicker from 'react-native-dropdown-picker';
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';
import theme from '../../common/theme';
import icons from '../../utils/icons';

class EditGuideTour extends Component {
  constructor(props) {
    super(props);

    const {params} = this.props.route;
    const item = params.item;
    // alert(JSON.stringify(item));
    this.state = {
      showAlert: false,
      alertMsg: '',
      ammount: '',
      tourname: item && item.TourName ? item.TourName : '',
      totalperson: item.TotalPerson,
      latlng: item && item.LatLng ? item.LatLng : '',
      directioninfo: item && item.DirectionInfo ? item.DirectionInfo : '',
      chosendate: item && item.TourDate ? item.TourDate : '',
      chosentime: item && item.Timing ? item.Timing : '',
      chosencurrency: '',
      chosenvenue: '',
      isVisibleDate: false,
      isVisibleTime: false,
      Currency: [],
      VenuesList: [],
      CountryList: [],
      data: null,
    };
  }

  showDatePicker = () => {
    this.setState({isVisibleDate: true});
  };
  hideDatePicker = () => {
    this.setState({isVisibleDate: false});
  };
  handleConfirm = (date) => {
    this.setState({
      isVisibleDate: false,
      chosendate: moment(date).format('YYYY-MM-DD'),
    });
    console.log('A date has been picked: ', date);
  };
  /*----------------------------------------------------------------- */
  showTimePicker = () => {
    this.setState({isVisibleTime: true});
  };
  handleTimeConfirm = (time) => {
    this.setState({
      isVisibleTime: false,
      chosentime: moment(time).format('LTS'),
    });
    console.log('A time has been picked: ', time);
  };
  hideTimePicker = () => {
    this.setState({isVisibleTime: false});
  };

  componentDidMount() {
    this.getCurrency();
  }

  getCurrency = () => {
    const {appResources} = this.props;

    this.props.currency((LanguageID = 1)).then(
      (response) => {
        //alert(JSON.stringify(response));
        if (response.StatusCode == 200) {
          this.setState({
            Currency: response.Data,
            loader: false,
          });
          //alert(JSON.stringify(response.Data));
        } else {
          this.setState({
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };

  editMytour = () => {
    const {params} = this.props.route;
    const item = params.item;
    if (
      !this.state.tourname ||
      !this.state.chosendate ||
      !this.state.chosentime ||
      !this.state.totalperson ||
      !this.state.latlng ||
      !this.state.directioninfo ||
      !this.state.ammount ||
      !this.state.chosencurrency
    ) {
      return this.setState({
        showAlert: true,
        alertMsg: 'Please Enter All Field',
      });
    } else {
      const {user} = this.props;
      const {appResources} = this.props;
      let payload = {
        tourId: item.TourID,
        userid: user.UserID,
        venueId: item.VenueID,
        tourname: this.state.tourname,
        tourdate: this.state.chosendate,
        timing: this.state.chosentime,
        totalperson: this.state.totalperson,
        latlng: this.state.latlng,
        directioninfo: this.state.directioninfo,
        amount: this.state.ammount,
        currencyid: this.state.chosencurrency,
      };

      this.props.editTour(payload).then(
        (response) => {
          if (response.StatusCode == 200) {
            this.setState({
              loader: false,
              showAlert: true,
              alertMsg: 'Tour has been edit and waiting for approval by Admin',
            });
            if (response.Data != null) {
              this.props.navigation.push('Schedule');
            }
          } else {
            this.setState({
              loader: false,
              showAlert: true,
              alertMsg: '',
            });
          }
        },
        (error) => {
          this.setState({
            loader: false,
            isRefreshing: false,
            showAlert: true,
            alertMsg:
              error && error.message
                ? error.message
                : appResources &&
                  appResources.OopsSomething &&
                  appResources.OopsSomething,
          });
        },
      );
    }
  };

  render() {
    return (
      <View style={styles.container}>
        <LinearGradient
          start={{x: 0, y: 0}}
          end={{x: 1, y: 0}}
          colors={['#FC4F1C', '#F89230', '#F9B434']}
          style={styles.linearGradient}
        />
        <CustomAlert
          isVisible={this.state.showAlert}
          onPress={() => this.setState({showAlert: false, alertMsg: ''})}
          message={this.state.alertMsg}
        />
        <ScrollView
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={styles.scrollViewStyle}
          showsVerticalScrollIndicator={false}>
            <LinearGradient
            start={{x: 0, y: 0}}
            end={{x: 1, y: 0}}
            colors={['#FC4F1C', '#F89230', '#F9B434']}
            style={styles.linearGradient}>
            <Header
              navigation={this.props.navigation}
              isLeft={true}
              leftIcon={icons.back}
              navi={() => this.props.navigation.goBack()}
              isBorder={true}
              isHead={true}
              Head={'Edit Tour'}
            />
          </LinearGradient>
          
          <View
            style={{
              width: width * 0.9,
              // marginTop: height * 0.1,
              // backgroundColor: 'black',
              alignSelf: 'center',
            }}
          />
          <View
            style={{
              width: width * 0.9,
              alignSelf: 'center',
              // backgroundColor: 'yellow',
              justifyContent: 'center',
              paddingBottom: height * 0.1,
            }}>
            <View style={styles.margin}>
              <TextInput
                placeholder={'Enter Tour Name'}
                onChangeText={(text) => {
                  this.setState({tourname: text});
                }}
                value={this.state.tourname}
                style={[
                  {
                    height: height * 0.07,
                    width: width * 0.7,
                    color: 'black',
                    //backgroundColor: 'red',
                    marginLeft: width * 0.015,
                  },
                ]}
                placeholderTextColor="black"
              />
            </View>

            {/* ------------------------------------date picker------------------------------------ */}

            <DateTimePickerModal
              isVisible={this.state.isVisibleDate}
              mode={'date'}
              onConfirm={this.handleConfirm}
              onCancel={this.hideDatePicker}
            />
            <DateTimePickerModal
              isVisible={this.state.isVisibleTime}
              mode={'time'}
              onConfirm={this.handleTimeConfirm}
              onCancel={this.hideTimePicker}
            />
            {/* ------------------------------------date picker------------------------------------ */}
            <View
              style={{
                justifyContent: 'space-between',
                flexDirection: 'row',
                width: width * 0.5,
                marginBottom: height * 0.02,
                alignItems: 'center',
              }}>
              <Text style={styles.heading}>Tour Date:</Text>
              <Text style={{fontSize: RFPercentage(1.5)}}>
                {'   '}
                {this.state.chosendate}
                {'   '}
              </Text>
              <TouchableOpacity
                style={{
                  width: width * 0.2,
                  height: height * 0.04,
                  alignContent: 'center',
                  justifyContent: 'center',
                  backgroundColor: theme.secondaryColor,
                  borderRadius: 9,
                }}
                onPress={this.showDatePicker}>
                <Text
                  style={{
                    color: 'white',
                    textAlign: 'center',
                    fontSize: RFValue(10, height),
                  }}>
                  SELECT DATE
                </Text>
              </TouchableOpacity>
            </View>
            <View
              style={{
                justifyContent: 'space-between',
                flexDirection: 'row',
                width: width * 0.5,
                marginBottom: height * 0.02,
                alignItems: 'center',
              }}>
              <Text style={styles.heading}>Tour Timing:</Text>
              <Text style={{fontSize: RFPercentage(1.5)}}>
                {'   '}
                {this.state.chosentime}
                {'   '}
              </Text>

              <TouchableOpacity
                style={{
                  width: width * 0.2,
                  height: height * 0.04,
                  alignContent: 'center',
                  justifyContent: 'center',
                  backgroundColor: theme.secondaryColor,
                  borderRadius: 9,
                }}
                onPress={this.showTimePicker}>
                <Text
                  style={{
                    color: 'white',
                    textAlign: 'center',
                    fontSize: RFValue(10, height),
                  }}>
                  SELECT TIME
                </Text>
              </TouchableOpacity>
            </View>
            <View style={styles.margin}>
              <TextInput
                placeholder={'Enter Total Person'}
                onChangeText={(text) => {
                  this.setState({totalperson: text});
                }}
                value={this.state.totalperson.toString()}
                style={[
                  {
                    height: height * 0.07,
                    width: width * 0.7,
                    color: 'black',
                    //backgroundColor: 'red',
                    marginLeft: width * 0.015,
                  },
                ]}
                placeholderTextColor="black"
                keyboardType={'number-pad'}
              />
            </View>

            {/* ------------------------------------------------------------------------------------------------ */}
            <View style={{height: height * 0.02}} />

            <View style={styles.margin}>
              <TextInput
                placeholder={'Enter Amount'}
                keyboardType={'numeric'}
                onChangeText={(text) => {
                  this.setState({ammount: text});
                }}
                value={this.state.ammount}
                style={[
                  {
                    height: height * 0.07,
                    width: width * 0.7,
                    color: 'black',
                    //backgroundColor: 'red',
                    marginLeft: width * 0.015,
                  },
                ]}
                placeholderTextColor="#D3D3D3"
              />
            </View>
            <DropDownPicker
              zIndex={5000}
              items={this.state.Currency.map((item) => ({
                label: item.Currency,
                value: item.CurrencyID,
              }))}
              containerStyle={{
                height: height * 0.08,
                width: width * 0.7,
                // backgroundColor: '#F5F5F5',
              }}
              style={{
                // backgroundColor:'red',
                backgroundColor: 'transparent',
                // height: height * 0.0815,
                width: width * 0.73,
                // borderWidth: 1,
                borderColor: 'black',
                borderTopWidth: 0,
                borderBottomWidth: 1.5,
                borderLeftWidth: 0,
                borderRightWidth: 0,
              }}
              placeholderStyle={{color: '#D3D3D3'}}
              itemStyle={{
                justifyContent: 'flex-start',
                backgroundColor: 'white',
              }}
              defaultValue={this.state.data}
              placeholder={'Enter Currency'}
              showArrow={false}
              labelStyle={{
                zIndex: 5000,
                backgroundColor: 'transparent',
                color: 'black',
              }}
              dropDownStyle={{backgroundColor: 'white'}}
              onChangeItem={(item) =>
                this.setState({
                  chosencurrency: item.value,
                })
              }
            />
            <View style={{height: height * 0.02}} />
            <View style={styles.margin}>
              <TextInput
                placeholder={'Enter Longitude , Latitude'}
                onChangeText={(text) => {
                  this.setState({latlng: text});
                }}
                value={this.state.latlng}
                style={[
                  {
                    height: height * 0.07,
                    width: width * 0.35,
                    color: 'black',
                    //backgroundColor: 'red',
                    marginLeft: width * 0.015,
                  },
                ]}
                placeholderTextColor="black"
                keyboardType={'number-pad'}
              />
            </View>
            <View style={styles.margin}>
              <TextInput
                placeholder={'Tour Description'}
                onChangeText={(text) => {
                  this.setState({directioninfo: text});
                }}
                value={this.state.directioninfo}
                style={[
                  {
                    height: height * 0.07,
                    width: width * 0.7,
                    color: 'black',
                    //backgroundColor: 'red',
                    marginLeft: width * 0.015,
                  },
                ]}
                placeholderTextColor="black"
              />
            </View>

            <TouchableOpacity
              style={{
                width: width * 0.7,
                height: height * 0.06,
                backgroundColor: theme.secondaryColor,
                alignSelf: 'center',
                borderRadius: 15,
                alignItems: 'center',
                justifyContent: 'center',
              }}
              onPress={this.editMytour}>
              <Text
                style={{
                  fontSize: RFPercentage(2),
                  textAlign: 'center',
                  color: 'white',
                }}>
                SAVE CHANGES
              </Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    );
  }
}

const mapStateToProps = (state) => {
  const {date, langId, user, appResources} = state.app;
  return {date, langId, user, appResources};
};

const mapDispatchToProps = {
  editTour,
  currency,
};

export default connect(mapStateToProps, mapDispatchToProps)(EditGuideTour);
