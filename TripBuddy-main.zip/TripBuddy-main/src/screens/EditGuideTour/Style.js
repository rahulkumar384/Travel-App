import {StyleSheet, Dimensions} from 'react-native';
import theme from '../../common/theme';
const {width, height} = Dimensions.get('window');
import { RFPercentage, RFValue } from 'react-native-responsive-fontsize';


export default StyleSheet.create({
  container: {
    height: height,
    width: width,
    backgroundColor: theme.primaryColor,
    justifyContent: 'flex-start',
  
  },
  linearGradient: {
    width: width,
    // height: height * 0.1,
    // position: 'absolute',
    top: 0,
    //  zIndex: -1,
  },
  margin: {
    borderBottomWidth: 1,
    width: width * 0.73,
    marginBottom: height * 0.02,
  },
  heading:{
    fontSize:RFPercentage(1.5),
    fontWeight:'bold',
  },
  scrollViewStyle: {
    width,
    justifyContent: 'flex-start',
    alignSelf: 'center',
    paddingBottom: height * 0.02,
  },
});
