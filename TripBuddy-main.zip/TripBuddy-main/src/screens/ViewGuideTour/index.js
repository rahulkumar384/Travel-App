import React, {Component} from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  Image,
  ScrollView,
  Dimensions,
  FlatList,
} from 'react-native';
import styles from './Style';
import LinearGradient from 'react-native-linear-gradient';
const {width, height} = Dimensions.get('window');
import {getCountries, getCities} from '../../redux/actions/app';
import icons from '../../utils/icons';
import {connect} from 'react-redux';
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';
import Header from '../../components/Header';
class ViewGuideTour extends Component {
  constructor() {
    super();

    this.state = {
      loader: false,
      isRefreshing: false,
      alertMsg: '',
      Countries: [],
      City: [],
    };
  }
  componentDidMount = () => {
    this.country();
    this.cities();
  };

  country = () => {
    const {appResources} = this.props;

    this.props.getCountries((LanguageID = 1)).then(
      (response) => {
        if (response.StatusCode == 200) {
          this.setState({
            Countries: response.Data,
            loader: false,
          });
          //alert(JSON.stringify(response.Data));
        } else {
          this.setState({
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };

  cities = () => {
    const {params} = this.props.route;
    const viewTour = params.viewTour;
    const {appResources} = this.props;
    //console.log('ksdjfn;asdjfn;asdjfm', this.state.country);
    let payload = {
      langId: 1,
      countryId: viewTour.CountryID,
    };

    this.props.getCities(payload).then(
      (response) => {
        if (response.StatusCode == 200) {
          this.setState({
            City: response.Data,
            loader: false,
          });

          //alert(JSON.stringify(response.Data));
        } else {
          this.setState({
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };

  render() {
    const {params} = this.props.route;
    const viewTour = params.viewTour;
    // alert(JSON.stringify(viewTour));
    return (
      <View style={styles.container}>
        <ScrollView
          contentContainerStyle={styles.scrollViewStyle}
          showsVerticalScrollIndicator={false}>
          <LinearGradient
            start={{x: 0, y: 0}}
            end={{x: 1, y: 0}}
            colors={['#FC4F1C', '#F89230', '#F9B434']}
            style={styles.linearGradient}>
            <Header
              navigation={this.props.navigation}
              isLeft={true}
              leftIcon={icons.back}
              navi={() => this.props.navigation.goBack()}
              isBorder={true}
              isHead={true}
              Head={'View Tour'}
            />
          </LinearGradient>
          
          <View
            style={{
              width: width * 0.9,
              // marginTop: height * 0.12,
              alignSelf: 'center',
            }}
          />
          <TouchableOpacity
            style={{
              width: '80%',
              height: height * 0.22,
              backgroundColor: this.state.image ? 'white' : '#383428',
              marginTop: height * 0.02,
              marginBottom: height * 0.02,
              borderRadius: 10,
              justifyContent: 'center',
              alignItems: 'center',
              borderWidth: 0.5,
              borderColor: this.state.image ? 'white' : 'silver',
              alignSelf: 'center',
            }}>
            <Image
              source={{uri: viewTour.LogoUrl}}
              style={{
                width: '100%',
                height: '100%',
                resizeMode: 'stretch',
                borderRadius: 10,
              }}
            />
          </TouchableOpacity>
          {/*------------------------------------------------------------------------------*/}

          <View style={styles.cont}>
            <View
              style={{
                width: width * 0.9,
                flexDirection: 'row',
                marginTop: height * 0.02,
                justifyContent: 'space-between',
              }}>
              <View style={{flexDirection: 'row', marginLeft: width * 0.04}}>
                <Text style={styles.aboutMain}>Tour Name:</Text>
                <Text>
                  {'  '}
                  {viewTour.TourName}
                </Text>
              </View>
            </View>
          </View>

          {/*------------------------------------------------------------------------------*/}

          {/*------------------------------------------------------------------------------*/}

          <View style={styles.cont}>
            <View
              style={{
                width: width * 0.9,
                flexDirection: 'row',
                marginTop: height * 0.02,
                justifyContent: 'space-between',
              }}>
              <View style={{flexDirection: 'row', marginLeft: width * 0.04}}>
                <Text style={styles.aboutMain}>Tour Date:</Text>
                <Text>
                  {'  '}
                  {viewTour.TourDate}
                </Text>
              </View>
            </View>
          </View>

          {/*------------------------------------------------------------------------------*/}

          {/*------------------------------------------------------------------------------*/}

          <View style={styles.cont}>
            <View
              style={{
                width: width * 0.9,
                flexDirection: 'row',
                marginTop: height * 0.02,
                justifyContent: 'space-between',
              }}>
              <View style={{flexDirection: 'row', marginLeft: width * 0.04}}>
                <Text style={styles.aboutMain}>Tour Timing:</Text>
                <Text>
                  {'  '}
                  {viewTour.Timing}
                </Text>
              </View>
            </View>
          </View>

          {/*------------------------------------------------------------------------------*/}

          {/*------------------------------------------------------------------------------*/}

          <View style={styles.cont}>
            <View
              style={{
                width: width * 0.9,
                flexDirection: 'row',
                marginTop: height * 0.02,
                justifyContent: 'space-between',
              }}>
              <View style={{flexDirection: 'row', marginLeft: width * 0.04}}>
                <Text style={styles.aboutMain}>Total Person:</Text>
                <Text>
                  {'  '}
                  {viewTour.TotalPerson}
                </Text>
              </View>
            </View>
          </View>

          {/*------------------------------------------------------------------------------*/}

          {/*------------------------------------------------------------------------------*/}
          <FlatList
            data={this.state.Countries}
            renderItem={({item}) => {
              return (
                <View>
                  {viewTour.CountryID == item.CountryID ? (
                    <View
                      style={{
                        height: height * 0.05,
                        width: width * 0.9,
                        flexDirection: 'row',
                        //marginTop: height * 0.02,
                        justifyContent: 'space-between',
                        marginLeft: width * 0.03,
                        backgroundColor: '#F0F7F2',
                        borderRadius: 15,
                        marginBottom: height * 0.02,
                        paddingBottom: height * 0.01,
                        alignItems: 'center',
                      }}>
                      {viewTour.CountryID != item.CountryID ? (
                        <View
                          style={{
                            flexDirection: 'row',
                            marginLeft: width * 0.04,
                          }}></View>
                      ) : (
                        <View
                          style={{
                            flexDirection: 'row',
                            marginLeft: width * 0.04,
                          }}>
                          <Text style={styles.aboutMain}>Country:</Text>
                          <Text>
                            {'  '}
                            {item.CountryName}
                          </Text>
                        </View>
                      )}
                    </View>
                  ) : null}
                </View>
              );
            }}
          />

          {/*------------------------------------------------------------------------------*/}

          {/*------------------------------------------------------------------------------*/}

          <FlatList
            data={this.state.City}
            renderItem={({item}) => {
              return (
                <View>
                  {viewTour.CityID == item.CityID ? (
                    <View
                      style={{
                        height: height * 0.05,
                        width: width * 0.9,
                        flexDirection: 'row',
                        //marginTop: height * 0.02,
                        justifyContent: 'space-between',
                        marginLeft: width * 0.03,
                        backgroundColor: '#F0F7F2',
                        borderRadius: 15,
                        marginBottom: height * 0.02,
                        paddingBottom: height * 0.01,
                        alignItems: 'center',
                      }}>
                      {viewTour.CityID != item.CityID ? (
                        <View
                          style={{
                            flexDirection: 'row',
                            marginLeft: width * 0.04,
                          }}></View>
                      ) : (
                        <View
                          style={{
                            flexDirection: 'row',
                            marginLeft: width * 0.04,
                          }}>
                          <Text style={styles.aboutMain}>City:</Text>
                          <Text>
                            {'  '}
                            {item.CityName}
                          </Text>
                        </View>
                      )}
                    </View>
                  ) : null}
                </View>
              );
            }}
          />

          {/*------------------------------------------------------------------------------*/}

          {/*------------------------------------------------------------------------------*/}

          <View style={styles.cont}>
            <View
              style={{
                width: width * 0.9,
                flexDirection: 'row',
                marginTop: height * 0.02,
                justifyContent: 'space-between',
              }}>
              <View style={{flexDirection: 'row', marginLeft: width * 0.04}}>
                <Text style={styles.aboutMain}>Venue Name:</Text>
                <Text style={{width: width * 0.6}}>
                  {'  '}
                  {viewTour.VenueName}
                </Text>
              </View>
            </View>
          </View>

          {/*------------------------------------------------------------------------------*/}

          {/*------------------------------------------------------------------------------*/}

          <View style={styles.cont}>
            <View
              style={{
                width: width * 0.9,
                flexDirection: 'column',
                marginTop: height * 0.02,
                //justifyContent: 'space-between',
              }}>
              <View style={{flexDirection: 'row', marginLeft: width * 0.04}}>
                <Text style={styles.aboutMain}>Description:</Text>
                <Text style={{width: width * 0.6}}>
                  {'  '}
                  {viewTour.Description}
                </Text>
              </View>
            </View>
          </View>

          {/*------------------------------------------------------------------------------*/}

          {/*------------------------------------------------------------------------------*/}

          <View style={styles.cont}>
            <View
              style={{
                width: width * 0.9,
                flexDirection: 'row',
                marginTop: height * 0.02,
                justifyContent: 'space-between',
              }}>
              <View style={{flexDirection: 'row', marginLeft: width * 0.04}}>
                <Text style={styles.aboutMain}>Longitude:</Text>
                <Text>
                  {'  '}
                  {viewTour.Longitude}
                </Text>
              </View>
            </View>
          </View>

          {/*------------------------------------------------------------------------------*/}

          {/*------------------------------------------------------------------------------*/}

          <View style={styles.cont}>
            <View
              style={{
                width: width * 0.9,
                flexDirection: 'row',
                marginTop: height * 0.02,
                justifyContent: 'space-between',
              }}>
              <View style={{flexDirection: 'row', marginLeft: width * 0.04}}>
                <Text style={styles.aboutMain}>Latitude:</Text>
                <Text>
                  {'  '}
                  {viewTour.Latitude}
                </Text>
              </View>
            </View>
          </View>

          {/*------------------------------------------------------------------------------*/}

          {/*------------------------------------------------------------------------------*/}

          <View style={styles.cont}>
            <View
              style={{
                width: width * 0.9,
                flexDirection: 'column',
                marginTop: height * 0.02,
                justifyContent: 'space-between',
              }}>
              <View style={{flexDirection: 'row', marginLeft: width * 0.04}}>
                <Text style={styles.aboutMain}>Direction Info:</Text>
                <Text style={{width: width * 0.6}}>
                  {' '}
                  {viewTour.DirectionInfo}
                </Text>
              </View>
            </View>
          </View>

          {/*------------------------------------------------------------------------------*/}
        </ScrollView>
      </View>
    );
  }
}

const mapStateToProps = (state) => {
  const {date, langId, user, appResources} = state.app;
  return {date, langId, user, appResources};
};

const mapDispatchToProps = {
  getCities,
  getCountries,
};

export default connect(mapStateToProps, mapDispatchToProps)(ViewGuideTour);
