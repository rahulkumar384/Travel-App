import {StyleSheet, Dimensions} from 'react-native';
import theme from '../../common/theme';
const {width, height} = Dimensions.get('window');
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';

export default StyleSheet.create({
  container: {
    height: height,
    width: width,
    backgroundColor: theme.primaryColor,
    justifyContent: 'flex-start',
  },
  linearGradient: {
    width: width,
    // height: height * 0.1,
    // position: 'absolute',
    top: 0,
    //  zIndex: -1,
  },
  margin: {
    borderBottomWidth: 1,
    width: width * 0.7,
    marginBottom: height * 0.02,
  },
  heading: {
    fontSize: RFPercentage(1.5),
    fontWeight: 'bold',
    textDecorationLine: 'underline',
    textDecorationStyle: 'solid',
  },
  scrollViewStyle: {
    width,
    justifyContent: 'flex-start',
    alignSelf: 'center',
    paddingBottom: height * 0.02,
  },
  boxes: {
    justifyContent: 'space-between',
    flexDirection: 'row',
    width: width * 0.5,
    marginBottom: height * 0.02,
    backgroundColor: 'red',
  },
  sadebox: {
    backgroundColor: 'red',
    marginBottom: height * 0.02,
    flexDirection: 'row',
  },
  aboutMain: {
    fontSize: RFValue(15, height),
    fontWeight: 'bold',
    textDecorationLine: 'underline',
    textDecorationStyle: 'solid',
    marginRight: width * 0.01,
  },
  cont: {
    marginLeft: width * 0.03,
    backgroundColor: '#F0F7F2',
    width: width * 0.9,
    borderRadius: 15,
    marginBottom: height * 0.02,
    paddingBottom: height * 0.01,
  },
});
