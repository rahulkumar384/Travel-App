import {StyleSheet, Dimensions} from 'react-native';
import theme from '../../common/theme';
const {width, height} = Dimensions.get('window');
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';

export default StyleSheet.create({
  container: {
    backgroundColor: 'white',
    height: height,
    width: width,
  },
  linearGradient: {
    width: width,
    height: height * 0.1,
    // position: 'absolute',
    top: 0,
    //  zIndex: -1,
    marginBottom: height * 0.02,
  },
  cont: {
    width: width * 0.9,
    flexDirection: 'row',
    //marginTop:height*0.0,
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'red',
    height: height * 0.1,
    // width: width * 0.9,
    elevation: 10,
    backgroundColor: 'white',
    borderRadius: 25,
    shadowColor: 'black',
    shadowOpacity: 0.26,
    shadowOffset: {width: 0, height: 1},
    shadowRadius: 10,
  },
  flatelist: {
    height: height * 0.1,
    width: width,
    alignItems: 'center',
    //backgroundColor:'red',
    marginBottom: height * 0.02,
  },
});
