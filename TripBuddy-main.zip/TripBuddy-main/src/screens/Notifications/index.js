import React, {Component, Fragment} from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  Image,
  ScrollView,
  Dimensions,
  Button,
  SafeAreaView,
  FlatList,
} from 'react-native';
const {width, height} = Dimensions.get('window');
import LinearGradient from 'react-native-linear-gradient';
import styles from './Style';
import images from '../../utils/images';
import theme from '../../common/theme';
import Header from '../../components/Header';
import icons from '../../utils/icons';
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';
import {getResources, getNotification} from '../../redux/actions/app';
import {connect} from 'react-redux';
import CustomAlert from '../../components/CustomAlert';
import {Avatar} from 'react-native-paper';
import LoaderView from '../../components/Loader';
class Notifications extends Component {
  constructor(props) {
    super(props);
    this.state = {
      NotificationInfo: [],
      loader: false,
      showAlert: false,
      alertMsg: '',
    };
  }
  componentDidMount = () => {
    this.loaddata();
  };

  loaddata = () => {
    this.setState({loader: true});
    const {appResources} = this.props;
    // alert(JSON.stringify(this.props.user.UserID))
    let payload = {
      userId: this.props.user.UserID,
      langId: 2,
    };
    this.props.getNotification(payload).then(
      (response) => {
        if (response.StatusCode == 200) {
          if (response.Data && response.Data.length > 0) {
            this.setState({
              NotificationInfo: response.Data,
              loader: false,
              moreDataLoader: false,
              isRefreshing: false,
            });
          } else {
            this.setState({
              loader: false,
              isRefreshing: false,
            });
          }
        } else {
          this.setState({
            showAlert: true,
            alertMsg:
              appResources &&
              appResources.OopsSomething &&
              appResources.OopsSomething,
          });
        }
      },
      (error) => {
        this.setState({
          loader: false,
          isRefreshing: false,
          showAlert: true,
          alertMsg:
            error && error.message
              ? error.message
              : appResources &&
                appResources.OopsSomething &&
                appResources.OopsSomething,
        });
      },
    );
  };
  componentWillMount() {
    this.focusListener = this.props.navigation.addListener('focus', () => {
      this.loaddata();
      //Put your Data loading function here instead of my this.LoadData()
    });
  }
  render() {
    const {appResources} = this.props;
    return (
      <View style={styles.container}>
        <CustomAlert
          isVisible={this.state.showAlert}
          onPress={() => this.setState({showAlert: false, alertMsg: ''})}
          message={this.state.alertMsg}
        />
        <LoaderView isVisible={this.state.loader} />

        <LinearGradient
          start={{x: 0, y: 0}}
          end={{x: 1, y: 0}}
          colors={['#FC4F1C', '#F89230', '#F9B434']}
          style={styles.linearGradient}>
          <Header
            navigation={this.props.navigation}
            isLeft={true}
            leftIcon={icons.back}
            navi={() => this.props.navigation.goBack()}
            isBorder={true}
            isHead={true}
            Head={'Notification'}
          />
        </LinearGradient>

        <FlatList
          data={this.state.NotificationInfo}
          renderItem={({item}) => {
            return (
              <View style={{marginBottom: height * 0.02}}>
                {/* <View style={styles.cont}> */}
                <View style={styles.cont}>
                  <View
                    style={{
                      alignItems: 'center',
                      flexDirection: 'row',
                      marginLeft: width * 0.04,
                      justifyContent: 'center',
                    }}>
                    <Avatar.Image size={50} source={{uri: item.ProfileUrl}} />

                    <View
                      style={{
                        flexDirection: 'column',
                        marginLeft: width * 0.02,
                      }}>
                      <Text
                        style={{
                          fontWeight: 'bold',
                          fontSize: RFValue(15, height),
                          marginBottom: height * 0.003,
                        }}>
                        {item.TourName}
                      </Text>
                      <Text
                        style={{
                          fontWeight: 'bold',
                          fontSize: RFValue(11, height),
                          color: '#A9A9A9',
                        }}>
                        {item.Description}
                      </Text>
                    </View>
                  </View>
                  <TouchableOpacity style={{justifyContent: 'center'}}>
                    <Text
                      style={{
                        marginRight: width * 0.05,
                        fontSize: RFValue(12, height),
                      }}>
                      {item.DurationText}
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
              // </View>
            );
          }}
          showsVerticalScrollIndicator={false}
          horizontal={false}
          numColumns={1}
          contentContainerStyle={{
            width: width,
            alignItems: 'center',
            paddingBottom: height * 0.14,
          }}
          ListEmptyComponent={
            <View
              style={{
                width: width * 0.9,
                marginTop: height * 0.05,
                marginBottom: height * 0.05,
              }}>
              <Text
                style={{
                  fontSize: RFValue(20, height),
                  color: 'black',
                  textAlign: 'center',
                }}>
                No Notifications !
              </Text>
            </View>
          }
        />
      </View>
    );
  }
}

const mapStateToProps = (state) => {
  const {appResources, token, user} = state.app;
  return {appResources, token, user};
};

const mapDispatchToProps = {
  getResources,
  getNotification,
};

export default connect(mapStateToProps, mapDispatchToProps)(Notifications);
