import {StyleSheet, Dimensions} from 'react-native';
const {width, height} = Dimensions.get('window');
import theme from '../../common/theme';

export default StyleSheet.create({
  container: {
    height: height * 0.1,
    width: '85%',
    //  marginTop: '1%',
    // margin: '2%',
    backgroundColor: 'white',
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent:'space-between',
    
  },
  addressList: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  part: {
    // flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

  part1: {
    flex: 3,
    alignItems: 'flex-start',
marginLeft:height*0.03,
    justifyContent: 'center',
  },
  text1: {
    color: 'gray',
    fontSize: 12,
  },
  text2: {
    color: 'black',
    fontSize: 15,
    textAlign: 'left',
  },
  toggleOn: {
    width: '20%',
    backgroundColor: '#309564',
    tintColor: 'green',
 
  },
  toggleOff: {
    width: '20%',
    borderColor: '#309564',
    paddingTop: 5,
      
  },
});
