import React, {Component} from 'react';
import { Text, View, TouchableOpacity, TouchableHighlight, Image, ScrollView,
} from 'react-native';
import styles from './style';
import {Images, Icons} from '../../utils';

//components
import Header from '../../components/Header';
import { TextInput } from 'react-native-gesture-handler';
import RoundCheckbox from 'rn-round-checkbox';

class Address extends Component {
  constructor() {
    super();

    this.state = {
      isSelected: true,

    };
  }
  toggleHandler = ()=>{
    let foc = this.state.isSelected
    this.setState({
      isSelected: !foc,
    })
  }

render() {
return (

    <TouchableOpacity style={styles.container}>  
    
    

    <RoundCheckbox
          size={24}
          checked={!this.state.isSelected}
          style={this.state.checked ? styles.toggleOn :styles.toggleOff}
          onValueChange = {this.toggleHandler} 
        // Add ICON here  
          backgroundColor = 'green'
        />
    
    



    <View style={styles.part1}>
          <Text style={styles.text1}>
            {this.props.extr.addrName}
            </Text>

          <Text style={styles.text2} numberOfLines ={ 1 }>
          {this.props.extr.addr1 + ', ' +this.props.extr.addr2 }
            </Text>

    </View>
    
    
    <TouchableOpacity style={styles.part}> 
      <Text style={{color: 'green'}}>
        Change
      </Text>
    </TouchableOpacity>
    
    </TouchableOpacity>

    );
  }
}

export default Address;
