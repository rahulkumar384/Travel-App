import React, {useState} from 'react';
import {
  View,
  TouchableOpacity,
  Image,
  Text,
  StyleSheet,
  Dimensions,
  Modal
} from 'react-native';
const {width, height} = Dimensions.get('window');
import styles from './Style';
import {Icons} from '../../utils';
import icons from '../../utils/icons';
import images from '../../utils/images';
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';



const AlertView = ({title}) => {
  const [alertVisible,setAlertVisible] = useState(true)

    return (
      <View>
        <Modal
        animationType="slide"
        transparent={true}
        visible={alertVisible}
        >
          <View><Text>{title}</Text></View>
        </Modal>
      </View>
    )
 
}
export default AlertView;
