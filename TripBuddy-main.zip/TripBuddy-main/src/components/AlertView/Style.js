import {StyleSheet, Dimensions} from 'react-native';
const {width, height} = Dimensions.get('window');
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';
export default StyleSheet.create({
  
  flatelist: {
    borderTopLeftRadius: 7, 
    borderTopRightRadius: 7,
    // marginBottom: height * 0.02,
      marginTop: height * 0.02,
      marginLeft: width * 0.01,
      marginRight: width * 0.05,
      resizeMode: 'cover',
      //backgroundColor: 'black',
      width: width * 0.37,
      height: height * 0.22,
      resizeMode: 'cover',
    },
    Text1: {fontSize: RFValue(13,height), marginLeft: width * 0.01, marginBottom: height * 0.01,marginTop:height*0.015},
    Text2: {fontSize: RFValue(10,height), marginLeft: width * 0.01, marginBottom: height * 0.02},
  
    viewflatlist: {
      marginLeft: width * 0.01,
      width: width * 0.37,
      height: height * 0.13,
      backgroundColor:'white',
      elevation:17,
      borderBottomLeftRadius:RFPercentage(1),
      borderBottomRightRadius:RFPercentage(1),
      shadowColor: 'black',
      shadowOpacity: 0.26,
      shadowOffset: { width: 0, height: 2},
      shadowRadius: 10,
    },
});
