
import React, {Component} from 'react';
import {View, TextInput, StyleSheet, Text, Image, Dimensions, TouchableOpacity} from 'react-native';
const {width, height} = Dimensions.get('window');
import styles from './style';

import {Circle} from 'react-native-shape';
import Icon from 'react-native-vector-icons/Ionicons';
class PaymentMethod extends Component {
     
    state = {
showMethod: true
    };
  

  
  render() {
        let icon1 = null;
       let icon2 = null;
       let icons = null;

       if(this.props.icon1 !== true && this.props.icon2 !== true){
  
        icons =(<View style={styles.icons}></View>);
       }else if(this.props.icon1 === true && this.props.icon2 !== true){
    
          icons=(
            <View style={styles.icons1}>
            <TouchableOpacity style={styles.icon1onlyContainer} onPress={this.props.icon1Press}>
            <Image style={styles.icon1} source={this.props.icon1image}/>
                 </TouchableOpacity>
                 </View>
          );
       }else if(this.props.icon1 !== true && this.props.icon2 === true){
         icons=(
          <View style={styles.icons1}>
        <TouchableOpacity style={styles.icon2Container}onPress={this.props.icon2Press}>
        <Image style={styles.icon2} source={this.props.icon2image}/>
             </TouchableOpacity>
             </View>);
       }else if(this.props.icon1 === true && this.props.icon2 === true){
icons=(  <View style={styles.icons2}>
       <TouchableOpacity style={styles.icon1Container} onPress={this.props.icon1Press}>
            <Image style={styles.icon1} source={this.props.icon1image}/>
                 </TouchableOpacity>
                 <TouchableOpacity style={styles.icon2Container}onPress={this.props.icon2Press}>
        <Image style={styles.icon2} source={this.props.icon2image}/>
             </TouchableOpacity>
  </View>)
       }

    return (
     
  <View style={[styles.boxContainer,this.props.boxstyle]}>
    { this.props.isHeading ?
    <Text style={[styles.Heading, this.props.Head]}>{this.props.Heading}</Text>
    : null
  }
 {this.props.children}
  </View>
    );
    }
  }
export default PaymentMethod;
