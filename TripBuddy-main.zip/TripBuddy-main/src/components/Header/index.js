import React, {Component} from 'react';
import {
  View,
  TouchableOpacity,
  Image,
  SafeAreaView,
  Text,
  ImageBackground,
  Dimensions,
} from 'react-native';
import styles from './style';
import {Icons} from '../../utils';
import icons from '../../utils/icons';
import images from '../../utils/images';
import style from '../../navigation/style';
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';
const {width, height} = Dimensions.get('window');
class Header extends Component {
  constructor() {
    super();
    this.state = {
      isleft: false,
      isright: false,
      isBack: false,
    };
  }

  render() {
    let header = null;
    if (
      this.props.isLeft == true &&
      this.props.isRight != true &&
      this.props.isHead != true
    ) {
      header = (
        <TouchableOpacity style={styles.leftCont} onPress={this.props.navi}>
          <Image source={this.props.leftIcon} style={styles.iconStyle} />
        </TouchableOpacity>
      );
    } else if (
      this.props.isLeft != true &&
      this.props.isRight == true &&
      this.props.isHead != true
    ) {
      header = (
        <TouchableOpacity style={styles.rightCont} onPress={this.props.navi}>
          <Image source={this.props.rightIcon} style={styles.iconStyle} />
        </TouchableOpacity>
      );
    } else if (
      this.props.isLeft == true &&
      this.props.isRight == true &&
      this.props.isHead != true
    ) {
      header = (
        <View style={styles.mainHead}>
          <TouchableOpacity style={styles.leftCont} onPress={this.props.navi}>
            <Image source={this.props.leftIcon} style={styles.iconStyle} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.rightCont2} onPress={this.props.navi}>
            <Image source={this.props.rightIcon} style={styles.iconStyle} />
          </TouchableOpacity>
        </View>
      );
    } else if (
      this.props.isLeft == true &&
      this.props.isRight != true &&
      this.props.isHead == true
    ) {
      header = (
        <View style={styles.mainHead}>
          <TouchableOpacity style={styles.leftCont} onPress={this.props.navi}>
            <Image source={this.props.leftIcon} style={styles.iconStyle} />
          </TouchableOpacity>
          <View style={{justifyContent: 'center'}}>
            <Text style={styles.headText}>{this.props.Head}</Text>
          </View>
          <View style={styles.rightCont2}></View>
        </View>
      );
    } else if (
      this.props.isLeft != true &&
      this.props.isRight == true &&
      this.props.isHead == true
    ) {
      header = (
        <View style={styles.mainHead}>
          <View style={styles.leftCont}></View>
          <View style={{justifyContent: 'center'}}>
            <Text style={styles.headText}>{this.props.Head}</Text>
          </View>
          <TouchableOpacity style={styles.rightCont2} onPress={this.props.navi}>
            <Image source={this.props.rightIcon} style={styles.iconStyle} />
          </TouchableOpacity>
        </View>
      );
    } else if (
      this.props.isLeft == true &&
      this.props.isRight == true &&
      this.props.isHead == true
    ) {
      header = (
        <View style={styles.mainHead}>
          <TouchableOpacity style={styles.leftCont} onPress={this.props.navi}>
            <Image source={this.props.leftIcon} style={styles.iconStyle} />
          </TouchableOpacity>
          <View style={{justifyContent: 'center'}}>
            <Text style={styles.headText}>{this.props.Head}</Text>
          </View>
          <TouchableOpacity
            style={{justifyContent: 'center'}}
            onPress={this.props.navi2}>
            <Text style={styles.RightText}>{this.props.right}</Text>
          </TouchableOpacity>
        </View>
      );
    }
    return (
      <SafeAreaView>
        <View style={this.props.isBorder ? styles.Header1 : styles.Header}>
          <View
            style={{
              width: '100%',
              height: '100%',
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignSelf: 'center',
            }}>
            {header}
          </View>
        </View>
      </SafeAreaView>
    );
  }
}

export default Header;
