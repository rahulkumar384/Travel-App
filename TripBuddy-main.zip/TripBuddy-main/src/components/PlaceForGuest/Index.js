import React, {Component} from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  TouchableHighlight,
  Image,
  ScrollView,
  Dimensions,
} from 'react-native';
import styles from './Style';
import {Images, Icons} from '../../utils';
const {width, height} = Dimensions.get('window');
//components
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';
import {connect} from 'react-redux';
import theme from '../../common/theme';
class PlaceForGuest extends Component {
  constructor() {
    super();

    this.state = {
      isSelected: true,
    };
  }

  months = [
    'JAN',
    'FEB',
    'MAR',
    'APR',
    'MAY',
    'JUN',
    'JUL',
    'AUG',
    'SEP',
    'OCT',
    'NOV',
    'DEC',
  ];
  render() {
    const {data} = this.props;

    let d = new Date(data.TourDate);
    var mon = this.months[d.getMonth()];
    var date = d.getDate();

    return (
      <TouchableOpacity
        style={styles.container}
        onPress={
          this.props.isGuide
            ? () =>
                this.props.navigation.navigate('GuideTourDetail', {
                  tour: data,
                })
            : () =>
                this.props.navigation.navigate('TourDetailForGuest', {
                  tour: data,
                })
        }>
        {this.props.isGuide ? (
          <View
            style={{
              position: 'absolute',
              left: 20,
              top: 20,
              elevation: 10,
              alignItems: 'center',
              backgroundColor: 'white',
              paddingLeft: height * 0.015,
              paddingRight: height * 0.015,
              paddingTop: height * 0.01,
              paddingBottom: height * 0.01,
              borderRadius: 2,
            }}>
            <Text style={{color: '#AEAEAE'}}>{mon}</Text>
            <Text
              style={{
                fontSize: RFValue(23, height),
                fontWeight: 'bold',
                color: theme.secondaryColor,
              }}>
              {date}
            </Text>
          </View>
        ) : null}
        <Image source={{uri: data.LogoUrl}} style={styles.imgStyle} />
        <View style={styles.bottomCont}>
          <TouchableOpacity>
            <Text style={styles.txtStyle1}>{data.TourName}</Text>
          </TouchableOpacity>
        </View>
      </TouchableOpacity>
    );
  }
}

const mapStateToProps = (state) => {
  const {date} = state.app;
  return {date};
};

const mapDispatchToProps = {};

export default connect(mapStateToProps, null)(PlaceForGuest);
