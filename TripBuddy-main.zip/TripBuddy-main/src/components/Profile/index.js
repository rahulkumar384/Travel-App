import React, {Component} from 'react';
import {
  View,
  TouchableOpacity,
  Image,
  Text,
  ImageBackground,
  Dimensions,
  Modal,
  FlatList,
  TextInput,
} from 'react-native';
const {width, height} = Dimensions.get('window');
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';
import styles from './Style';
import {Icons} from '../../utils';
import icons from '../../utils/icons';
import images from '../../utils/images';
import {ScrollView} from 'react-native-gesture-handler';
// local import
import LoaderView from '../Loader';

//Redux import
import {
  getResources,
  getCountries,
  updateCountry,
  updateUser,
} from '../../redux/actions/app';
import {connect, useDispatch} from 'react-redux';
import {makeAPICall} from '../../utils/callAPI';
import {UPDATE_USER} from '../../redux/reducers/app';

class Profile extends Component {
  constructor(props) {
    super();

    this.state = {
      countries: [],
      isLoading: false,
      isModelOpen: false,
      selectedCountryTxt: '',
      edit: false,
      name: props.name,
      number: props.number,
      email: props.email,
      bio: props.bio,
    };
  }

  componentDidMount() {
    //calling the countries API
    this.props.setLoading(true);
    this.props
      .getCountries(1)
      .then((response) => {
        console.log('countresi response ===>', response);
        let tempSelectedCountryTxt = '';
        const tempCountryArr = response.Data.map((singleCountry) => {
          if (singleCountry.CountryID == this.props.user.CountryID) {
            tempSelectedCountryTxt = singleCountry.CountryName;
          }
          return {
            label: singleCountry.CountryName,
            value: singleCountry.CountryID,
            flagUrl: singleCountry.flagUrl,
          };
        });

        this.setState({
          countries: tempCountryArr,
          selectedCountryTxt: tempSelectedCountryTxt,
        });
        this.props.setLoading(false);
      })
      .catch((error) => {
        this.setState({
          countries: [],
          selectedCountryTxt: '',
        });
        this.props.setLoading(false);
      });
  }

  // handle select country
  handleCountry = (updateCountryID) => {
    //if the updated country ID it the current country ID
    if (updateCountryID != this.props.user.CountryID) {
      //setting loader
      this.props.setLoading(true);
      //making API call for update country
      this.props
        .updateCountry(updateCountryID, this.props.user)
        .then((response) => {
          console.log('response update ===>', response);
          let tempCountryName = '';
          for (let country of this.state.countries) {
            console.log('ye ====>', country);
            if (country.value == updateCountryID) {
              tempCountryName = country.label;
            }
          }
          this.setState({
            isModelOpen: false,
            selectedCountryTxt: tempCountryName,
          });
        })
        .catch((error) => {
          this.setState({isModelOpen: false});
        })
        .finally(() => {
          this.props.setLoading(false);
        });
    }
  };

  update = () => {
    if (this.state.edit) {
      //DO UPDATE
      this.setState({edit: false});
      this.props.setLoading(true);
      makeAPICall(
        '/data/update-profile',
        {
          param: {
            UserID: this.props.id,
            CountryID: this.props.user.CountryID,
            CityID: this.props.user.CityID,
            FullName: this.state.name,
            EmailAddress: this.props.user.EmailAddress,
            PhoneNo: this.state.number,
            ProfileUrl: this.props.user.ProfileUrl,
            Bio: this.state.bio,
          },
        },
        this.props.id,
      ).then((res) => {
        debugger;
        makeAPICall(
          '/data/get-profile',
          {
            param: {
              UserID: this.props.id,
            },
          },
          this.props.id,
        )
          .then((resUser) => {
            if (resUser.data.StatusMessage == 'Success' && resUser.data.Data) {
              this.props.updateUser(resUser.data.Data);
            }
          })
          .finally(() => this.props.setLoading(false));
      });
    } else {
      this.setState({edit: true});
    }
  };

  render() {
    const {appResources} = this.props;
    return (
      <View style={styles.container}>
        <ScrollView>
          {this.state.edit && (
            <Text
              style={{
                alignSelf: 'center',
              }}>
              Tap on the photo to change
            </Text>
          )}
          <View style={{alignItems: 'center', marginBottom: height * 0.03}}>
            <Text style={styles.aboutMain1}>{this.props.name}</Text>
          </View>
          <TouchableOpacity style={styles.bookButton} onPress={this.update}>
            <Text style={{fontSize: RFValue(18, height), color: 'white'}}>
              {this.state.edit ? 'Save Changes' : 'Edit'}
            </Text>
          </TouchableOpacity>

          {this.props.name ? (
            <View style={styles.cont}>
              <View
                style={{
                  width: width * 0.9,
                  flexDirection: 'row',
                  //marginTop: height * 0.02,
                  justifyContent: 'space-between',
                }}>
                <View
                  style={{flexDirection: 'column', marginLeft: width * 0.04}}>
                  <Text style={styles.aboutMain}>{appResources.Name}:</Text>
                  {this.state.edit ? (
                    <View
                      style={{
                        flexDirection: 'row',
                        width: width * 0.9,
                        alignItems: 'center',
                      }}>
                      <TextInput
                        value={this.state.name}
                        style={{width: width * 0.75}}
                        onChangeText={(text) => this.setState({name: text})}
                      />
                      <Image
                        style={{
                          resizeMode: 'contain',
                          width: width * 0.04,
                          height: height * 0.03,
                          // backgroundColor:'red',
                          alignSelf: 'center',
                        }}
                        source={require('../../assets/pencil.png')}
                      />
                    </View>
                  ) : (
                    <Text style={styles.aboutInput}>{this.props.name}</Text>
                  )}
                </View>
              </View>
            </View>
          ) : null}

          {this.props.number ? (
            <View style={styles.cont}>
              <View
                style={{
                  width: width * 0.9,
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}>
                <View
                  style={{flexDirection: 'column', marginLeft: width * 0.04}}>
                  <Text style={styles.aboutMain}>
                    {appResources.PhoneNumber}:
                  </Text>
                  {this.state.edit ? (
                    <View
                      style={{
                        flexDirection: 'row',
                        width: width * 0.9,
                        alignItems: 'center',
                      }}>
                      <TextInput
                        value={this.state.number}
                        style={{width: width * 0.75}}
                        onChangeText={(text) => this.setState({number: text})}
                      />
                      <Image
                        style={{
                          resizeMode: 'contain',
                          width: width * 0.04,
                          height: height * 0.03,
                          //backgroundColor:'red',
                          alignSelf: 'center',
                        }}
                        source={require('../../assets/pencil.png')}
                      />
                    </View>
                  ) : (
                    <Text style={styles.aboutInput}>{this.props.number}</Text>
                  )}
                </View>
              </View>
            </View>
          ) : null}

          <View style={styles.cont}>
            <View
              style={{
                width: width * 0.9,
                flexDirection: 'row',

                justifyContent: 'space-between',
              }}>
              <View style={{flexDirection: 'column', marginLeft: width * 0.04}}>
                <Text style={styles.aboutMain}>Bio:</Text>
                {this.state.edit ? (
                  <View
                    style={{
                      flexDirection: 'row',
                      width: width * 0.9,
                      alignItems: 'center',
                    }}>
                    <TextInput
                      value={this.state.bio}
                      style={{width: width * 0.75}}
                      onChangeText={(text) => this.setState({bio: text})}
                      placeholder={'Enter Bio'}
                      placeholderTextColor="black"
                    />
                    <Image
                      style={{
                        resizeMode: 'contain',
                        width: width * 0.04,
                        height: height * 0.03,
                        //backgroundColor:'red',
                        alignSelf: 'center',
                      }}
                      source={require('../../assets/pencil.png')}
                    />
                  </View>
                ) : (
                  <Text style={styles.aboutInput}>{this.props.bio}</Text>
                )}
              </View>
            </View>
          </View>

          <View style={styles.cont}>
            {this.props.email ? (
              <View
                style={{
                  width: width * 0.9,
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}>
                <View
                  style={{flexDirection: 'column', marginLeft: width * 0.04}}>
                  <Text style={styles.aboutMain}>
                    {appResources.EmailAddress}:
                  </Text>
                  {false ? (
                    <TextInput
                      value={this.state.email}
                      style={{width: '100%'}}
                      onChangeText={(text) => this.setState({email: text})}
                    />
                  ) : (
                    <Text style={styles.aboutInput}>{this.props.email}</Text>
                  )}
                </View>
              </View>
            ) : null}
          </View>

          {/** COUNTRY START */}
          {!this.props.user.IsTourGuide ? (
            <View style={styles.cont}>
              <View
                style={{
                  width: width * 0.9,
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}>
                <View
                  style={{flexDirection: 'column', marginLeft: width * 0.04}}>
                  <Text style={styles.aboutMain}>Selected Country:</Text>
                  <Text style={styles.aboutInput}>
                    {this.state.selectedCountryTxt}
                  </Text>
                </View>
                <TouchableOpacity
                  onPress={() => this.setState({isModelOpen: true})}
                  activeOpacity={10}
                  style={{
                    justifyContent: 'center',
                    //backgroundColor: 'red',
                    marginRight: width * 0.02,
                  }}>
                  <Text style={styles.countryButtonTxt}>Update</Text>
                </TouchableOpacity>
              </View>
            </View>
          ) : null}
          {/**COUNTRY MODAL START */}

          {/**COUNTRY MODAL END */}

          <Modal
            animationType="slide"
            transparent={true}
            visible={this.state.isModelOpen}>
            <TouchableOpacity
              style={styles.centeredView}
              activeOpacity={10}
              onPress={() => this.setState({isModelOpen: false})}>
              <View style={styles.lModalView}>
                <View style={styles.openModelTitleView}>
                  <Text style={styles.openModelTitle}>
                    Select Country to Update
                  </Text>
                </View>
                <FlatList
                  style={{width: '100%'}}
                  data={this.state.countries}
                  keyExtractor={(item) => item.value}
                  renderItem={({item, index, separators}) => (
                    <TouchableOpacity
                      onPress={() => this.handleCountry(item.value)}
                      style={styles.litstItemView}
                      activeOpacity={10}>
                      <View style={styles.imgTextContainer}>
                        <Image
                          source={{
                            uri: item.flagUrl,
                          }}
                          resizeMode="contain"
                          style={{width: width * 0.08, height: height * 0.08}}
                        />

                        <Text style={styles.litstItem}>{item.label}</Text>
                      </View>

                      {this.props.user.CountryID == item.value ? (
                        <Image
                          source={icons.circuleTick}
                          resizeMode="contain"
                          style={{width: width * 0.05, height: height * 0.05}}
                        />
                      ) : (
                        <Image
                          source={icons.circuleUntick}
                          resizeMode="contain"
                          style={{width: width * 0.05, height: height * 0.05}}
                        />
                      )}
                    </TouchableOpacity>
                  )}
                />
              </View>
            </TouchableOpacity>
          </Modal>
          {/** COUNTRY END */}
        </ScrollView>
      </View>
    );
  }
}

const mapStateToProps = (state) => {
  const {appResources, token, countries, languages, user} = state.app;
  return {appResources, token, countries, languages, user};
};

const mapDispatchToProps = {
  getResources,
  getCountries,
  updateCountry,
  updateUser,
};

export default connect(mapStateToProps, mapDispatchToProps)(Profile);
