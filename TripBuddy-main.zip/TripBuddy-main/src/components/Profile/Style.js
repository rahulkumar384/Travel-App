import {StyleSheet, Dimensions} from 'react-native';
const {width, height} = Dimensions.get('window');
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';
import theme from '../../common/theme';

export default StyleSheet.create({
  container: {
    width: width,
    backgroundColor: 'white',
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  bookButton: {
    width: width * 0.89,
    height: height * 0.055,
    backgroundColor: theme.secondaryColor,
    marginVertical: height * 0.02,
    borderRadius: 22,
    justifyContent: 'center',
    alignSelf: 'center',
    alignItems: 'center',
  },
  Viewall: {
    justifyContent: 'center',
    alignItems: 'center',
    color: '#F0F7F2',
    fontSize: RFValue(15, height),
    marginRight: width * 0.04,
    color: 'black',
  },
  aboutMain: {
    fontSize: RFValue(17, height),
    //fontFamily: 'Montserrat-Regular',
    fontWeight: 'bold',
    color: 'black',
    marginBottom: height * 0.01,
  },
  cont: {
    backgroundColor: '#F0F7F2',
    width: width * 0.9,
    borderRadius: 15,
    marginBottom: height * 0.02,
    paddingBottom: height * 0.02,
    paddingTop: height * 0.02,
  },
  countryButtonTxt: {
    fontSize: RFValue(15, height),
    //fontFamily: 'Montserrat-Regular',
    fontWeight: 'bold',
    color: 'black',
  },
  //MOdel Styles start
  centeredView: {
    height,
    width,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.7)',
  },
  lModalView: {
    height: height * 0.43, //height * 0.262
    width: '75%',
    backgroundColor: 'white',
    //justifyContent: 'space-evenly',
    alignItems: 'center',
    borderRadius: width * 0.03,
    overflow: 'hidden',
  },
  openModelTitleView: {
    marginTop: height * 0.03,
    paddingBottom: height * 0.03,
    width: width,
    justifyContent: 'center',
    alignItems: 'center',
    //backgroundColor: 'red',
    borderBottomColor: '#eee',
    borderBottomWidth: width * 0.003,
  },
  openModelTitle: {
    fontSize: RFValue(15, height),
    fontWeight: 'bold',
    color: '#616161',
  },
  litstItemView: {
    //backgroundColor: 'red',
    width: '100%',
    height: height * 0.08,

    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomColor: '#eee',
    borderBottomWidth: width * 0.001,
    padding: width * 0.08,
    paddingLeft: width * 0.04,
  },
  imgTextContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  litstItem: {
    height: 20,
    marginLeft: width * 0.04,
    fontSize: RFValue(15, height),
    //backgroundColor:"red",
    color: '#616161',
  },
  //MOdel Styles END
  aboutInput: {
    fontSize: RFValue(16, height),
  },
  aboutMain1: {
    fontSize: RFValue(20, height),
    //fontFamily: 'Montserrat-Regular',
    fontWeight: 'bold',
    color: 'black',
    marginBottom: height * 0.01,
  },
});
