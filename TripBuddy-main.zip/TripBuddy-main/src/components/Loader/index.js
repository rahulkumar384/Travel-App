import React, {Component} from 'react';
import {
  View,
  Modal,
  ActivityIndicator,
  StyleSheet,
  Dimensions,
} from 'react-native';
const {width, height} = Dimensions.get('window');

class LoaderView extends Component {
  constructor() {
    super();

    this.state = {};
  }

  render() {
    const {isVisible} = this.props;
    if (isVisible)
    return (
      <View style={{top:0,left:0,zIndex:30, justifyContent:'center', alignItems:'center', position:'absolute'}}>
        <View style={styles.centeredView}>
          <View style={styles.lModalView}>
            <ActivityIndicator size={'large'} color="#fff" />
          </View>
      </View>
      </View>
    );
    else 
    return <View/>
  }
}

export default LoaderView;

const styles = StyleSheet.create({
  centeredView: {
    height,
    width,
    justifyContent: 'center',
    alignItems: 'center',
  },
  lModalView: {
    height: '100%',
    width: '100%',
    backgroundColor: 'rgba(0,0,0,0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
});
