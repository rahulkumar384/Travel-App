import {StyleSheet, Dimensions} from 'react-native';
const {width, height} = Dimensions.get('window');
import theme from '../../common/theme';

export default StyleSheet.create({
  container: {
    height: height * 0.1,
    width: '85%',
    //  marginTop: '1%',
    // margin: '2%',
    backgroundColor: 'white',
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent:'space-between',
    
  },
 
});
