import React, {Component} from 'react';
import {Text, View, TouchableOpacity, Image, Dimensions} from 'react-native';
const {width, height} = Dimensions.get('window');
//components
import {Avatar} from 'react-native-paper';
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';

class ChooseGuideComp extends Component {
  constructor() {
    super();

    this.state = {
      isSelected: true,
    };
  }

  toggleHandler = () => {
    let foc = this.state.isSelected;
    this.setState({
      isSelected: !foc,
    });
  };

  render() {
    const {data, tourData} = this.props;
    return (
      <TouchableOpacity
        onPress={() =>
          this.props.navigation.navigate('Guide', {
            guide: data,
            tour: tourData,
          })
        }
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          width: '100%',
          marginBottom: height * 0.02,
        }}>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <Avatar.Image
            size={50}
            style={{backgroundColor: '#EAF6F', marginRight: height * 0.02}}
            source={{uri: data.ProfileUrl}}
          />
          <View style={{flexDirection: 'column'}}>
            <Text style={{fontWeight: 'bold', fontSize: RFValue(12, height)}}>
              {data.FullName}
            </Text>
            <Text style={{fontSize: RFValue(10, height)}}>
              {data.Amount} {data.Currency}
            </Text>
          </View>
        </View>

        <View style={{flexDirection: 'row', alignItems: 'center'}}>
          <Image
            style={{
              width: width * 0.04,
              height: height * 0.04,
              resizeMode: 'contain',
            }}
            source={require('../../assets/star.png')}
          />
          <Text style={{fontWeight: 'bold', marginLeft: height * 0.01}}>
            {data.Ratings}
          </Text>
        </View>
      </TouchableOpacity>
    );
  }
}

export default ChooseGuideComp;
