import React, {Component} from 'react';
import {
  View,
  Modal,
  Text,
  TouchableOpacity,
  Dimensions,
  I18nManager,
  Image,
} from 'react-native';
import styles from './style';
import Icons from '../../utils/icons';
const {width, height} = Dimensions.get('window');

class CustomAlert extends Component {
  render() {
    const {isVisible, onPress, message} = this.props;
    return (
      <Modal animationType="fade" transparent={true} visible={isVisible}>
        <View style={styles.centeredView}>
          <View style={styles.lModalView}>
            <View style={styles.logoBox}>
              <Image
                source={require('../../assets/compassBlack.png')}
                style={styles.logoStyle}
              />
            </View>
            <Text style={styles.msgText}>{message}</Text>
            <TouchableOpacity onPress={onPress} style={styles.okBox}>
              <Text style={styles.okText}>
                {I18nManager.isRTL ? 'حسنا' : 'OK'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    );
  }
}

export default CustomAlert;
