import React, {useState} from 'react';
import {
  Text,
  View,
  Dimensions,
  Image,
  TextInput,
  TouchableOpacity,
  TouchableOpacityBase,

} from 'react-native';

import styles from './style';
import icons from '../../utils/icons';
import { Icons } from '../../utils';

const {width, height} = Dimensions.get('window');

export default function index(props) {
  const [ShowPass, setShowPass] = useState(true)

const handlePass = ()=>{
  setShowPass(!ShowPass)
}

  return (
    
    <TouchableOpacity style={props.isLeftIcon == true && props.RightIcon != true ? [styles.sectionStyle2,props.mainStyle] : [styles.sectionStyle,props.mainStyle]} onPress={props.onPress}>
      {props.isLeftIcon ?
      <TouchableOpacity style={[styles.rightcont,props.leftContStyle]} >
        <Image source={props.leftIcon} style={styles.imagStyle} />
      </TouchableOpacity>
       : null}
        <TextInput
          secureTextEntry= {props.isPass ? ShowPass : null}
          style={[styles.placestyle,props.style]}
          placeholder={props.Label}
          // selectionColor="#309564"
        editable={props.editable}
          value={props.value}
          onChangeText={props.onChangeText}
          onFocus={props.onFocus}
        autoCapitalize={props.autoCapitalize}
        keyboardType={props.keyboardType}
        textContentType={props.textContentType}
        maxLength={props.maxLength}
        />
        {props.RightText ? <View style={[styles.rightcont,props.rightContStyle]} >
      <Text style={styles.fontStyle} >{props.text}</Text>
      </View>
       : null}
    {props.RightIcon ? <TouchableOpacity style={[styles.rightcont,props.rightContStyle]} onPress={props.onPressRight}>
        <Image source={props.rightIcon} style={styles.imagStyle} />
      </TouchableOpacity>
       : null}
{props.isRightIcon ?
      <TouchableOpacity style={styles.rightcont} onPress={handlePass}>
        <Image source={ShowPass ? props.eye : Icons.eyeicon} style={styles.imagStyle} />
      </TouchableOpacity>
       : null}
    </TouchableOpacity>
   

  );
}

