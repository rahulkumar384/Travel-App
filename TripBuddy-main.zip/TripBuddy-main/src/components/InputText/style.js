import {StyleSheet, Dimensions} from 'react-native';

const {width, height} = Dimensions.get('window');
import theme from '../../common/theme';
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';
export default StyleSheet.create({


sectionStyle: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: height * 0.06,
    width: '100%',
    borderBottomWidth : 1,
    marginVertical :height * 0.0075,
    // backgroundColor:'red',
  },
  sectionStyle2: {
    flexDirection: 'row',
   
    alignItems: 'center',
    height: height * 0.06,
    width: '100%',
    borderBottomWidth : 1,
    marginVertical :height * 0.0075,
   
    // backgroundColor:'red',
  },
  imageStyle: {
  
    height: '60%',
    width: '60%',
    resizeMode: 'contain'
  },
fontStyle:{
fontSize:RFValue(15,height)
},
  leftcont:{
    height:'100%',
    width: '10%',
    resizeMode: 'contain',
    justifyContent: 'center',
    alignItems: 'center'
  },

  centercont:{
      flexDirection:'row',
      width:'80%',
      height:'100%',
  }, 
  placestyle:{
      width:'80%',
      height:'100%',
    

      paddingBottom: height *0.02,
      fontSize: width *0.04,
      fontFamily:'SF Pro Text',
     
  },
  rightcont:{
    // backgroundColor:'red',
    height:'50%',
    width: '10%',
    resizeMode: 'contain',
    justifyContent: 'center',
    alignItems: 'center',
  
    // paddingBottom: height *0.08,
  
  },
  imagStyle:{
    // backgroundColor:'blue',
    height: '100%',
    width: '100%',
    resizeMode: 'contain'
  },
});