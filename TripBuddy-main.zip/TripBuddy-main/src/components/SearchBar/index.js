import React, {Component} from 'react';
import {TextInput, View, Image} from 'react-native';

import styles from './style';
import {Icons} from '../../utils';

class SearchBar extends Component {
  constructor() {
    super();

    this.state = {
      searchTxt: '',
    };
  }

  render() {
    const {searchTxt} = this.state;
    return (
      <View style={styles.container}>
        <View style={styles.iconCont}>
          <Image
            style={styles.iconStyle}
            source={Icons.searchIcon}
            resizeMode={'center'}
          />
        </View>
        <TextInput
        onFocus={this.props.focus}
          style={styles.searchCont}
          onChangeText={(text) => this.setState({searchTxt: text})}
          value={searchTxt}
          placeholder={this.props.placeholder}
        />
      </View>
    );
  }
}

export default SearchBar;
