import {StyleSheet, Dimensions} from 'react-native';
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';
const {width, height} = Dimensions.get('window');

export default StyleSheet.create({
  container: {
    height: height * 0.07,
    width: '100%',
    backgroundColor: 'white',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: height * 0.04,
    marginBottom: height * 0.02,
    shadowColor: '#000',
    shadowOpacity: 0.5,
    shadowRadius: 3.84,
    borderBottomWidth: 1,
  },
  searchCont: {
    height: '100%',
    width: '90%',
    fontSize: RFValue(17, height),
    marginLeft: width * 0.01,
  },
  iconCont: {
    height: '100%',
    width: '15%',
    justifyContent: 'center',
    alignItems: 'center',

    marginRight: width * 0.025,
  },
  iconStyle: {
    width: '100%',
    height: '100%',
    opacity: 0.5,
  },
});
