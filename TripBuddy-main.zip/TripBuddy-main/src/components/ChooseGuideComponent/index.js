import React, {Component} from 'react';
import { Text, View, TouchableOpacity,Image} from 'react-native';
import styles from './Style';
const {width, height} = Dimensions.get('window');
import {StyleSheet, Dimensions} from 'react-native';
import theme from '../../common/theme';

class ChooseGuideComponent extends Component {
  constructor() {
    super();

    this.state = {
    
    };
  }
  

render() {
return (

    <View style={styles.container}>  
      <View
                style={{marginLeft: width * 0.06, marginTop: height * 0.03}}>
                <Text style={{fontSize: width * 0.04, color: '#FFD700'}}>
                  Museum Tour
                </Text>
                <Text
                  style={{
                    fontSize: width * 0.025,
                    color: 'black',
                    marginTop: height * 0.01,
                  }}>
                  Book a guide for all the London Museums
                </Text>
              </View>

              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  width: width * 0.65,
                  marginLeft:width*0.04}}>
                <Text
                  style={{
                    fontSize: width * 0.04,
                    color: 'black',
                    fontWeight: 'bold',
                    marginLeft: width * 0.02,
                  }}>
                  Choose Guide:
                </Text>
                <TouchableOpacity>
                  <Image
                    style={{
                      resizeMode: 'contain',
                      width: width * 0.05,
                      height: height * 0.05,
                    }}
                    source={require('../../assets/filter.png')}
                  />
                </TouchableOpacity>
              </View>

              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  width: width * 0.65,
                  marginLeft:width*0.049
                }}>
                <View style={{flexDirection: 'row'}}>
                  <Image
                    style={{
                      resizeMode: 'contain',
                      width: width * 0.05,
                      height: height * 0.05,
                    }}
                    source={require('../../assets/Shape.png')}
                  />
                  <View
                    style={{flexDirection: 'column', marginLeft: width * 0.04}}>
                    <Text style={{fontWeight: 'bold'}}>Liv Morro</Text>
                    <Text>London</Text>
                  </View>
                </View>

                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                  <Image
                    style={{
                      width: width * 0.04,
                      height: height * 0.04,
                      resizeMode: 'contain',
                    }}
                    source={require('../../assets/star.png')}
                  />
                  <Text style={{fontWeight: 'bold', marginLeft: width * 0.02}}>
                    4.8
                  </Text>
                </View>
              </View>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  width: width * 0.65,
                  marginLeft:width*0.049,
                  marginTop: height * 0.025,
                }}>
                <View style={{flexDirection: 'row'}}>
                  <Image
                    style={{
                      resizeMode: 'contain',
                      width: width * 0.05,
                      height: height * 0.05,
                    }}
                    source={require('../../assets/Shape.png')}
                  />
                  <View
                    style={{flexDirection: 'column', marginLeft: width * 0.04}}>
                    <Text style={{fontWeight: 'bold'}}>Bruce Lee</Text>
                    <Text>London</Text>
                  </View>
                </View>

                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                  <Image
                    style={{
                      width: width * 0.04,
                      height: height * 0.04,
                      resizeMode: 'contain',
                    }}
                    source={require('../../assets/star.png')}
                  />
                  <Text style={{fontWeight: 'bold', marginLeft: width * 0.02}}>
                   
                    4.9
                  </Text>
                </View>
              </View>

              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  width: width * 0.65,
                  marginLeft:width*0.049,
                  marginTop: height * 0.025,
                }}>
                <View style={{flexDirection: 'row'}}>
                  <Image
                    style={{
                      resizeMode: 'contain',
                      width: width * 0.05,
                      height: height * 0.05,
                    }}
                    source={require('../../assets/Shape.png')}
                  />
                  <View
                    style={{flexDirection: 'column', marginLeft: width * 0.04}}>
                    <Text style={{fontWeight: 'bold'}}>Vicky Wayne</Text>
                    <Text>London</Text>
                  </View>
                </View>

                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                  <Image
                    style={{
                      width: width * 0.04,
                      height: height * 0.04,
                      resizeMode: 'contain',
                    }}
                    source={require('../../assets/star.png')}
                  />
                  <Text style={{fontWeight: 'bold', marginLeft: width * 0.02}}>
                    3.5
                  </Text>
                </View>
              </View>

              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  width: width * 0.65,
                  marginLeft:width*0.049,
                  marginTop: height * 0.025,
                }}>
                <View style={{flexDirection: 'row'}}>
                  <Image
                    style={{
                      resizeMode: 'contain',
                      width: width * 0.05,
                      height: height * 0.05,
                    }}
                    source={require('../../assets/Shape.png')}
                  />
                  <View
                    style={{flexDirection: 'column', marginLeft: width * 0.04}}>
                    <Text style={{fontWeight: 'bold'}}>Kevin Lara</Text>
                    <Text>London</Text>
                  </View>
                </View>

                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                  <Image
                    style={{
                      width: width * 0.04,
                      height: height * 0.04,
                      resizeMode: 'contain',
                    }}
                    source={require('../../assets/star.png')}
                  />
                  <Text style={{fontWeight: 'bold', marginLeft: width * 0.02}}>
                    3.0
                  </Text>
                </View>
              </View>

              <TouchableOpacity
              style={{width:width*0.8,height:height*0.07,alignSelf:'center',backgroundColor:theme.secondaryColor,marginTop:height*0.03,borderBottomEndRadius:15,borderBottomStartRadius:15}}
              onPress={this.props.navi}>
                <Text style={{textAlign:'center',marginTop:height*0.02,fontSize:width*0.038, color:'white'}}>BOOK GUIDES</Text>
                  </TouchableOpacity>
    </View>

    );
  }
}

export default ChooseGuideComponent;
