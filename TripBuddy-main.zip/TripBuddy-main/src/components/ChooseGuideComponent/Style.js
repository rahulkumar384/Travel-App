import {StyleSheet, Dimensions} from 'react-native';
const {width, height} = Dimensions.get('window');
import theme from '../../common/theme';

export default StyleSheet.create({
  container: {
   // height:height*0.56,
    width: width*0.8,
elevation:10,

backgroundColor:'white',
borderRadius:15
    //backgroundColor: 'red',
    //alignItems: 'center',
    //backgroundColor:'red',
    //marginBottom:height*0.02
  },
});
