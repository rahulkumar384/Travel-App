import {StyleSheet, Dimensions} from 'react-native';
import { shadow } from 'react-native-paper';
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';
const {width, height} = Dimensions.get('window');

export default StyleSheet.create({
   
    boxContainer:{
      alignSelf:'center',
      marginTop:5,
   padding:height*0.02,
 
   width:width*0.9,
    elevation:20,
    borderWidth:0,
    borderLeftWidth:0,
    borderRightColor:0,
    borderBottomWidth:0,
    borderTopWidth:0,
    backgroundColor:'white',
    borderTopLeftRadius:RFPercentage(3),
    borderTopRightRadius:RFPercentage(3),
    borderBottomLeftRadius:RFPercentage(3),
    borderBottomRightRadius:RFPercentage(3),
    shadowColor: 'black',
  shadowOpacity: 0.26,
  shadowOffset: { width: 0, height: 2},
  shadowRadius: 10,
  marginBottom:RFPercentage(1.5),
  
    },
    Heading:{
fontSize:RFValue(20,height),
fontWeight:'bold',
marginBottom:RFValue(15,height)
    },
    contentContainer:{
      flexDirection:'row',
     width:'100%',

  
    },
    content:{width:'90%'},
    icons1:{width:'10%',
  justifyContent:'space-between',


  },
  icons2:{width:'10%',
  justifyContent:'space-between',

  },
  icon1Container:{width:'100%', height:'30%', justifyContent:'center'},
  icon2Container:{width:'100%', height:'30%'},
  icon1onlyContainer:{width:'100%', height:'70%', backgroundColor:'white', justifyContent:'center'},
  
  icon1:{width:'100%',  height:'100%', resizeMode:'contain'},
  icon2:{width:'100%', height:'100%', resizeMode:'contain'},
  });