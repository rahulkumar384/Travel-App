import React, {Component} from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  TouchableHighlight,
  Image,
  ScrollView,
} from 'react-native';
import styles from './style';
import {Images, Icons} from '../../utils';

//components
import Header from '../../components/Header';
import {TextInput} from 'react-native-gesture-handler';
import RoundCheckbox from 'rn-round-checkbox';

class Address extends Component {
  constructor() {
    super();

    this.state = {
      isSelected: false,
      NotSeletedText:false
    };
  }

  render() {
    return (
      <TouchableOpacity
        style={
          this.props.isSelected ? styles.onPressContainer : styles.container
        }
        onPress={this.props.onPress}>
        <Text style={ this.props.NotSeletedText ? styles.txtStyle : styles.txtStyle1}>{this.props.name}</Text>
      </TouchableOpacity>
    );
  }
}

export default Address;
