import {StyleSheet, Dimensions} from 'react-native';
const {width, height} = Dimensions.get('window');
import theme from '../../common/theme';
import {RFPercentage, RFValue} from 'react-native-responsive-fontsize';

export default StyleSheet.create({
  container: {
    height: '100%',
    paddingLeft: width * 0.08,
    paddingRight: width * 0.08,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 30,
    borderColor: theme.secondaryColor,
    borderWidth: 2,
    marginRight: height * 0.01,
  
  },
  onPressContainer: {
    height: '100%',
    paddingLeft: width * 0.08,
    paddingRight: width * 0.08,
    backgroundColor: theme.secondaryColor,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 30,
    //elevation: 8,
    marginRight: height * 0.01,
  },
  txtStyle: {
    fontSize: RFValue(13, height),
    color: theme.primaryColor,
  },
  txtStyle1:{
    fontSize: RFValue(13, height),
    color: theme.secondaryColor,
  }
});
