import {StyleSheet, Dimensions} from 'react-native';
const {width, height} = Dimensions.get('window');
import theme from '../../common/theme';
import {RFValue} from 'react-native-responsive-fontsize'
export default StyleSheet.create({
  container: {
    height: height*0.3,
    width: '90%',
    alignSelf:'center',
    //  marginTop: '1%',
    // margin: '2%',


    alignItems: 'center',
    justifyContent:'center',
    borderRadius:15,
    marginTop:height*0.02
  },
  bottomCont:{
    backgroundColor:theme.secondaryColor,
    height:'25%',
    width:'100%',
    flexDirection:'row',
    justifyContent:'space-between',
    alignItems:'center',
    paddingLeft:height*0.02,
    paddingRight:height*0.02,
    borderBottomLeftRadius:15,
    borderBottomRightRadius:15
  },
  txtStyle1:{color:theme.primaryColor, fontSize:RFValue(20,height)},
  txtStyle2:{color:theme.primaryColor, fontSize:RFValue(15,height)},
  imgStyle:{
    width:'100%',
    height:'75%',
    resizeMode:'cover',
    
    borderTopRightRadius:15,
    borderTopLeftRadius:15
  },
  

});
